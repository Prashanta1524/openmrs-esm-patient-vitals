(globalThis["webpackChunk_openmrs_esm_patient_vitals_app"] = globalThis["webpackChunk_openmrs_esm_patient_vitals_app"] || []).push([["src_index_ts"],{

/***/ "../../node_modules/openmrs/node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[2].use[1]!../../node_modules/openmrs/node_modules/sass-loader/dist/cjs.js??ruleSet[1].rules[2].use[2]!./src/biometrics/biometrics-base.scss":
/*!************************************************************************************************************************************************************************************************************************************!*\
  !*** ../../node_modules/openmrs/node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[2].use[1]!../../node_modules/openmrs/node_modules/sass-loader/dist/cjs.js??ruleSet[1].rules[2].use[2]!./src/biometrics/biometrics-base.scss ***!
  \************************************************************************************************************************************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_openmrs_node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../../node_modules/openmrs/node_modules/css-loader/dist/runtime/cssWithMappingToString.js */ "../../node_modules/openmrs/node_modules/css-loader/dist/runtime/cssWithMappingToString.js");
/* harmony import */ var _node_modules_openmrs_node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_openmrs_node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_openmrs_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../../node_modules/openmrs/node_modules/css-loader/dist/runtime/api.js */ "../../node_modules/openmrs/node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_openmrs_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_openmrs_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_openmrs_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_openmrs_node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0___default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, "/* 60,70 and 80 are already declared as brand-01, 02 and 03 respectively */\n:root {\n  --brand-01: #005d5d;\n  --brand-02: #004144;\n  --brand-03: #007d79;\n  --bottom-nav-height: 4rem;\n  --workspace-header-height: 3rem;\n  --tablet-workspace-window-height: calc(100vh - var(--omrs-navbar-height) - var(--bottom-nav-height));\n  --desktop-workspace-window-height: calc(100vh - var(--omrs-navbar-height) - var(--workspace-header-height));\n}\n\n/* These color variables will be removed in a future release */\n.-esm-patient-vitals__biometrics-base__widgetCard___2dWUk {\n  border: 1px solid #e0e0e0;\n  background-color: #ffffff;\n}\n\n.-esm-patient-vitals__biometrics-base__activitiesText___td-Wu {\n  background-color: #f0f4ff;\n  border: 2px solid #2f80ed;\n  border-radius: 10px;\n  padding: 1.2rem 1.5rem;\n  margin: 1rem 0;\n  box-shadow: 0 3px 8px rgba(0, 0, 0, 0.1);\n  word-wrap: break-word;\n  font-size: 1rem;\n  line-height: 1.6;\n}\n.-esm-patient-vitals__biometrics-base__activitiesText___td-Wu p {\n  margin: 0.3rem 0;\n}\n.-esm-patient-vitals__biometrics-base__activitiesText___td-Wu strong {\n  display: block;\n  font-weight: 600;\n  margin: 0.5rem 0;\n}\n.-esm-patient-vitals__biometrics-base__activitiesText___td-Wu li {\n  margin-left: 1.5rem;\n  list-style-type: disc;\n}\n\n.-esm-patient-vitals__biometrics-base__biometricsHeaderActionItems___-lWW0 {\n  align-items: center;\n  display: flex;\n  flex: 1 1 0%;\n  justify-content: end;\n}\n.-esm-patient-vitals__biometrics-base__biometricsHeaderActionItems___-lWW0 .cds--content-switcher {\n  max-width: max-content;\n}\n.-esm-patient-vitals__biometrics-base__biometricsHeaderActionItems___-lWW0 .cds--content-switcher .cds--content-switcher__label {\n  height: 1rem;\n}\n\n.-esm-patient-vitals__biometrics-base__divider___AfR6V {\n  width: 1px;\n  height: 1rem;\n  color: #161616;\n  margin: 0 1rem;\n}\n\n.-esm-patient-vitals__biometrics-base__backgroundDataFetchingIndicator___kgxNR {\n  align-items: center;\n  display: flex;\n  flex: 1 1 0%;\n  justify-content: end;\n}\n\n.-esm-patient-vitals__biometrics-base__introBox___hceTn {\n  background: #f0f6ff;\n  border: 1px solid #2f80ed;\n  border-radius: 8px;\n  padding: 1rem;\n  margin-bottom: 1rem;\n  max-width: 100%;\n}\n\n.-esm-patient-vitals__biometrics-base__introText___Ilt\\+p {\n  font-size: var(--cds-body-01-font-size, 0.875rem);\n  font-weight: var(--cds-body-01-font-weight, 400);\n  line-height: var(--cds-body-01-line-height, 1.42857);\n  letter-spacing: var(--cds-body-01-letter-spacing, 0.16px);\n  color: #161616;\n  line-height: 1.6;\n  margin: 0;\n  white-space: normal;\n  word-break: break-word;\n}\n\n.-esm-patient-vitals__biometrics-base__headerItems___KSv3p {\n  display: flex;\n  align-items: baseline;\n  flex-flow: row wrap;\n  gap: 0.25rem 0.75rem;\n}\n\n.-esm-patient-vitals__biometrics-base__heading___nLZPG {\n  font-size: var(--cds-heading-compact-02-font-size, 1rem);\n  font-weight: var(--cds-heading-compact-02-font-weight, 600);\n  line-height: var(--cds-heading-compact-02-line-height, 1.375);\n  letter-spacing: var(--cds-heading-compact-02-letter-spacing, 0);\n  /* Carbon Design's compact heading style */\n  color: #161616 !important; /* Light text color for contrast */\n  text-align: center; /* Center the text */\n  padding: 0.5rem 1rem; /* Add padding around the text */\n  margin-bottom: 1rem; /* Margin below the heading */\n  background-color: #cadbf4; /* Light blue background */\n  border: 2px solid #1e6ed6; /* Darker blue border for contrast */\n  border-radius: 8px; /* Optional rounded corners */\n  box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1); /* Light shadow for depth */\n  max-width: 100%; /* Prevent overflow */\n  word-wrap: break-word; /* Prevent text overflow */\n  font-weight: bolder;\n  /* Default font size */\n  font-size: 1.2rem; /* Smaller font size for desktop (about 19px) */\n  /* Responsive adjustments */\n}\n@media (max-width: 768px) {\n  .-esm-patient-vitals__biometrics-base__heading___nLZPG {\n    font-size: 1rem; /* Smaller font size for tablets (about 16px) */\n    padding: 0.25rem 0.75rem; /* Adjust padding for smaller screens */\n  }\n}\n@media (max-width: 480px) {\n  .-esm-patient-vitals__biometrics-base__heading___nLZPG {\n    font-size: 0.875rem; /* Font size for mobile (about 14px) */\n    padding: 0.25rem; /* Less padding on small screens */\n  }\n}", "",{"version":3,"sources":["webpack://./../../node_modules/@openmrs/esm-styleguide/src/_vars.scss","webpack://./src/biometrics/biometrics-base.scss","webpack://./../../node_modules/@carbon/layout/scss/generated/_spacing.scss","webpack://./../../node_modules/@carbon/type/scss/_styles.scss"],"names":[],"mappings":"AAkCA,0EAAA;AAoBA;EACE,mBAAA;EACA,mBAAA;EACA,mBAAA;EACA,yBAAA;EACA,+BAAA;EACA,oGAAA;EACA,2GAAA;ACpDF;;ADgEA,8DAAA;ACrEA;EACE,yBAAA;EACA,yBDHM;ACYR;;AANA;EACE,yBAAA;EACA,yBAAA;EACA,mBAAA;EACA,sBAAA;EACA,cAAA;EACA,wCAAA;EACA,qBAAA;EACA,eAAA;EACA,gBAAA;AASF;AAPE;EACE,gBAAA;AASJ;AANE;EACE,cAAA;EACA,gBAAA;EACA,gBAAA;AAQJ;AALE;EACE,mBAAA;EACA,qBAAA;AAOJ;;AAHA;EACE,mBAAA;EACA,aAAA;EACA,YAAA;EACA,oBAAA;AAMF;AAJE;EACE,sBAAA;AAMJ;AAJI;EACE,YCfO;ADqBb;;AADA;EACE,UAAA;EACA,YCtBW;EDuBX,cDhDM;ECiDN,cAAA;AAIF;;AADA;EACE,mBAAA;EACA,aAAA;EACA,YAAA;EACA,oBAAA;AAIF;;AADA;EACE,mBAAA;EACA,yBAAA;EACA,kBAAA;EACA,aAAA;EACA,mBAAA;EACA,eAAA;AAIF;;AADA;EEwxBI,iDAAA;EAAA,gDAAA;EAAA,oDAAA;EAAA,yDAAA;EFtxBF,cDtEM;ECuEN,gBAAA;EACA,SAAA;EACA,mBAAA;EACA,sBAAA;AAOF;;AAJA;EACE,aAAA;EACA,qBAAA;EACA,mBAAA;EACA,oBAAA;AAOF;;AAJA;EEwwBI,wDAAA;EAAA,2DAAA;EAAA,6DAAA;EAAA,+DAAA;EFvwB8C,0CAAA;EAChD,yBAAA,EAAA,kCAAA;EACA,kBAAA,EAAA,oBAAA;EACA,oBAAA,EAAA,gCAAA;EACA,mBChEW,EDgEwB,6BAAA;EACnC,yBAAA,EAAA,0BAAA;EACA,yBAAA,EAAA,oCAAA;EACA,kBAAA,EAAA,6BAAA;EACA,wCAAA,EAAA,2BAAA;EACA,eAAA,EAAA,qBAAA;EACA,qBAAA,EAAA,0BAAA;EACA,mBAAA;EACA,sBAAA;EACA,iBAAA,EAAA,+CAAA;EAEA,2BAAA;AAUF;AATE;EAjBF;IAkBI,eAAA,EAAA,+CAAA;IACA,wBAAA,EAAA,uCAAA;EAYF;AACF;AAVE;EAtBF;IAuBI,mBAAA,EAAA,sCAAA;IACA,gBClGS,EDkGoB,kCAAA;EAa/B;AACF","sourcesContent":["@use '@carbon/layout';\n\n$ui-01: #f4f4f4;\n$ui-02: #ffffff;\n$ui-03: #e0e0e0;\n$ui-04: #8d8d8d;\n$ui-05: #161616;\n$text-02: #525252;\n$text-03: #a8a8a8;\n$ui-background: #ffffff;\n$color-gray-30: #c6c6c6;\n$color-gray-70: #525252;\n$color-gray-100: #161616;\n$color-blue-60-2: #0f62fe;\n$color-blue-10: #edf5ff;\n$color-yellow-50: #feecae;\n$carbon--red-50: #fa4d56;\n$inverse-link: #78a9ff;\n$support-02: #24a148;\n$inverse-support-03: #f1c21b;\n$warning-background: #fff8e1;\n$openmrs-background-grey: #f4f4f4;\n$danger: #da1e28;\n$interactive-01: #0f62fe;\n$field-01: #f4f4f4;\n$grey-2: #e0e0e0;\n$labeldropdown: #c6c6c6;\n\n$brand-primary-10: #d9fbfb;\n$brand-primary-20: #9ef0f0;\n$brand-primary-30: #3ddbd9;\n$brand-primary-40: #08bdba;\n$brand-primary-50: #009d9a;\n\n/* 60,70 and 80 are already declared as brand-01, 02 and 03 respectively */\n\n$brand-primary-90: #022b30;\n$brand-primary-100: #081a1c;\n\n@mixin brand-01($property) {\n  #{$property}: #005d5d;\n  #{$property}: var(--brand-01);\n}\n\n@mixin brand-02($property) {\n  #{$property}: #004144;\n  #{$property}: var(--brand-02);\n}\n\n@mixin brand-03($property) {\n  #{$property}: #007d79;\n  #{$property}: var(--brand-03);\n}\n\n:root {\n  --brand-01: #005d5d;\n  --brand-02: #004144;\n  --brand-03: #007d79;\n  --bottom-nav-height: #{layout.$spacing-10};\n  --workspace-header-height: #{layout.$spacing-09};\n  --tablet-workspace-window-height: calc(100vh - var(--omrs-navbar-height) - var(--bottom-nav-height));\n  --desktop-workspace-window-height: calc(100vh - var(--omrs-navbar-height) - var(--workspace-header-height));\n}\n\n$breakpoint-phone-min: 0px;\n$breakpoint-phone-max: 600px;\n$breakpoint-tablet-min: 601px;\n$breakpoint-tablet-max: 1023px;\n$breakpoint-small-desktop-min: 1024px;\n$breakpoint-small-desktop-max: 1439px;\n$breakpoint-large-desktop-min: 1440px;\n$breakpoint-large-desktop-max: 99999999px;\n\n/* These color variables will be removed in a future release */\n$brand-teal-01: #007d79;\n$brand-01: #005d5d;\n$brand-02: #004144;\n","@use '@carbon/layout';\r\n@use '@openmrs/esm-styleguide/src/vars' as *;\r\n@use '@carbon/type' as type;\r\n\r\n.widgetCard {\r\n  border: 1px solid $ui-03;\r\n  background-color: $ui-02;\r\n}\r\n\r\n.activitiesText {\r\n  background-color: #f0f4ff; // Light blue background\r\n  border: 2px solid #2f80ed; // Dark blue border\r\n  border-radius: 10px;\r\n  padding: 1.2rem 1.5rem;\r\n  margin: 1rem 0;\r\n  box-shadow: 0 3px 8px rgba(0, 0, 0, 0.1);\r\n  word-wrap: break-word;\r\n  font-size: 1rem;\r\n  line-height: 1.6;\r\n\r\n  p {\r\n    margin: 0.3rem 0;\r\n  }\r\n\r\n  strong {\r\n    display: block;\r\n    font-weight: 600;\r\n    margin: 0.5rem 0;\r\n  }\r\n\r\n  li {\r\n    margin-left: 1.5rem;\r\n    list-style-type: disc;\r\n  }\r\n}\r\n\r\n.biometricsHeaderActionItems {\r\n  align-items: center;\r\n  display: flex;\r\n  flex: 1 1 0%;\r\n  justify-content: end;\r\n\r\n  & :global(.cds--content-switcher) {\r\n    max-width: max-content;\r\n\r\n    :global(.cds--content-switcher__label) {\r\n      height: layout.$spacing-05;\r\n    }\r\n  }\r\n}\r\n\r\n.divider {\r\n  width: 1px;\r\n  height: layout.$spacing-05;\r\n  color: $ui-05;\r\n  margin: 0 layout.$spacing-05;\r\n}\r\n\r\n.backgroundDataFetchingIndicator {\r\n  align-items: center;\r\n  display: flex;\r\n  flex: 1 1 0%;\r\n  justify-content: end;\r\n}\r\n\r\n.introBox {\r\n  background: #f0f6ff;\r\n  border: 1px solid #2f80ed;\r\n  border-radius: 8px;\r\n  padding: 1rem;\r\n  margin-bottom: 1rem;\r\n  max-width: 100%;\r\n}\r\n\r\n.introText {\r\n  @include type.type-style('body-01');\r\n  color: $ui-05;\r\n  line-height: 1.6;\r\n  margin: 0;\r\n  white-space: normal;\r\n  word-break: break-word;\r\n}\r\n\r\n.headerItems {\r\n  display: flex;\r\n  align-items: baseline;\r\n  flex-flow: row wrap;\r\n  gap: layout.$spacing-02 layout.$spacing-04;\r\n}\r\n\r\n.heading {\r\n  @include type.type-style('heading-compact-02'); /* Carbon Design's compact heading style */\r\n  color: $ui-05 !important; /* Light text color for contrast */\r\n  text-align: center; /* Center the text */\r\n  padding: layout.$spacing-03 layout.$spacing-05; /* Add padding around the text */\r\n  margin-bottom: layout.$spacing-05; /* Margin below the heading */\r\n  background-color: #cadbf4; /* Light blue background */\r\n  border: 2px solid #1e6ed6; /* Darker blue border for contrast */\r\n  border-radius: 8px; /* Optional rounded corners */\r\n  box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1); /* Light shadow for depth */\r\n  max-width: 100%; /* Prevent overflow */\r\n  word-wrap: break-word; /* Prevent text overflow */\r\n  font-weight: bolder;\r\n  /* Default font size */\r\n  font-size: 1.2rem; /* Smaller font size for desktop (about 19px) */\r\n\r\n  /* Responsive adjustments */\r\n  @media (max-width: 768px) {\r\n    font-size: 1rem; /* Smaller font size for tablets (about 16px) */\r\n    padding: layout.$spacing-02 layout.$spacing-04; /* Adjust padding for smaller screens */\r\n  }\r\n\r\n  @media (max-width: 480px) {\r\n    font-size: 0.875rem; /* Font size for mobile (about 14px) */\r\n    padding: layout.$spacing-02; /* Less padding on small screens */\r\n  }\r\n}\r\n","// Code generated by @carbon/layout. DO NOT EDIT.\n//\n// Copyright IBM Corp. 2018, 2023\n//\n// This source code is licensed under the Apache-2.0 license found in the\n// LICENSE file in the root directory of this source tree.\n//\n\n/// @type Number\n/// @access public\n/// @group @carbon/layout\n$spacing-01: 0.125rem !default;\n\n/// @type Number\n/// @access public\n/// @group @carbon/layout\n$spacing-02: 0.25rem !default;\n\n/// @type Number\n/// @access public\n/// @group @carbon/layout\n$spacing-03: 0.5rem !default;\n\n/// @type Number\n/// @access public\n/// @group @carbon/layout\n$spacing-04: 0.75rem !default;\n\n/// @type Number\n/// @access public\n/// @group @carbon/layout\n$spacing-05: 1rem !default;\n\n/// @type Number\n/// @access public\n/// @group @carbon/layout\n$spacing-06: 1.5rem !default;\n\n/// @type Number\n/// @access public\n/// @group @carbon/layout\n$spacing-07: 2rem !default;\n\n/// @type Number\n/// @access public\n/// @group @carbon/layout\n$spacing-08: 2.5rem !default;\n\n/// @type Number\n/// @access public\n/// @group @carbon/layout\n$spacing-09: 3rem !default;\n\n/// @type Number\n/// @access public\n/// @group @carbon/layout\n$spacing-10: 4rem !default;\n\n/// @type Number\n/// @access public\n/// @group @carbon/layout\n$spacing-11: 5rem !default;\n\n/// @type Number\n/// @access public\n/// @group @carbon/layout\n$spacing-12: 6rem !default;\n\n/// @type Number\n/// @access public\n/// @group @carbon/layout\n$spacing-13: 10rem !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/layout\n$spacing: (\n  spacing-01: $spacing-01,\n  spacing-02: $spacing-02,\n  spacing-03: $spacing-03,\n  spacing-04: $spacing-04,\n  spacing-05: $spacing-05,\n  spacing-06: $spacing-06,\n  spacing-07: $spacing-07,\n  spacing-08: $spacing-08,\n  spacing-09: $spacing-09,\n  spacing-10: $spacing-10,\n  spacing-11: $spacing-11,\n  spacing-12: $spacing-12,\n  spacing-13: $spacing-13,\n);\n","//\n// Copyright IBM Corp. 2018, 2023\n//\n// This source code is licensed under the Apache-2.0 license found in the\n// LICENSE file in the root directory of this source tree.\n//\n\n// stylelint-disable number-max-precision\n\n@use 'sass:map';\n@use 'sass:math';\n@use '@carbon/grid/scss/config' as gridconfig;\n@use '@carbon/grid/scss/breakpoint' as grid;\n@use 'prefix' as *;\n@use 'font-family';\n@use 'scale';\n\n/// @type Map\n/// @access public\n/// @deprecated\n/// @group @carbon/type\n$caption-01: (\n  font-size: scale.type-scale(1),\n  font-weight: font-family.font-weight('regular'),\n  line-height: 1.33333,\n  letter-spacing: 0.32px,\n) !default;\n\n/// @type Map\n/// @access public\n/// @deprecated\n/// @group @carbon/type\n$caption-02: (\n  font-size: scale.type-scale(2),\n  font-weight: font-family.font-weight('regular'),\n  line-height: 1.28572,\n  letter-spacing: 0.32px,\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$label-01: (\n  font-size: scale.type-scale(1),\n  font-weight: font-family.font-weight('regular'),\n  line-height: 1.33333,\n  letter-spacing: 0.32px,\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$label-02: (\n  font-size: scale.type-scale(2),\n  font-weight: font-family.font-weight('regular'),\n  line-height: 1.28572,\n  letter-spacing: 0.16px,\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$legal-01: (\n  font-size: scale.type-scale(1),\n  font-weight: font-family.font-weight('regular'),\n  line-height: 1.33333,\n  letter-spacing: 0.32px,\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$legal-02: (\n  font-size: scale.type-scale(2),\n  font-weight: font-family.font-weight('regular'),\n  line-height: 1.28572,\n  letter-spacing: 0.16px,\n) !default;\n\n/// @type Map\n/// @access public\n/// @deprecated\n/// @group @carbon/type\n$helper-text-01: (\n  font-size: scale.type-scale(1),\n  line-height: 1.33333,\n  letter-spacing: 0.32px,\n) !default;\n\n/// @type Map\n/// @access public\n/// @deprecated\n/// @group @carbon/type\n$helper-text-02: (\n  font-size: scale.type-scale(2),\n  font-weight: font-family.font-weight('regular'),\n  line-height: 1.28572,\n  letter-spacing: 0.16px,\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$body-short-01: (\n  font-size: scale.type-scale(2),\n  font-weight: font-family.font-weight('regular'),\n  line-height: 1.28572,\n  letter-spacing: 0.16px,\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$body-compact-01: $body-short-01 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$body-long-01: (\n  font-size: scale.type-scale(2),\n  font-weight: font-family.font-weight('regular'),\n  line-height: 1.42857,\n  letter-spacing: 0.16px,\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$body-01: $body-long-01 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$body-short-02: (\n  font-size: scale.type-scale(3),\n  font-weight: font-family.font-weight('regular'),\n  line-height: 1.375,\n  letter-spacing: 0,\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$body-compact-02: $body-short-02 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$body-long-02: (\n  font-size: scale.type-scale(3),\n  font-weight: font-family.font-weight('regular'),\n  line-height: 1.5,\n  letter-spacing: 0,\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$body-02: $body-long-02 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$code-01: (\n  font-family: font-family.font-family('mono'),\n  font-size: scale.type-scale(1),\n  font-weight: font-family.font-weight('regular'),\n  line-height: 1.33333,\n  letter-spacing: 0.32px,\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$code-02: (\n  font-family: font-family.font-family('mono'),\n  font-size: scale.type-scale(2),\n  font-weight: font-family.font-weight('regular'),\n  line-height: 1.42857,\n  letter-spacing: 0.32px,\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$heading-01: (\n  font-size: scale.type-scale(2),\n  font-weight: font-family.font-weight('semibold'),\n  line-height: 1.42857,\n  letter-spacing: 0.16px,\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$productive-heading-01: (\n  font-size: scale.type-scale(2),\n  font-weight: font-family.font-weight('semibold'),\n  line-height: 1.28572,\n  letter-spacing: 0.16px,\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$heading-compact-01: $productive-heading-01 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$heading-02: (\n  font-size: scale.type-scale(3),\n  font-weight: font-family.font-weight('semibold'),\n  line-height: 1.5,\n  letter-spacing: 0,\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$productive-heading-02: (\n  font-size: scale.type-scale(3),\n  font-weight: font-family.font-weight('semibold'),\n  line-height: 1.375,\n  letter-spacing: 0,\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$heading-compact-02: $productive-heading-02 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$productive-heading-03: (\n  font-size: scale.type-scale(5),\n  font-weight: font-family.font-weight('regular'),\n  line-height: 1.4,\n  letter-spacing: 0,\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$heading-03: $productive-heading-03 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$productive-heading-04: (\n  font-size: scale.type-scale(7),\n  font-weight: font-family.font-weight('regular'),\n  line-height: 1.28572,\n  letter-spacing: 0,\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$heading-04: $productive-heading-04 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$productive-heading-05: (\n  font-size: scale.type-scale(8),\n  font-weight: font-family.font-weight('regular'),\n  line-height: 1.25,\n  letter-spacing: 0,\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$heading-05: $productive-heading-05 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$productive-heading-06: (\n  font-size: scale.type-scale(10),\n  font-weight: font-family.font-weight('light'),\n  // Extra digit needed for precision in Chrome\n  line-height: 1.199,\n  letter-spacing: 0,\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$heading-06: $productive-heading-06 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$productive-heading-07: (\n  font-size: scale.type-scale(12),\n  font-weight: font-family.font-weight('light'),\n  line-height: 1.19,\n  letter-spacing: 0,\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$heading-07: $productive-heading-07 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$expressive-heading-01: $heading-01 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$expressive-heading-02: $heading-02 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$expressive-heading-03: (\n  font-size: scale.type-scale(5),\n  font-weight: font-family.font-weight('regular'),\n  line-height: 1.4,\n  letter-spacing: 0,\n  breakpoints: (\n    xlg: (\n      font-size: scale.type-scale(5),\n      line-height: 1.4,\n    ),\n    max: (\n      font-size: scale.type-scale(6),\n      line-height: 1.334,\n    ),\n  ),\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$fluid-heading-03: $expressive-heading-03 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$expressive-heading-04: (\n  font-size: scale.type-scale(7),\n  font-weight: font-family.font-weight('regular'),\n  line-height: 1.28572,\n  letter-spacing: 0,\n  breakpoints: (\n    xlg: (\n      font-size: scale.type-scale(8),\n      line-height: 1.25,\n      font-weight: font-family.font-weight('regular'),\n    ),\n    max: (\n      font-size: scale.type-scale(8),\n      font-weight: font-family.font-weight('regular'),\n    ),\n  ),\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$fluid-heading-04: $expressive-heading-04 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$expressive-heading-05: (\n  font-size: scale.type-scale(8),\n  font-weight: font-family.font-weight('regular'),\n  line-height: 1.25,\n  letter-spacing: 0,\n  breakpoints: (\n    md: (\n      font-size: scale.type-scale(9),\n      font-weight: font-family.font-weight('light'),\n      line-height: 1.22,\n    ),\n    lg: (\n      font-size: scale.type-scale(10),\n      line-height: 1.19,\n    ),\n    xlg: (\n      font-size: scale.type-scale(11),\n      line-height: 1.17,\n    ),\n    max: (\n      font-size: scale.type-scale(13),\n    ),\n  ),\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$fluid-heading-05: $expressive-heading-05 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$expressive-heading-06: (\n  font-size: scale.type-scale(8),\n  font-weight: font-family.font-weight('semibold'),\n  line-height: 1.25,\n  letter-spacing: 0,\n  breakpoints: (\n    md: (\n      font-size: scale.type-scale(9),\n      line-height: 1.22,\n    ),\n    lg: (\n      font-size: scale.type-scale(10),\n      line-height: 1.19,\n    ),\n    xlg: (\n      font-size: scale.type-scale(11),\n      line-height: 1.17,\n    ),\n    max: (\n      font-size: scale.type-scale(13),\n    ),\n  ),\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$fluid-heading-06: $expressive-heading-06 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$expressive-paragraph-01: (\n  font-size: scale.type-scale(6),\n  font-weight: font-family.font-weight('light'),\n  line-height: 1.334,\n  letter-spacing: 0,\n  breakpoints: (\n    lg: (\n      font-size: scale.type-scale(7),\n      line-height: 1.28572,\n    ),\n    max: (\n      font-size: scale.type-scale(8),\n      line-height: 1.25,\n    ),\n  ),\n);\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$fluid-paragraph-01: $expressive-paragraph-01 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$quotation-01: (\n  font-family: font-family.font-family('serif'),\n  font-size: scale.type-scale(5),\n  font-weight: font-family.font-weight('regular'),\n  line-height: 1.3,\n  letter-spacing: 0,\n  breakpoints: (\n    md: (\n      font-size: scale.type-scale(5),\n    ),\n    lg: (\n      font-size: scale.type-scale(6),\n      line-height: 1.334,\n    ),\n    xlg: (\n      font-size: scale.type-scale(7),\n      line-height: 1.28572,\n    ),\n    max: (\n      font-size: scale.type-scale(8),\n      line-height: 1.25,\n    ),\n  ),\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$fluid-quotation-01: $quotation-01 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$quotation-02: (\n  font-family: font-family.font-family('serif'),\n  font-size: scale.type-scale(8),\n  font-weight: font-family.font-weight('light'),\n  line-height: 1.25,\n  letter-spacing: 0,\n  breakpoints: (\n    md: (\n      font-size: scale.type-scale(9),\n      line-height: 1.22,\n    ),\n    lg: (\n      font-size: scale.type-scale(10),\n      line-height: 1.19,\n    ),\n    xlg: (\n      font-size: scale.type-scale(11),\n      line-height: 1.17,\n    ),\n    max: (\n      font-size: scale.type-scale(13),\n    ),\n  ),\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$fluid-quotation-02: $quotation-02 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$display-01: (\n  font-size: scale.type-scale(10),\n  font-weight: font-family.font-weight('light'),\n  line-height: 1.19,\n  letter-spacing: 0,\n  breakpoints: (\n    md: (\n      font-size: scale.type-scale(10),\n    ),\n    lg: (\n      font-size: scale.type-scale(12),\n    ),\n    xlg: (\n      font-size: scale.type-scale(13),\n      line-height: 1.17,\n    ),\n    max: (\n      font-size: scale.type-scale(15),\n      line-height: 1.13,\n    ),\n  ),\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$fluid-display-01: $display-01 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$display-02: (\n  font-size: scale.type-scale(10),\n  font-weight: font-family.font-weight('semibold'),\n  line-height: 1.19,\n  letter-spacing: 0,\n  breakpoints: (\n    md: (\n      font-size: scale.type-scale(10),\n    ),\n    lg: (\n      font-size: scale.type-scale(12),\n    ),\n    xlg: (\n      font-size: scale.type-scale(13),\n      line-height: 1.16,\n    ),\n    max: (\n      font-size: scale.type-scale(15),\n      line-height: 1.13,\n    ),\n  ),\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$fluid-display-02: $display-02 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$display-03: (\n  font-size: scale.type-scale(10),\n  font-weight: font-family.font-weight('light'),\n  line-height: 1.19,\n  letter-spacing: 0,\n  breakpoints: (\n    md: (\n      font-size: scale.type-scale(12),\n      line-height: 1.18,\n    ),\n    lg: (\n      font-size: scale.type-scale(13),\n      line-height: 1.16,\n      letter-spacing: -0.64px,\n    ),\n    xlg: (\n      font-size: scale.type-scale(15),\n      line-height: 1.13,\n      letter-spacing: -0.64px,\n    ),\n    max: (\n      font-size: scale.type-scale(16),\n      line-height: 1.11,\n      letter-spacing: -0.96px,\n    ),\n  ),\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$fluid-display-03: $display-03 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$display-04: (\n  font-size: scale.type-scale(10),\n  font-weight: font-family.font-weight('light'),\n  line-height: 1.19,\n  letter-spacing: 0,\n  breakpoints: (\n    md: (\n      font-size: scale.type-scale(14),\n      line-height: 1.15,\n    ),\n    lg: (\n      font-size: scale.type-scale(17),\n      line-height: 1.11,\n      letter-spacing: -0.64px,\n    ),\n    xlg: (\n      font-size: scale.type-scale(20),\n      line-height: 1.07,\n      letter-spacing: -0.64px,\n    ),\n    max: (\n      font-size: scale.type-scale(23),\n      line-height: 1.05,\n      letter-spacing: -0.96px,\n    ),\n  ),\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$fluid-display-04: $display-04 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$tokens: (\n  caption-01: $caption-01,\n  caption-02: $caption-02,\n  label-01: $label-01,\n  label-02: $label-02,\n  helper-text-01: $helper-text-01,\n  helper-text-02: $helper-text-02,\n  body-short-01: $body-short-01,\n  body-short-02: $body-short-02,\n  body-long-01: $body-long-01,\n  body-long-02: $body-long-02,\n  code-01: $code-01,\n  code-02: $code-02,\n  heading-01: $heading-01,\n  heading-02: $heading-02,\n  productive-heading-01: $productive-heading-01,\n  productive-heading-02: $productive-heading-02,\n  productive-heading-03: $productive-heading-03,\n  productive-heading-04: $productive-heading-04,\n  productive-heading-05: $productive-heading-05,\n  productive-heading-06: $productive-heading-06,\n  productive-heading-07: $productive-heading-07,\n  expressive-paragraph-01: $expressive-paragraph-01,\n  expressive-heading-01: $expressive-heading-01,\n  expressive-heading-02: $expressive-heading-02,\n  expressive-heading-03: $expressive-heading-03,\n  expressive-heading-04: $expressive-heading-04,\n  expressive-heading-05: $expressive-heading-05,\n  expressive-heading-06: $expressive-heading-06,\n  quotation-01: $quotation-01,\n  quotation-02: $quotation-02,\n  display-01: $display-01,\n  display-02: $display-02,\n  display-03: $display-03,\n  display-04: $display-04,\n  // V11 Tokens\n  legal-01: $legal-01,\n  legal-02: $legal-02,\n  body-compact-01: $body-compact-01,\n  body-compact-02: $body-compact-02,\n  heading-compact-01: $heading-compact-01,\n  heading-compact-02: $heading-compact-02,\n  body-01: $body-01,\n  body-02: $body-02,\n  heading-03: $heading-03,\n  heading-04: $heading-04,\n  heading-05: $heading-05,\n  heading-06: $heading-06,\n  heading-07: $heading-07,\n  fluid-heading-03: $fluid-heading-03,\n  fluid-heading-04: $fluid-heading-04,\n  fluid-heading-05: $fluid-heading-05,\n  fluid-heading-06: $fluid-heading-06,\n  fluid-paragraph-01: $fluid-paragraph-01,\n  fluid-quotation-01: $fluid-quotation-01,\n  fluid-quotation-02: $fluid-quotation-02,\n  fluid-display-01: $fluid-display-01,\n  fluid-display-02: $fluid-display-02,\n  fluid-display-03: $fluid-display-03,\n  fluid-display-04: $fluid-display-04,\n) !default;\n\n/// @param {Map} $map\n/// @access public\n/// @group @carbon/type\n@mixin properties($map) {\n  @each $name, $value in $map {\n    #{$name}: $value;\n  }\n}\n\n/// @param {Number} $value - Number with units\n/// @return {Number} Without units\n/// @access public\n/// @group @carbon/type\n@function strip-unit($value) {\n  @return math.div($value, $value * 0 + 1);\n}\n\n/// This helper includes fluid type styles for the given token value. Fluid type\n/// means that the `font-size` is computed using `calc()` in order to be\n/// determined by the screen size instead of a breakpoint. As a result, fluid\n/// styles should be used with caution in fixed width contexts.\n///\n/// In addition, we make use of %-based line-heights so that the line-height of\n/// each type style is computed correctly due to the dynamic nature of the\n/// `font-size`.\n///\n/// Most of the logic for this work comes from CSS Tricks:\n/// https://css-tricks.com/snippets/css/fluid-typography/\n///\n/// @param {Map} $type-styles - The value of a given type token\n/// @param {Map} $breakpoints [$grid-breakpoints] - Custom breakpoints to use\n/// @access public\n/// @group @carbon/type\n@mixin fluid-type($type-styles, $breakpoints: gridconfig.$grid-breakpoints) {\n  // Include the initial styles for the given token by default without any\n  // media query guard. This includes `font-size` as a fallback in the case\n  // that a browser does not support `calc()`\n  @include properties(map.remove($type-styles, breakpoints));\n  // We also need to include the `sm` styles by default since they don't\n  // appear in the fluid styles for tokens\n  @include fluid-type-size($type-styles, sm, $breakpoints);\n\n  // Finally, we need to go through all the breakpoints defined in the type\n  // token and apply the properties and fluid type size for that given\n  // breakpoint\n  @each $name, $values in map.get($type-styles, breakpoints) {\n    @include grid.breakpoint($name) {\n      @include properties($values);\n      @include fluid-type-size($type-styles, $name, $breakpoints);\n    }\n  }\n}\n\n/// Computes the fluid `font-size` for a given type style and breakpoint\n/// @param {Map} $type-styles - The styles for a given token\n/// @param {String} $name - The name of the breakpoint to which we apply the fluid\n/// @param {Map} $breakpoints [$grid-breakpoints] - The breakpoints for the grid system\n/// @access public\n/// @group @carbon/type\n@mixin fluid-type-size(\n  $type-styles,\n  $name,\n  $breakpoints: gridconfig.$grid-breakpoints\n) {\n  // Get the information about the breakpoint we're currently working in. Useful\n  // for getting initial width information\n  $breakpoint: map.get($breakpoints, $name);\n\n  // Our fluid styles are captured under the 'breakpoints' property in our type\n  // styles map. These define what values to treat as `max-` variables below\n  $fluid-sizes: map.get($type-styles, breakpoints);\n  $fluid-breakpoint: ();\n  // Special case for `sm` because the styles for small are on the type style\n  // directly\n  @if $name == sm {\n    $fluid-breakpoint: map.remove($type-styles, breakpoints);\n  } @else {\n    $fluid-breakpoint: map.get($fluid-sizes, $name);\n  }\n\n  // Initialize our font-sizes to the default size for the type style\n  $max-font-size: map.get($type-styles, font-size);\n  $min-font-size: map.get($type-styles, font-size);\n  @if map.has-key($fluid-breakpoint, font-size) {\n    $min-font-size: map.get($fluid-breakpoint, font-size);\n  }\n\n  // Initialize our min and max width to the width of the current breakpoint\n  $max-vw: map.get($breakpoint, width);\n  $min-vw: map.get($breakpoint, width);\n\n  // We can use `breakpoint-next` to see if there is another breakpoint we can\n  // use to update `max-font-size` and `max-vw` with larger values\n  $next-breakpoint-available: grid.breakpoint-next($name, $breakpoints);\n  $next-fluid-breakpoint-name: null;\n\n  // We need to figure out what the next available fluid breakpoint is for our\n  // given $type-styles. In this loop we try and iterate through breakpoints\n  // until we either manually set $next-breakpoint-available to null or\n  // `breakpoint-next` returns null.\n  @while $next-breakpoint-available {\n    @if map.has-key($fluid-sizes, $next-breakpoint-available) {\n      $next-fluid-breakpoint-name: $next-breakpoint-available;\n      $next-breakpoint-available: null;\n    } @else {\n      $next-breakpoint-available: grid.breakpoint-next(\n        $next-breakpoint-available,\n        $breakpoints\n      );\n    }\n  }\n\n  // If we have found the next available fluid breakpoint name, then we know\n  // that we have values that we can use to set max-font-size and max-vw as both\n  // values derive from the next breakpoint\n  @if $next-fluid-breakpoint-name {\n    $next-fluid-breakpoint: map.get($breakpoints, $next-fluid-breakpoint-name);\n    $max-font-size: map.get(\n      map.get($fluid-sizes, $next-fluid-breakpoint-name),\n      font-size\n    );\n    $max-vw: map.get($next-fluid-breakpoint, width);\n\n    // prettier-ignore\n    font-size: calc(#{$min-font-size} +\n      #{strip-unit($max-font-size - $min-font-size)} *\n      ((100vw - #{$min-vw}) / #{strip-unit($max-vw - $min-vw)})\n    );\n  } @else {\n    // Otherwise, just default to setting the font size found from the type\n    // style or the given fluid breakpoint in the type style\n    font-size: $min-font-size;\n  }\n}\n\n// TODO move following variable and `custom-property` mixin into shared file for\n// both `@carbon/type` and `@carbon/themes`\n\n/// @access private\n/// @group @carbon/type\n@mixin custom-properties($name, $value) {\n  @each $property, $value in $value {\n    #{$property}: var(\n      --#{$custom-property-prefix}-#{$name}-#{$property},\n      #{$value}\n    );\n  }\n}\n\n/// Helper mixin to include the styles for a given token in any selector in your\n/// project. Also includes an optional fluid option that will enable fluid\n/// styles for the token if they are defined. Fluid styles will cause the\n/// token's font-size to be computed based on the viewport size. As a result, use\n/// with caution in fixed contexts.\n/// @param {String} $name - The name of the token to get the styles for\n/// @param {Boolean} $fluid [false] - Specify whether to include fluid styles for the\n/// @param {Map} $breakpoints [$grid-breakpoints] - Provide a custom breakpoint map to use\n/// @access public\n/// @group @carbon/type\n@mixin type-style(\n  $name,\n  $fluid: false,\n  $breakpoints: gridconfig.$grid-breakpoints\n) {\n  @if not map.has-key($tokens, $name) {\n    @error 'Unable to find a token with the name: `#{$name}`';\n  }\n\n  $token: map.get($tokens, $name);\n\n  // If $fluid is set to true and the token has breakpoints defined for fluid\n  // styles, delegate to the fluid-type helper for the given token\n  @if $fluid == true and map.has-key($token, 'breakpoints') {\n    @include fluid-type($token, $breakpoints);\n  } @else {\n    @include custom-properties($name, $token);\n  }\n}\n"],"sourceRoot":""}]);
// Exports
___CSS_LOADER_EXPORT___.locals = {
	"widgetCard": "-esm-patient-vitals__biometrics-base__widgetCard___2dWUk",
	"activitiesText": "-esm-patient-vitals__biometrics-base__activitiesText___td-Wu",
	"biometricsHeaderActionItems": "-esm-patient-vitals__biometrics-base__biometricsHeaderActionItems___-lWW0",
	"divider": "-esm-patient-vitals__biometrics-base__divider___AfR6V",
	"backgroundDataFetchingIndicator": "-esm-patient-vitals__biometrics-base__backgroundDataFetchingIndicator___kgxNR",
	"introBox": "-esm-patient-vitals__biometrics-base__introBox___hceTn",
	"introText": "-esm-patient-vitals__biometrics-base__introText___Ilt+p",
	"headerItems": "-esm-patient-vitals__biometrics-base__headerItems___KSv3p",
	"heading": "-esm-patient-vitals__biometrics-base__heading___nLZPG"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "../../node_modules/openmrs/node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[2].use[1]!../../node_modules/openmrs/node_modules/sass-loader/dist/cjs.js??ruleSet[1].rules[2].use[2]!./src/components/action-menu/vitals-biometrics-action-menu.scss":
/*!**************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ../../node_modules/openmrs/node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[2].use[1]!../../node_modules/openmrs/node_modules/sass-loader/dist/cjs.js??ruleSet[1].rules[2].use[2]!./src/components/action-menu/vitals-biometrics-action-menu.scss ***!
  \**************************************************************************************************************************************************************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_openmrs_node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../../../node_modules/openmrs/node_modules/css-loader/dist/runtime/cssWithMappingToString.js */ "../../node_modules/openmrs/node_modules/css-loader/dist/runtime/cssWithMappingToString.js");
/* harmony import */ var _node_modules_openmrs_node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_openmrs_node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_openmrs_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../../../node_modules/openmrs/node_modules/css-loader/dist/runtime/api.js */ "../../node_modules/openmrs/node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_openmrs_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_openmrs_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_openmrs_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_openmrs_node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0___default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, ".-esm-patient-vitals__vitals-biometrics-action-menu__layer___2p7EJ {\n  height: 100%;\n}\n.-esm-patient-vitals__vitals-biometrics-action-menu__layer___2p7EJ .cds--overflow-menu {\n  min-height: unset;\n}\n\n.-esm-patient-vitals__vitals-biometrics-action-menu__menuItem___1bTNP {\n  max-width: none;\n}", "",{"version":3,"sources":["webpack://./src/components/action-menu/vitals-biometrics-action-menu.scss"],"names":[],"mappings":"AAAA;EACE,YAAA;AACF;AACE;EACE,iBAAA;AACJ;;AAGA;EACE,eAAA;AAAF","sourcesContent":[".layer {\r\n  height: 100%;\r\n\r\n  :global(.cds--overflow-menu) {\r\n    min-height: unset;\r\n  }\r\n}\r\n\r\n.menuItem {\r\n  max-width: none;\r\n}\r\n"],"sourceRoot":""}]);
// Exports
___CSS_LOADER_EXPORT___.locals = {
	"layer": "-esm-patient-vitals__vitals-biometrics-action-menu__layer___2p7EJ",
	"menuItem": "-esm-patient-vitals__vitals-biometrics-action-menu__menuItem___1bTNP"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "../../node_modules/openmrs/node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[2].use[1]!../../node_modules/openmrs/node_modules/sass-loader/dist/cjs.js??ruleSet[1].rules[2].use[2]!./src/vitals-and-biometrics-header/vitals-header-item.scss":
/*!*********************************************************************************************************************************************************************************************************************************************************!*\
  !*** ../../node_modules/openmrs/node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[2].use[1]!../../node_modules/openmrs/node_modules/sass-loader/dist/cjs.js??ruleSet[1].rules[2].use[2]!./src/vitals-and-biometrics-header/vitals-header-item.scss ***!
  \*********************************************************************************************************************************************************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_openmrs_node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../../node_modules/openmrs/node_modules/css-loader/dist/runtime/cssWithMappingToString.js */ "../../node_modules/openmrs/node_modules/css-loader/dist/runtime/cssWithMappingToString.js");
/* harmony import */ var _node_modules_openmrs_node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_openmrs_node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_openmrs_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../../node_modules/openmrs/node_modules/css-loader/dist/runtime/api.js */ "../../node_modules/openmrs/node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_openmrs_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_openmrs_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_openmrs_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_openmrs_node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0___default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, "@charset \"UTF-8\";\n/* 60,70 and 80 are already declared as brand-01, 02 and 03 respectively */\n:root {\n  --brand-01: #005d5d;\n  --brand-02: #004144;\n  --brand-03: #007d79;\n  --bottom-nav-height: 4rem;\n  --workspace-header-height: 3rem;\n  --tablet-workspace-window-height: calc(100vh - var(--omrs-navbar-height) - var(--bottom-nav-height));\n  --desktop-workspace-window-height: calc(100vh - var(--omrs-navbar-height) - var(--workspace-header-height));\n}\n\n/* These color variables will be removed in a future release */\n.-esm-patient-vitals__vitals-header-item__container___p5XwE {\n  display: flex;\n  flex-flow: row wrap;\n  flex-direction: column;\n  margin: 0.5rem 0 0;\n  min-inline-size: max-content;\n}\n\n.-esm-patient-vitals__vitals-header-item__abnormal-value___HAWyr, .-esm-patient-vitals__vitals-header-item__critical-value___peT7P {\n  border: solid 1px #ffc69e;\n  background-color: #fff2e8;\n  display: flex;\n  flex-direction: column;\n  justify-content: center;\n  width: fit-content;\n  gap: 0.25rem;\n  padding: 0.25rem;\n}\n\n.-esm-patient-vitals__vitals-header-item__critical-value___peT7P {\n  border: 1px solid #da1e28;\n  background-color: #ffd7d9;\n}\n\n.-esm-patient-vitals__vitals-header-item__label-container___gHTUB, .-esm-patient-vitals__vitals-header-item__value-container___FOgkv {\n  flex-grow: 0;\n  flex-direction: row;\n  justify-content: flex-start;\n  align-items: center;\n  display: flex;\n  gap: 0.25rem;\n  padding: 0;\n}\n\n.-esm-patient-vitals__vitals-header-item__value-container___FOgkv {\n  margin-top: 0.25rem;\n}\n\n.-esm-patient-vitals__vitals-header-item__label___ajEL0 {\n  font-size: var(--cds-label-01-font-size, 0.75rem);\n  font-weight: var(--cds-label-01-font-weight, 400);\n  line-height: var(--cds-label-01-line-height, 1.33333);\n  letter-spacing: var(--cds-label-01-letter-spacing, 0.32px);\n  color: #525252;\n}\n\n.-esm-patient-vitals__vitals-header-item__danger-icon___DGpcb {\n  color: #da1e28;\n  height: 0.25rem;\n  width: 0.25rem;\n}\n\n.-esm-patient-vitals__vitals-header-item__value___AA1n6 {\n  font-size: var(--cds-body-compact-02-font-size, 1rem);\n  font-weight: var(--cds-body-compact-02-font-weight, 400);\n  line-height: var(--cds-body-compact-02-line-height, 1.375);\n  letter-spacing: var(--cds-body-compact-02-letter-spacing, 0);\n}\n\n.-esm-patient-vitals__vitals-header-item__units___TOg9d {\n  font-size: var(--cds-body-compact-01-font-size, 0.875rem);\n  font-weight: var(--cds-body-compact-01-font-weight, 400);\n  line-height: var(--cds-body-compact-01-line-height, 1.28572);\n  letter-spacing: var(--cds-body-compact-01-letter-spacing, 0.16px);\n  color: #525252;\n}\n\n.-esm-patient-vitals__vitals-header-item__pad-right___0ixyf {\n  margin-right: 0.125rem;\n}\n\n.-esm-patient-vitals__vitals-header-item__critically-low___ZZAGy::after,\n.-esm-patient-vitals__vitals-header-item__critically-high___D78ng::after,\n.-esm-patient-vitals__vitals-header-item__low___-d1S0::after,\n.-esm-patient-vitals__vitals-header-item__high___hV5Gr::after {\n  font-size: var(--cds-heading-compact-01-font-size, 0.875rem);\n  font-weight: var(--cds-heading-compact-01-font-weight, 600);\n  line-height: var(--cds-heading-compact-01-line-height, 1.28572);\n  letter-spacing: var(--cds-heading-compact-01-letter-spacing, 0.16px);\n  color: #525252;\n}\n\n.-esm-patient-vitals__vitals-header-item__arrow___6PUyM, .-esm-patient-vitals__vitals-header-item__critically-high___D78ng::after, .-esm-patient-vitals__vitals-header-item__high___hV5Gr::after, .-esm-patient-vitals__vitals-header-item__critically-low___ZZAGy::after, .-esm-patient-vitals__vitals-header-item__low___-d1S0::after {\n  color: #161616;\n  font-weight: 500;\n}\n\n.-esm-patient-vitals__vitals-header-item__low___-d1S0::after {\n  content: \" ↓\";\n}\n\n.-esm-patient-vitals__vitals-header-item__critically-low___ZZAGy::after {\n  content: \" ↓↓\";\n}\n\n.-esm-patient-vitals__vitals-header-item__high___hV5Gr::after {\n  content: \" ↑\";\n}\n\n.-esm-patient-vitals__vitals-header-item__critically-high___D78ng::after {\n  content: \" ↑↑\";\n}", "",{"version":3,"sources":["webpack://./src/vitals-and-biometrics-header/vitals-header-item.scss","webpack://./../../node_modules/@openmrs/esm-styleguide/src/_vars.scss","webpack://./../../node_modules/@carbon/colors/index.scss","webpack://./../../node_modules/@carbon/layout/scss/generated/_spacing.scss","webpack://./../../node_modules/@carbon/type/scss/_styles.scss"],"names":[],"mappings":"AAAA,gBAAgB;ACkChB,0EAAA;AAoBA;EACE,mBAAA;EACA,mBAAA;EACA,mBAAA;EACA,yBAAA;EACA,+BAAA;EACA,oGAAA;EACA,2GAAA;ADnDF;;AC+DA,8DAAA;ADpEA;EACE,aAAA;EACA,mBAAA;EACA,sBAAA;EACA,kBAAA;EACA,4BAAA;AASF;;AANA;EACE,yBAAA;EACA,yBEyDU;EFxDV,aAAA;EACA,sBAAA;EACA,uBAAA;EACA,kBAAA;EACA,YGJW;EHKX,gBGLW;AHcb;;AANA;EAEE,yBAAA;EACA,yBEkEO;AF1DT;;AALA;EACE,YAAA;EACA,mBAAA;EACA,2BAAA;EACA,mBAAA;EACA,aAAA;EACA,YGpBW;EHqBX,UAAA;AAQF;;AALA;EAEE,mBG1BW;AHiCb;;AAJA;EIqzBI,iDAAA;EAAA,iDAAA;EAAA,qDAAA;EAAA,0DAAA;EJnzBF,cCxCQ;ADkDV;;AAPA;EACE,cC7BO;ED8BP,eGpCW;EHqCX,cGrCW;AH+Cb;;AAPA;EI0yBI,qDAAA;EAAA,wDAAA;EAAA,0DAAA;EAAA,4DAAA;AJ5xBJ;;AAVA;EIsyBI,yDAAA;EAAA,wDAAA;EAAA,4DAAA;EAAA,iEAAA;EJpyBF,cCvDQ;ADuEV;;AAbA;EACE,sBGvDW;AHuEb;;AATE;;;;EIyxBE,4DAAA;EAAA,2DAAA;EAAA,+DAAA;EAAA,oEAAA;EJvxBA,cCpEM;ADsFV;;AAdA;EACE,cE7BS;EF8BT,gBAAA;AAiBF;;AAdA;EAEE,aAAA;AAgBF;;AAbA;EAEE,cAAA;AAeF;;AAZA;EAEE,aAAA;AAcF;;AAXA;EAEE,cAAA;AAaF","sourcesContent":["@use '@carbon/colors';\r\n@use '@carbon/type';\r\n@use '@carbon/layout';\r\n@use '@openmrs/esm-styleguide/src/vars' as *;\r\n\r\n.container {\r\n  display: flex;\r\n  flex-flow: row wrap;\r\n  flex-direction: column;\r\n  margin: layout.$spacing-03 0 0;\r\n  min-inline-size: max-content;\r\n}\r\n\r\n.abnormal-value {\r\n  border: solid 1px colors.$orange-20-hover;\r\n  background-color: colors.$orange-10;\r\n  display: flex;\r\n  flex-direction: column;\r\n  justify-content: center;\r\n  width: fit-content;\r\n  gap: layout.$spacing-02;\r\n  padding: layout.$spacing-02;\r\n}\r\n\r\n.critical-value {\r\n  @extend .abnormal-value;\r\n  border: 1px solid colors.$red-60;\r\n  background-color: colors.$red-20;\r\n}\r\n\r\n.label-container {\r\n  flex-grow: 0;\r\n  flex-direction: row;\r\n  justify-content: flex-start;\r\n  align-items: center;\r\n  display: flex;\r\n  gap: layout.$spacing-02;\r\n  padding: 0;\r\n}\r\n\r\n.value-container {\r\n  @extend .label-container;\r\n  margin-top: layout.$spacing-02;\r\n}\r\n\r\n.label {\r\n  @include type.type-style('label-01');\r\n  color: $text-02;\r\n}\r\n\r\n.danger-icon {\r\n  color: $danger;\r\n  height: layout.$spacing-02;\r\n  width: layout.$spacing-02;\r\n}\r\n\r\n.value {\r\n  @include type.type-style('body-compact-02');\r\n}\r\n\r\n.units {\r\n  @include type.type-style('body-compact-01');\r\n  color: $text-02;\r\n}\r\n\r\n.pad-right {\r\n  margin-right: layout.$spacing-01;\r\n}\r\n\r\n.critically-low,\r\n.critically-high,\r\n.low,\r\n.high {\r\n  &::after {\r\n    @include type.type-style('heading-compact-01');\r\n    color: $text-02;\r\n  }\r\n}\r\n\r\n.arrow {\r\n  color: colors.$gray-100;\r\n  font-weight: 500;\r\n}\r\n\r\n.low::after {\r\n  @extend .arrow;\r\n  content: ' ↓';\r\n}\r\n\r\n.critically-low::after {\r\n  @extend .arrow;\r\n  content: ' ↓↓';\r\n}\r\n\r\n.high::after {\r\n  @extend .arrow;\r\n  content: ' ↑';\r\n}\r\n\r\n.critically-high::after {\r\n  @extend .arrow;\r\n  content: ' ↑↑';\r\n}\r\n","@use '@carbon/layout';\n\n$ui-01: #f4f4f4;\n$ui-02: #ffffff;\n$ui-03: #e0e0e0;\n$ui-04: #8d8d8d;\n$ui-05: #161616;\n$text-02: #525252;\n$text-03: #a8a8a8;\n$ui-background: #ffffff;\n$color-gray-30: #c6c6c6;\n$color-gray-70: #525252;\n$color-gray-100: #161616;\n$color-blue-60-2: #0f62fe;\n$color-blue-10: #edf5ff;\n$color-yellow-50: #feecae;\n$carbon--red-50: #fa4d56;\n$inverse-link: #78a9ff;\n$support-02: #24a148;\n$inverse-support-03: #f1c21b;\n$warning-background: #fff8e1;\n$openmrs-background-grey: #f4f4f4;\n$danger: #da1e28;\n$interactive-01: #0f62fe;\n$field-01: #f4f4f4;\n$grey-2: #e0e0e0;\n$labeldropdown: #c6c6c6;\n\n$brand-primary-10: #d9fbfb;\n$brand-primary-20: #9ef0f0;\n$brand-primary-30: #3ddbd9;\n$brand-primary-40: #08bdba;\n$brand-primary-50: #009d9a;\n\n/* 60,70 and 80 are already declared as brand-01, 02 and 03 respectively */\n\n$brand-primary-90: #022b30;\n$brand-primary-100: #081a1c;\n\n@mixin brand-01($property) {\n  #{$property}: #005d5d;\n  #{$property}: var(--brand-01);\n}\n\n@mixin brand-02($property) {\n  #{$property}: #004144;\n  #{$property}: var(--brand-02);\n}\n\n@mixin brand-03($property) {\n  #{$property}: #007d79;\n  #{$property}: var(--brand-03);\n}\n\n:root {\n  --brand-01: #005d5d;\n  --brand-02: #004144;\n  --brand-03: #007d79;\n  --bottom-nav-height: #{layout.$spacing-10};\n  --workspace-header-height: #{layout.$spacing-09};\n  --tablet-workspace-window-height: calc(100vh - var(--omrs-navbar-height) - var(--bottom-nav-height));\n  --desktop-workspace-window-height: calc(100vh - var(--omrs-navbar-height) - var(--workspace-header-height));\n}\n\n$breakpoint-phone-min: 0px;\n$breakpoint-phone-max: 600px;\n$breakpoint-tablet-min: 601px;\n$breakpoint-tablet-max: 1023px;\n$breakpoint-small-desktop-min: 1024px;\n$breakpoint-small-desktop-max: 1439px;\n$breakpoint-large-desktop-min: 1440px;\n$breakpoint-large-desktop-max: 99999999px;\n\n/* These color variables will be removed in a future release */\n$brand-teal-01: #007d79;\n$brand-01: #005d5d;\n$brand-02: #004144;\n","// Code generated by @carbon/colors. DO NOT EDIT.\n//\n// Copyright IBM Corp. 2018, 2023\n//\n// This source code is licensed under the Apache-2.0 license found in the\n// LICENSE file in the root directory of this source tree.\n//\n\n$black: #000000 !default;\n$white: #ffffff !default;\n\n$black-100: #000000 !default;\n$blue-10: #edf5ff !default;\n$blue-20: #d0e2ff !default;\n$blue-30: #a6c8ff !default;\n$blue-40: #78a9ff !default;\n$blue-50: #4589ff !default;\n$blue-60: #0f62fe !default;\n$blue-70: #0043ce !default;\n$blue-80: #002d9c !default;\n$blue-90: #001d6c !default;\n$blue-100: #001141 !default;\n$cool-gray-10: #f2f4f8 !default;\n$cool-gray-20: #dde1e6 !default;\n$cool-gray-30: #c1c7cd !default;\n$cool-gray-40: #a2a9b0 !default;\n$cool-gray-50: #878d96 !default;\n$cool-gray-60: #697077 !default;\n$cool-gray-70: #4d5358 !default;\n$cool-gray-80: #343a3f !default;\n$cool-gray-90: #21272a !default;\n$cool-gray-100: #121619 !default;\n$cyan-10: #e5f6ff !default;\n$cyan-20: #bae6ff !default;\n$cyan-30: #82cfff !default;\n$cyan-40: #33b1ff !default;\n$cyan-50: #1192e8 !default;\n$cyan-60: #0072c3 !default;\n$cyan-70: #00539a !default;\n$cyan-80: #003a6d !default;\n$cyan-90: #012749 !default;\n$cyan-100: #061727 !default;\n$gray-10: #f4f4f4 !default;\n$gray-20: #e0e0e0 !default;\n$gray-30: #c6c6c6 !default;\n$gray-40: #a8a8a8 !default;\n$gray-50: #8d8d8d !default;\n$gray-60: #6f6f6f !default;\n$gray-70: #525252 !default;\n$gray-80: #393939 !default;\n$gray-90: #262626 !default;\n$gray-100: #161616 !default;\n$green-10: #defbe6 !default;\n$green-20: #a7f0ba !default;\n$green-30: #6fdc8c !default;\n$green-40: #42be65 !default;\n$green-50: #24a148 !default;\n$green-60: #198038 !default;\n$green-70: #0e6027 !default;\n$green-80: #044317 !default;\n$green-90: #022d0d !default;\n$green-100: #071908 !default;\n$magenta-10: #fff0f7 !default;\n$magenta-20: #ffd6e8 !default;\n$magenta-30: #ffafd2 !default;\n$magenta-40: #ff7eb6 !default;\n$magenta-50: #ee5396 !default;\n$magenta-60: #d02670 !default;\n$magenta-70: #9f1853 !default;\n$magenta-80: #740937 !default;\n$magenta-90: #510224 !default;\n$magenta-100: #2a0a18 !default;\n$orange-10: #fff2e8 !default;\n$orange-20: #ffd9be !default;\n$orange-30: #ffb784 !default;\n$orange-40: #ff832b !default;\n$orange-50: #eb6200 !default;\n$orange-60: #ba4e00 !default;\n$orange-70: #8a3800 !default;\n$orange-80: #5e2900 !default;\n$orange-90: #3e1a00 !default;\n$orange-100: #231000 !default;\n$purple-10: #f6f2ff !default;\n$purple-20: #e8daff !default;\n$purple-30: #d4bbff !default;\n$purple-40: #be95ff !default;\n$purple-50: #a56eff !default;\n$purple-60: #8a3ffc !default;\n$purple-70: #6929c4 !default;\n$purple-80: #491d8b !default;\n$purple-90: #31135e !default;\n$purple-100: #1c0f30 !default;\n$red-10: #fff1f1 !default;\n$red-20: #ffd7d9 !default;\n$red-30: #ffb3b8 !default;\n$red-40: #ff8389 !default;\n$red-50: #fa4d56 !default;\n$red-60: #da1e28 !default;\n$red-70: #a2191f !default;\n$red-80: #750e13 !default;\n$red-90: #520408 !default;\n$red-100: #2d0709 !default;\n$teal-10: #d9fbfb !default;\n$teal-20: #9ef0f0 !default;\n$teal-30: #3ddbd9 !default;\n$teal-40: #08bdba !default;\n$teal-50: #009d9a !default;\n$teal-60: #007d79 !default;\n$teal-70: #005d5d !default;\n$teal-80: #004144 !default;\n$teal-90: #022b30 !default;\n$teal-100: #081a1c !default;\n$warm-gray-10: #f7f3f2 !default;\n$warm-gray-20: #e5e0df !default;\n$warm-gray-30: #cac5c4 !default;\n$warm-gray-40: #ada8a8 !default;\n$warm-gray-50: #8f8b8b !default;\n$warm-gray-60: #726e6e !default;\n$warm-gray-70: #565151 !default;\n$warm-gray-80: #3c3838 !default;\n$warm-gray-90: #272525 !default;\n$warm-gray-100: #171414 !default;\n$white-0: #ffffff !default;\n$yellow-10: #fcf4d6 !default;\n$yellow-20: #fddc69 !default;\n$yellow-30: #f1c21b !default;\n$yellow-40: #d2a106 !default;\n$yellow-50: #b28600 !default;\n$yellow-60: #8e6a00 !default;\n$yellow-70: #684e00 !default;\n$yellow-80: #483700 !default;\n$yellow-90: #302400 !default;\n$yellow-100: #1c1500 !default;\n\n$white-hover: #e8e8e8 !default;\n$black-hover: #212121 !default;\n$blue-10-hover: #dbebff !default;\n$blue-20-hover: #b8d3ff !default;\n$blue-30-hover: #8ab6ff !default;\n$blue-40-hover: #5c97ff !default;\n$blue-50-hover: #1f70ff !default;\n$blue-60-hover: #0050e6 !default;\n$blue-70-hover: #0053ff !default;\n$blue-80-hover: #0039c7 !default;\n$blue-90-hover: #00258a !default;\n$blue-100-hover: #001f75 !default;\n$cool-gray-10-hover: #e4e9f1 !default;\n$cool-gray-20-hover: #cdd3da !default;\n$cool-gray-30-hover: #adb5bd !default;\n$cool-gray-40-hover: #9199a1 !default;\n$cool-gray-50-hover: #757b85 !default;\n$cool-gray-60-hover: #585e64 !default;\n$cool-gray-70-hover: #5d646a !default;\n$cool-gray-80-hover: #434a51 !default;\n$cool-gray-90-hover: #2b3236 !default;\n$cool-gray-100-hover: #222a2f !default;\n$cyan-10-hover: #cceeff !default;\n$cyan-20-hover: #99daff !default;\n$cyan-30-hover: #57beff !default;\n$cyan-40-hover: #059fff !default;\n$cyan-50-hover: #0f7ec8 !default;\n$cyan-60-hover: #005fa3 !default;\n$cyan-70-hover: #0066bd !default;\n$cyan-80-hover: #00498a !default;\n$cyan-90-hover: #013360 !default;\n$cyan-100-hover: #0b2947 !default;\n$gray-10-hover: #e8e8e8 !default;\n$gray-20-hover: #d1d1d1 !default;\n$gray-30-hover: #b5b5b5 !default;\n$gray-40-hover: #999999 !default;\n$gray-50-hover: #7a7a7a !default;\n$gray-60-hover: #5e5e5e !default;\n$gray-70-hover: #636363 !default;\n$gray-80-hover: #474747 !default;\n$gray-90-hover: #333333 !default;\n$gray-100-hover: #292929 !default;\n$green-10-hover: #b6f6c8 !default;\n$green-20-hover: #74e792 !default;\n$green-30-hover: #36ce5e !default;\n$green-40-hover: #3bab5a !default;\n$green-50-hover: #208e3f !default;\n$green-60-hover: #166f31 !default;\n$green-70-hover: #11742f !default;\n$green-80-hover: #05521c !default;\n$green-90-hover: #033b11 !default;\n$green-100-hover: #0d300f !default;\n$magenta-10-hover: #ffe0ef !default;\n$magenta-20-hover: #ffbdda !default;\n$magenta-30-hover: #ff94c3 !default;\n$magenta-40-hover: #ff57a0 !default;\n$magenta-50-hover: #e3176f !default;\n$magenta-60-hover: #b0215f !default;\n$magenta-70-hover: #bf1d63 !default;\n$magenta-80-hover: #8e0b43 !default;\n$magenta-90-hover: #68032e !default;\n$magenta-100-hover: #53142f !default;\n$orange-10-hover: #ffe2cc !default;\n$orange-20-hover: #ffc69e !default;\n$orange-30-hover: #ff9d57 !default;\n$orange-40-hover: #fa6800 !default;\n$orange-50-hover: #cc5500 !default;\n$orange-60-hover: #9e4200 !default;\n$orange-70-hover: #a84400 !default;\n$orange-80-hover: #753300 !default;\n$orange-90-hover: #522200 !default;\n$orange-100-hover: #421e00 !default;\n$purple-10-hover: #ede5ff !default;\n$purple-20-hover: #dcc7ff !default;\n$purple-30-hover: #c5a3ff !default;\n$purple-40-hover: #ae7aff !default;\n$purple-50-hover: #9352ff !default;\n$purple-60-hover: #7822fb !default;\n$purple-70-hover: #7c3dd6 !default;\n$purple-80-hover: #5b24ad !default;\n$purple-90-hover: #40197b !default;\n$purple-100-hover: #341c59 !default;\n$red-10-hover: #ffe0e0 !default;\n$red-20-hover: #ffc2c5 !default;\n$red-30-hover: #ff99a0 !default;\n$red-40-hover: #ff6168 !default;\n$red-50-hover: #ee0713 !default;\n$red-60-hover: #b81922 !default;\n$red-70-hover: #c21e25 !default;\n$red-80-hover: #921118 !default;\n$red-90-hover: #66050a !default;\n$red-100-hover: #540d11 !default;\n$teal-10-hover: #acf6f6 !default;\n$teal-20-hover: #57e5e5 !default;\n$teal-30-hover: #25cac8 !default;\n$teal-40-hover: #07aba9 !default;\n$teal-50-hover: #008a87 !default;\n$teal-60-hover: #006b68 !default;\n$teal-70-hover: #007070 !default;\n$teal-80-hover: #005357 !default;\n$teal-90-hover: #033940 !default;\n$teal-100-hover: #0f3034 !default;\n$warm-gray-10-hover: #f0e8e6 !default;\n$warm-gray-20-hover: #d8d0cf !default;\n$warm-gray-30-hover: #b9b3b1 !default;\n$warm-gray-40-hover: #9c9696 !default;\n$warm-gray-50-hover: #7f7b7b !default;\n$warm-gray-60-hover: #605d5d !default;\n$warm-gray-70-hover: #696363 !default;\n$warm-gray-80-hover: #4c4848 !default;\n$warm-gray-90-hover: #343232 !default;\n$warm-gray-100-hover: #2c2626 !default;\n$yellow-10-hover: #f8e6a0 !default;\n$yellow-20-hover: #fccd27 !default;\n$yellow-30-hover: #ddb00e !default;\n$yellow-40-hover: #bc9005 !default;\n$yellow-50-hover: #9e7700 !default;\n$yellow-60-hover: #755800 !default;\n$yellow-70-hover: #806000 !default;\n$yellow-80-hover: #5c4600 !default;\n$yellow-90-hover: #3d2e00 !default;\n$yellow-100-hover: #332600 !default;\n\n/// Colors from the IBM Design Language\n/// @access public\n/// @group @carbon/colors\n$colors: (\n  black: (\n    100: #000000,\n  ),\n  blue: (\n    10: #edf5ff,\n    20: #d0e2ff,\n    30: #a6c8ff,\n    40: #78a9ff,\n    50: #4589ff,\n    60: #0f62fe,\n    70: #0043ce,\n    80: #002d9c,\n    90: #001d6c,\n    100: #001141,\n  ),\n  cool-gray: (\n    10: #f2f4f8,\n    20: #dde1e6,\n    30: #c1c7cd,\n    40: #a2a9b0,\n    50: #878d96,\n    60: #697077,\n    70: #4d5358,\n    80: #343a3f,\n    90: #21272a,\n    100: #121619,\n  ),\n  cyan: (\n    10: #e5f6ff,\n    20: #bae6ff,\n    30: #82cfff,\n    40: #33b1ff,\n    50: #1192e8,\n    60: #0072c3,\n    70: #00539a,\n    80: #003a6d,\n    90: #012749,\n    100: #061727,\n  ),\n  gray: (\n    10: #f4f4f4,\n    20: #e0e0e0,\n    30: #c6c6c6,\n    40: #a8a8a8,\n    50: #8d8d8d,\n    60: #6f6f6f,\n    70: #525252,\n    80: #393939,\n    90: #262626,\n    100: #161616,\n  ),\n  green: (\n    10: #defbe6,\n    20: #a7f0ba,\n    30: #6fdc8c,\n    40: #42be65,\n    50: #24a148,\n    60: #198038,\n    70: #0e6027,\n    80: #044317,\n    90: #022d0d,\n    100: #071908,\n  ),\n  magenta: (\n    10: #fff0f7,\n    20: #ffd6e8,\n    30: #ffafd2,\n    40: #ff7eb6,\n    50: #ee5396,\n    60: #d02670,\n    70: #9f1853,\n    80: #740937,\n    90: #510224,\n    100: #2a0a18,\n  ),\n  orange: (\n    10: #fff2e8,\n    20: #ffd9be,\n    30: #ffb784,\n    40: #ff832b,\n    50: #eb6200,\n    60: #ba4e00,\n    70: #8a3800,\n    80: #5e2900,\n    90: #3e1a00,\n    100: #231000,\n  ),\n  purple: (\n    10: #f6f2ff,\n    20: #e8daff,\n    30: #d4bbff,\n    40: #be95ff,\n    50: #a56eff,\n    60: #8a3ffc,\n    70: #6929c4,\n    80: #491d8b,\n    90: #31135e,\n    100: #1c0f30,\n  ),\n  red: (\n    10: #fff1f1,\n    20: #ffd7d9,\n    30: #ffb3b8,\n    40: #ff8389,\n    50: #fa4d56,\n    60: #da1e28,\n    70: #a2191f,\n    80: #750e13,\n    90: #520408,\n    100: #2d0709,\n  ),\n  teal: (\n    10: #d9fbfb,\n    20: #9ef0f0,\n    30: #3ddbd9,\n    40: #08bdba,\n    50: #009d9a,\n    60: #007d79,\n    70: #005d5d,\n    80: #004144,\n    90: #022b30,\n    100: #081a1c,\n  ),\n  warm-gray: (\n    10: #f7f3f2,\n    20: #e5e0df,\n    30: #cac5c4,\n    40: #ada8a8,\n    50: #8f8b8b,\n    60: #726e6e,\n    70: #565151,\n    80: #3c3838,\n    90: #272525,\n    100: #171414,\n  ),\n  white: (\n    0: #ffffff,\n  ),\n  yellow: (\n    10: #fcf4d6,\n    20: #fddc69,\n    30: #f1c21b,\n    40: #d2a106,\n    50: #b28600,\n    60: #8e6a00,\n    70: #684e00,\n    80: #483700,\n    90: #302400,\n    100: #1c1500,\n  ),\n) !default;\n","// Code generated by @carbon/layout. DO NOT EDIT.\n//\n// Copyright IBM Corp. 2018, 2023\n//\n// This source code is licensed under the Apache-2.0 license found in the\n// LICENSE file in the root directory of this source tree.\n//\n\n/// @type Number\n/// @access public\n/// @group @carbon/layout\n$spacing-01: 0.125rem !default;\n\n/// @type Number\n/// @access public\n/// @group @carbon/layout\n$spacing-02: 0.25rem !default;\n\n/// @type Number\n/// @access public\n/// @group @carbon/layout\n$spacing-03: 0.5rem !default;\n\n/// @type Number\n/// @access public\n/// @group @carbon/layout\n$spacing-04: 0.75rem !default;\n\n/// @type Number\n/// @access public\n/// @group @carbon/layout\n$spacing-05: 1rem !default;\n\n/// @type Number\n/// @access public\n/// @group @carbon/layout\n$spacing-06: 1.5rem !default;\n\n/// @type Number\n/// @access public\n/// @group @carbon/layout\n$spacing-07: 2rem !default;\n\n/// @type Number\n/// @access public\n/// @group @carbon/layout\n$spacing-08: 2.5rem !default;\n\n/// @type Number\n/// @access public\n/// @group @carbon/layout\n$spacing-09: 3rem !default;\n\n/// @type Number\n/// @access public\n/// @group @carbon/layout\n$spacing-10: 4rem !default;\n\n/// @type Number\n/// @access public\n/// @group @carbon/layout\n$spacing-11: 5rem !default;\n\n/// @type Number\n/// @access public\n/// @group @carbon/layout\n$spacing-12: 6rem !default;\n\n/// @type Number\n/// @access public\n/// @group @carbon/layout\n$spacing-13: 10rem !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/layout\n$spacing: (\n  spacing-01: $spacing-01,\n  spacing-02: $spacing-02,\n  spacing-03: $spacing-03,\n  spacing-04: $spacing-04,\n  spacing-05: $spacing-05,\n  spacing-06: $spacing-06,\n  spacing-07: $spacing-07,\n  spacing-08: $spacing-08,\n  spacing-09: $spacing-09,\n  spacing-10: $spacing-10,\n  spacing-11: $spacing-11,\n  spacing-12: $spacing-12,\n  spacing-13: $spacing-13,\n);\n","//\n// Copyright IBM Corp. 2018, 2023\n//\n// This source code is licensed under the Apache-2.0 license found in the\n// LICENSE file in the root directory of this source tree.\n//\n\n// stylelint-disable number-max-precision\n\n@use 'sass:map';\n@use 'sass:math';\n@use '@carbon/grid/scss/config' as gridconfig;\n@use '@carbon/grid/scss/breakpoint' as grid;\n@use 'prefix' as *;\n@use 'font-family';\n@use 'scale';\n\n/// @type Map\n/// @access public\n/// @deprecated\n/// @group @carbon/type\n$caption-01: (\n  font-size: scale.type-scale(1),\n  font-weight: font-family.font-weight('regular'),\n  line-height: 1.33333,\n  letter-spacing: 0.32px,\n) !default;\n\n/// @type Map\n/// @access public\n/// @deprecated\n/// @group @carbon/type\n$caption-02: (\n  font-size: scale.type-scale(2),\n  font-weight: font-family.font-weight('regular'),\n  line-height: 1.28572,\n  letter-spacing: 0.32px,\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$label-01: (\n  font-size: scale.type-scale(1),\n  font-weight: font-family.font-weight('regular'),\n  line-height: 1.33333,\n  letter-spacing: 0.32px,\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$label-02: (\n  font-size: scale.type-scale(2),\n  font-weight: font-family.font-weight('regular'),\n  line-height: 1.28572,\n  letter-spacing: 0.16px,\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$legal-01: (\n  font-size: scale.type-scale(1),\n  font-weight: font-family.font-weight('regular'),\n  line-height: 1.33333,\n  letter-spacing: 0.32px,\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$legal-02: (\n  font-size: scale.type-scale(2),\n  font-weight: font-family.font-weight('regular'),\n  line-height: 1.28572,\n  letter-spacing: 0.16px,\n) !default;\n\n/// @type Map\n/// @access public\n/// @deprecated\n/// @group @carbon/type\n$helper-text-01: (\n  font-size: scale.type-scale(1),\n  line-height: 1.33333,\n  letter-spacing: 0.32px,\n) !default;\n\n/// @type Map\n/// @access public\n/// @deprecated\n/// @group @carbon/type\n$helper-text-02: (\n  font-size: scale.type-scale(2),\n  font-weight: font-family.font-weight('regular'),\n  line-height: 1.28572,\n  letter-spacing: 0.16px,\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$body-short-01: (\n  font-size: scale.type-scale(2),\n  font-weight: font-family.font-weight('regular'),\n  line-height: 1.28572,\n  letter-spacing: 0.16px,\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$body-compact-01: $body-short-01 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$body-long-01: (\n  font-size: scale.type-scale(2),\n  font-weight: font-family.font-weight('regular'),\n  line-height: 1.42857,\n  letter-spacing: 0.16px,\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$body-01: $body-long-01 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$body-short-02: (\n  font-size: scale.type-scale(3),\n  font-weight: font-family.font-weight('regular'),\n  line-height: 1.375,\n  letter-spacing: 0,\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$body-compact-02: $body-short-02 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$body-long-02: (\n  font-size: scale.type-scale(3),\n  font-weight: font-family.font-weight('regular'),\n  line-height: 1.5,\n  letter-spacing: 0,\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$body-02: $body-long-02 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$code-01: (\n  font-family: font-family.font-family('mono'),\n  font-size: scale.type-scale(1),\n  font-weight: font-family.font-weight('regular'),\n  line-height: 1.33333,\n  letter-spacing: 0.32px,\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$code-02: (\n  font-family: font-family.font-family('mono'),\n  font-size: scale.type-scale(2),\n  font-weight: font-family.font-weight('regular'),\n  line-height: 1.42857,\n  letter-spacing: 0.32px,\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$heading-01: (\n  font-size: scale.type-scale(2),\n  font-weight: font-family.font-weight('semibold'),\n  line-height: 1.42857,\n  letter-spacing: 0.16px,\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$productive-heading-01: (\n  font-size: scale.type-scale(2),\n  font-weight: font-family.font-weight('semibold'),\n  line-height: 1.28572,\n  letter-spacing: 0.16px,\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$heading-compact-01: $productive-heading-01 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$heading-02: (\n  font-size: scale.type-scale(3),\n  font-weight: font-family.font-weight('semibold'),\n  line-height: 1.5,\n  letter-spacing: 0,\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$productive-heading-02: (\n  font-size: scale.type-scale(3),\n  font-weight: font-family.font-weight('semibold'),\n  line-height: 1.375,\n  letter-spacing: 0,\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$heading-compact-02: $productive-heading-02 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$productive-heading-03: (\n  font-size: scale.type-scale(5),\n  font-weight: font-family.font-weight('regular'),\n  line-height: 1.4,\n  letter-spacing: 0,\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$heading-03: $productive-heading-03 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$productive-heading-04: (\n  font-size: scale.type-scale(7),\n  font-weight: font-family.font-weight('regular'),\n  line-height: 1.28572,\n  letter-spacing: 0,\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$heading-04: $productive-heading-04 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$productive-heading-05: (\n  font-size: scale.type-scale(8),\n  font-weight: font-family.font-weight('regular'),\n  line-height: 1.25,\n  letter-spacing: 0,\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$heading-05: $productive-heading-05 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$productive-heading-06: (\n  font-size: scale.type-scale(10),\n  font-weight: font-family.font-weight('light'),\n  // Extra digit needed for precision in Chrome\n  line-height: 1.199,\n  letter-spacing: 0,\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$heading-06: $productive-heading-06 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$productive-heading-07: (\n  font-size: scale.type-scale(12),\n  font-weight: font-family.font-weight('light'),\n  line-height: 1.19,\n  letter-spacing: 0,\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$heading-07: $productive-heading-07 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$expressive-heading-01: $heading-01 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$expressive-heading-02: $heading-02 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$expressive-heading-03: (\n  font-size: scale.type-scale(5),\n  font-weight: font-family.font-weight('regular'),\n  line-height: 1.4,\n  letter-spacing: 0,\n  breakpoints: (\n    xlg: (\n      font-size: scale.type-scale(5),\n      line-height: 1.4,\n    ),\n    max: (\n      font-size: scale.type-scale(6),\n      line-height: 1.334,\n    ),\n  ),\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$fluid-heading-03: $expressive-heading-03 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$expressive-heading-04: (\n  font-size: scale.type-scale(7),\n  font-weight: font-family.font-weight('regular'),\n  line-height: 1.28572,\n  letter-spacing: 0,\n  breakpoints: (\n    xlg: (\n      font-size: scale.type-scale(8),\n      line-height: 1.25,\n      font-weight: font-family.font-weight('regular'),\n    ),\n    max: (\n      font-size: scale.type-scale(8),\n      font-weight: font-family.font-weight('regular'),\n    ),\n  ),\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$fluid-heading-04: $expressive-heading-04 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$expressive-heading-05: (\n  font-size: scale.type-scale(8),\n  font-weight: font-family.font-weight('regular'),\n  line-height: 1.25,\n  letter-spacing: 0,\n  breakpoints: (\n    md: (\n      font-size: scale.type-scale(9),\n      font-weight: font-family.font-weight('light'),\n      line-height: 1.22,\n    ),\n    lg: (\n      font-size: scale.type-scale(10),\n      line-height: 1.19,\n    ),\n    xlg: (\n      font-size: scale.type-scale(11),\n      line-height: 1.17,\n    ),\n    max: (\n      font-size: scale.type-scale(13),\n    ),\n  ),\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$fluid-heading-05: $expressive-heading-05 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$expressive-heading-06: (\n  font-size: scale.type-scale(8),\n  font-weight: font-family.font-weight('semibold'),\n  line-height: 1.25,\n  letter-spacing: 0,\n  breakpoints: (\n    md: (\n      font-size: scale.type-scale(9),\n      line-height: 1.22,\n    ),\n    lg: (\n      font-size: scale.type-scale(10),\n      line-height: 1.19,\n    ),\n    xlg: (\n      font-size: scale.type-scale(11),\n      line-height: 1.17,\n    ),\n    max: (\n      font-size: scale.type-scale(13),\n    ),\n  ),\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$fluid-heading-06: $expressive-heading-06 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$expressive-paragraph-01: (\n  font-size: scale.type-scale(6),\n  font-weight: font-family.font-weight('light'),\n  line-height: 1.334,\n  letter-spacing: 0,\n  breakpoints: (\n    lg: (\n      font-size: scale.type-scale(7),\n      line-height: 1.28572,\n    ),\n    max: (\n      font-size: scale.type-scale(8),\n      line-height: 1.25,\n    ),\n  ),\n);\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$fluid-paragraph-01: $expressive-paragraph-01 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$quotation-01: (\n  font-family: font-family.font-family('serif'),\n  font-size: scale.type-scale(5),\n  font-weight: font-family.font-weight('regular'),\n  line-height: 1.3,\n  letter-spacing: 0,\n  breakpoints: (\n    md: (\n      font-size: scale.type-scale(5),\n    ),\n    lg: (\n      font-size: scale.type-scale(6),\n      line-height: 1.334,\n    ),\n    xlg: (\n      font-size: scale.type-scale(7),\n      line-height: 1.28572,\n    ),\n    max: (\n      font-size: scale.type-scale(8),\n      line-height: 1.25,\n    ),\n  ),\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$fluid-quotation-01: $quotation-01 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$quotation-02: (\n  font-family: font-family.font-family('serif'),\n  font-size: scale.type-scale(8),\n  font-weight: font-family.font-weight('light'),\n  line-height: 1.25,\n  letter-spacing: 0,\n  breakpoints: (\n    md: (\n      font-size: scale.type-scale(9),\n      line-height: 1.22,\n    ),\n    lg: (\n      font-size: scale.type-scale(10),\n      line-height: 1.19,\n    ),\n    xlg: (\n      font-size: scale.type-scale(11),\n      line-height: 1.17,\n    ),\n    max: (\n      font-size: scale.type-scale(13),\n    ),\n  ),\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$fluid-quotation-02: $quotation-02 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$display-01: (\n  font-size: scale.type-scale(10),\n  font-weight: font-family.font-weight('light'),\n  line-height: 1.19,\n  letter-spacing: 0,\n  breakpoints: (\n    md: (\n      font-size: scale.type-scale(10),\n    ),\n    lg: (\n      font-size: scale.type-scale(12),\n    ),\n    xlg: (\n      font-size: scale.type-scale(13),\n      line-height: 1.17,\n    ),\n    max: (\n      font-size: scale.type-scale(15),\n      line-height: 1.13,\n    ),\n  ),\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$fluid-display-01: $display-01 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$display-02: (\n  font-size: scale.type-scale(10),\n  font-weight: font-family.font-weight('semibold'),\n  line-height: 1.19,\n  letter-spacing: 0,\n  breakpoints: (\n    md: (\n      font-size: scale.type-scale(10),\n    ),\n    lg: (\n      font-size: scale.type-scale(12),\n    ),\n    xlg: (\n      font-size: scale.type-scale(13),\n      line-height: 1.16,\n    ),\n    max: (\n      font-size: scale.type-scale(15),\n      line-height: 1.13,\n    ),\n  ),\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$fluid-display-02: $display-02 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$display-03: (\n  font-size: scale.type-scale(10),\n  font-weight: font-family.font-weight('light'),\n  line-height: 1.19,\n  letter-spacing: 0,\n  breakpoints: (\n    md: (\n      font-size: scale.type-scale(12),\n      line-height: 1.18,\n    ),\n    lg: (\n      font-size: scale.type-scale(13),\n      line-height: 1.16,\n      letter-spacing: -0.64px,\n    ),\n    xlg: (\n      font-size: scale.type-scale(15),\n      line-height: 1.13,\n      letter-spacing: -0.64px,\n    ),\n    max: (\n      font-size: scale.type-scale(16),\n      line-height: 1.11,\n      letter-spacing: -0.96px,\n    ),\n  ),\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$fluid-display-03: $display-03 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$display-04: (\n  font-size: scale.type-scale(10),\n  font-weight: font-family.font-weight('light'),\n  line-height: 1.19,\n  letter-spacing: 0,\n  breakpoints: (\n    md: (\n      font-size: scale.type-scale(14),\n      line-height: 1.15,\n    ),\n    lg: (\n      font-size: scale.type-scale(17),\n      line-height: 1.11,\n      letter-spacing: -0.64px,\n    ),\n    xlg: (\n      font-size: scale.type-scale(20),\n      line-height: 1.07,\n      letter-spacing: -0.64px,\n    ),\n    max: (\n      font-size: scale.type-scale(23),\n      line-height: 1.05,\n      letter-spacing: -0.96px,\n    ),\n  ),\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$fluid-display-04: $display-04 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$tokens: (\n  caption-01: $caption-01,\n  caption-02: $caption-02,\n  label-01: $label-01,\n  label-02: $label-02,\n  helper-text-01: $helper-text-01,\n  helper-text-02: $helper-text-02,\n  body-short-01: $body-short-01,\n  body-short-02: $body-short-02,\n  body-long-01: $body-long-01,\n  body-long-02: $body-long-02,\n  code-01: $code-01,\n  code-02: $code-02,\n  heading-01: $heading-01,\n  heading-02: $heading-02,\n  productive-heading-01: $productive-heading-01,\n  productive-heading-02: $productive-heading-02,\n  productive-heading-03: $productive-heading-03,\n  productive-heading-04: $productive-heading-04,\n  productive-heading-05: $productive-heading-05,\n  productive-heading-06: $productive-heading-06,\n  productive-heading-07: $productive-heading-07,\n  expressive-paragraph-01: $expressive-paragraph-01,\n  expressive-heading-01: $expressive-heading-01,\n  expressive-heading-02: $expressive-heading-02,\n  expressive-heading-03: $expressive-heading-03,\n  expressive-heading-04: $expressive-heading-04,\n  expressive-heading-05: $expressive-heading-05,\n  expressive-heading-06: $expressive-heading-06,\n  quotation-01: $quotation-01,\n  quotation-02: $quotation-02,\n  display-01: $display-01,\n  display-02: $display-02,\n  display-03: $display-03,\n  display-04: $display-04,\n  // V11 Tokens\n  legal-01: $legal-01,\n  legal-02: $legal-02,\n  body-compact-01: $body-compact-01,\n  body-compact-02: $body-compact-02,\n  heading-compact-01: $heading-compact-01,\n  heading-compact-02: $heading-compact-02,\n  body-01: $body-01,\n  body-02: $body-02,\n  heading-03: $heading-03,\n  heading-04: $heading-04,\n  heading-05: $heading-05,\n  heading-06: $heading-06,\n  heading-07: $heading-07,\n  fluid-heading-03: $fluid-heading-03,\n  fluid-heading-04: $fluid-heading-04,\n  fluid-heading-05: $fluid-heading-05,\n  fluid-heading-06: $fluid-heading-06,\n  fluid-paragraph-01: $fluid-paragraph-01,\n  fluid-quotation-01: $fluid-quotation-01,\n  fluid-quotation-02: $fluid-quotation-02,\n  fluid-display-01: $fluid-display-01,\n  fluid-display-02: $fluid-display-02,\n  fluid-display-03: $fluid-display-03,\n  fluid-display-04: $fluid-display-04,\n) !default;\n\n/// @param {Map} $map\n/// @access public\n/// @group @carbon/type\n@mixin properties($map) {\n  @each $name, $value in $map {\n    #{$name}: $value;\n  }\n}\n\n/// @param {Number} $value - Number with units\n/// @return {Number} Without units\n/// @access public\n/// @group @carbon/type\n@function strip-unit($value) {\n  @return math.div($value, $value * 0 + 1);\n}\n\n/// This helper includes fluid type styles for the given token value. Fluid type\n/// means that the `font-size` is computed using `calc()` in order to be\n/// determined by the screen size instead of a breakpoint. As a result, fluid\n/// styles should be used with caution in fixed width contexts.\n///\n/// In addition, we make use of %-based line-heights so that the line-height of\n/// each type style is computed correctly due to the dynamic nature of the\n/// `font-size`.\n///\n/// Most of the logic for this work comes from CSS Tricks:\n/// https://css-tricks.com/snippets/css/fluid-typography/\n///\n/// @param {Map} $type-styles - The value of a given type token\n/// @param {Map} $breakpoints [$grid-breakpoints] - Custom breakpoints to use\n/// @access public\n/// @group @carbon/type\n@mixin fluid-type($type-styles, $breakpoints: gridconfig.$grid-breakpoints) {\n  // Include the initial styles for the given token by default without any\n  // media query guard. This includes `font-size` as a fallback in the case\n  // that a browser does not support `calc()`\n  @include properties(map.remove($type-styles, breakpoints));\n  // We also need to include the `sm` styles by default since they don't\n  // appear in the fluid styles for tokens\n  @include fluid-type-size($type-styles, sm, $breakpoints);\n\n  // Finally, we need to go through all the breakpoints defined in the type\n  // token and apply the properties and fluid type size for that given\n  // breakpoint\n  @each $name, $values in map.get($type-styles, breakpoints) {\n    @include grid.breakpoint($name) {\n      @include properties($values);\n      @include fluid-type-size($type-styles, $name, $breakpoints);\n    }\n  }\n}\n\n/// Computes the fluid `font-size` for a given type style and breakpoint\n/// @param {Map} $type-styles - The styles for a given token\n/// @param {String} $name - The name of the breakpoint to which we apply the fluid\n/// @param {Map} $breakpoints [$grid-breakpoints] - The breakpoints for the grid system\n/// @access public\n/// @group @carbon/type\n@mixin fluid-type-size(\n  $type-styles,\n  $name,\n  $breakpoints: gridconfig.$grid-breakpoints\n) {\n  // Get the information about the breakpoint we're currently working in. Useful\n  // for getting initial width information\n  $breakpoint: map.get($breakpoints, $name);\n\n  // Our fluid styles are captured under the 'breakpoints' property in our type\n  // styles map. These define what values to treat as `max-` variables below\n  $fluid-sizes: map.get($type-styles, breakpoints);\n  $fluid-breakpoint: ();\n  // Special case for `sm` because the styles for small are on the type style\n  // directly\n  @if $name == sm {\n    $fluid-breakpoint: map.remove($type-styles, breakpoints);\n  } @else {\n    $fluid-breakpoint: map.get($fluid-sizes, $name);\n  }\n\n  // Initialize our font-sizes to the default size for the type style\n  $max-font-size: map.get($type-styles, font-size);\n  $min-font-size: map.get($type-styles, font-size);\n  @if map.has-key($fluid-breakpoint, font-size) {\n    $min-font-size: map.get($fluid-breakpoint, font-size);\n  }\n\n  // Initialize our min and max width to the width of the current breakpoint\n  $max-vw: map.get($breakpoint, width);\n  $min-vw: map.get($breakpoint, width);\n\n  // We can use `breakpoint-next` to see if there is another breakpoint we can\n  // use to update `max-font-size` and `max-vw` with larger values\n  $next-breakpoint-available: grid.breakpoint-next($name, $breakpoints);\n  $next-fluid-breakpoint-name: null;\n\n  // We need to figure out what the next available fluid breakpoint is for our\n  // given $type-styles. In this loop we try and iterate through breakpoints\n  // until we either manually set $next-breakpoint-available to null or\n  // `breakpoint-next` returns null.\n  @while $next-breakpoint-available {\n    @if map.has-key($fluid-sizes, $next-breakpoint-available) {\n      $next-fluid-breakpoint-name: $next-breakpoint-available;\n      $next-breakpoint-available: null;\n    } @else {\n      $next-breakpoint-available: grid.breakpoint-next(\n        $next-breakpoint-available,\n        $breakpoints\n      );\n    }\n  }\n\n  // If we have found the next available fluid breakpoint name, then we know\n  // that we have values that we can use to set max-font-size and max-vw as both\n  // values derive from the next breakpoint\n  @if $next-fluid-breakpoint-name {\n    $next-fluid-breakpoint: map.get($breakpoints, $next-fluid-breakpoint-name);\n    $max-font-size: map.get(\n      map.get($fluid-sizes, $next-fluid-breakpoint-name),\n      font-size\n    );\n    $max-vw: map.get($next-fluid-breakpoint, width);\n\n    // prettier-ignore\n    font-size: calc(#{$min-font-size} +\n      #{strip-unit($max-font-size - $min-font-size)} *\n      ((100vw - #{$min-vw}) / #{strip-unit($max-vw - $min-vw)})\n    );\n  } @else {\n    // Otherwise, just default to setting the font size found from the type\n    // style or the given fluid breakpoint in the type style\n    font-size: $min-font-size;\n  }\n}\n\n// TODO move following variable and `custom-property` mixin into shared file for\n// both `@carbon/type` and `@carbon/themes`\n\n/// @access private\n/// @group @carbon/type\n@mixin custom-properties($name, $value) {\n  @each $property, $value in $value {\n    #{$property}: var(\n      --#{$custom-property-prefix}-#{$name}-#{$property},\n      #{$value}\n    );\n  }\n}\n\n/// Helper mixin to include the styles for a given token in any selector in your\n/// project. Also includes an optional fluid option that will enable fluid\n/// styles for the token if they are defined. Fluid styles will cause the\n/// token's font-size to be computed based on the viewport size. As a result, use\n/// with caution in fixed contexts.\n/// @param {String} $name - The name of the token to get the styles for\n/// @param {Boolean} $fluid [false] - Specify whether to include fluid styles for the\n/// @param {Map} $breakpoints [$grid-breakpoints] - Provide a custom breakpoint map to use\n/// @access public\n/// @group @carbon/type\n@mixin type-style(\n  $name,\n  $fluid: false,\n  $breakpoints: gridconfig.$grid-breakpoints\n) {\n  @if not map.has-key($tokens, $name) {\n    @error 'Unable to find a token with the name: `#{$name}`';\n  }\n\n  $token: map.get($tokens, $name);\n\n  // If $fluid is set to true and the token has breakpoints defined for fluid\n  // styles, delegate to the fluid-type helper for the given token\n  @if $fluid == true and map.has-key($token, 'breakpoints') {\n    @include fluid-type($token, $breakpoints);\n  } @else {\n    @include custom-properties($name, $token);\n  }\n}\n"],"sourceRoot":""}]);
// Exports
___CSS_LOADER_EXPORT___.locals = {
	"container": "-esm-patient-vitals__vitals-header-item__container___p5XwE",
	"abnormal-value": "-esm-patient-vitals__vitals-header-item__abnormal-value___HAWyr",
	"critical-value": "-esm-patient-vitals__vitals-header-item__critical-value___peT7P",
	"label-container": "-esm-patient-vitals__vitals-header-item__label-container___gHTUB",
	"value-container": "-esm-patient-vitals__vitals-header-item__value-container___FOgkv",
	"label": "-esm-patient-vitals__vitals-header-item__label___ajEL0",
	"danger-icon": "-esm-patient-vitals__vitals-header-item__danger-icon___DGpcb",
	"value": "-esm-patient-vitals__vitals-header-item__value___AA1n6",
	"units": "-esm-patient-vitals__vitals-header-item__units___TOg9d",
	"pad-right": "-esm-patient-vitals__vitals-header-item__pad-right___0ixyf",
	"critically-low": "-esm-patient-vitals__vitals-header-item__critically-low___ZZAGy",
	"critically-high": "-esm-patient-vitals__vitals-header-item__critically-high___D78ng",
	"low": "-esm-patient-vitals__vitals-header-item__low___-d1S0",
	"high": "-esm-patient-vitals__vitals-header-item__high___hV5Gr",
	"arrow": "-esm-patient-vitals__vitals-header-item__arrow___6PUyM"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "../../node_modules/openmrs/node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[2].use[1]!../../node_modules/openmrs/node_modules/sass-loader/dist/cjs.js??ruleSet[1].rules[2].use[2]!./src/vitals-and-biometrics-header/vitals-header.scss":
/*!****************************************************************************************************************************************************************************************************************************************************!*\
  !*** ../../node_modules/openmrs/node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[2].use[1]!../../node_modules/openmrs/node_modules/sass-loader/dist/cjs.js??ruleSet[1].rules[2].use[2]!./src/vitals-and-biometrics-header/vitals-header.scss ***!
  \****************************************************************************************************************************************************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_openmrs_node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../../node_modules/openmrs/node_modules/css-loader/dist/runtime/cssWithMappingToString.js */ "../../node_modules/openmrs/node_modules/css-loader/dist/runtime/cssWithMappingToString.js");
/* harmony import */ var _node_modules_openmrs_node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_openmrs_node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_openmrs_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../../node_modules/openmrs/node_modules/css-loader/dist/runtime/api.js */ "../../node_modules/openmrs/node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_openmrs_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_openmrs_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_openmrs_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_openmrs_node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0___default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, "/* 60,70 and 80 are already declared as brand-01, 02 and 03 respectively */\n:root {\n  --brand-01: #005d5d;\n  --brand-02: #004144;\n  --brand-03: #007d79;\n  --bottom-nav-height: 4rem;\n  --workspace-header-height: 3rem;\n  --tablet-workspace-window-height: calc(100vh - var(--omrs-navbar-height) - var(--bottom-nav-height));\n  --desktop-workspace-window-height: calc(100vh - var(--omrs-navbar-height) - var(--workspace-header-height));\n}\n\n/* These color variables will be removed in a future release */\n.-esm-patient-vitals__vitals-header__container___2PKEF {\n  background-color: #f4f4f4;\n  padding: 0.5rem 1rem 1rem;\n  border-bottom: 1px solid #e0e0e0;\n}\n\n.-esm-patient-vitals__vitals-header__vitalsHeader___nN7c6 {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  min-height: 2rem;\n  outline: none;\n  pointer-events: visibleFill;\n}\n\n.-esm-patient-vitals__vitals-header__emptyStateVitalsHeader___81-z0 {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  padding: 0 1rem;\n  min-height: 3rem;\n  outline: none;\n  pointer-events: visibleFill;\n  border-bottom: 1px solid #e0e0e0;\n}\n.-esm-patient-vitals__vitals-header__emptyStateVitalsHeader___81-z0 .-esm-patient-vitals__vitals-header__container___2PKEF {\n  border-bottom: none;\n  padding: 0;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  gap: 1.5rem;\n}\n.-esm-patient-vitals__vitals-header__emptyStateVitalsHeader___81-z0 .-esm-patient-vitals__vitals-header__bodyText___xc5mx, .-esm-patient-vitals__vitals-header__emptyStateVitalsHeader___81-z0 .-esm-patient-vitals__vitals-header__link___Ap0jJ {\n  margin-left: 0.5rem;\n}\n\n.-esm-patient-vitals__vitals-header__separator___cZnKr {\n  border-left: 2px solid #000000; /* change color */\n  align-self: stretch; /* makes it grow full height of siblings */\n  margin: 1rem;\n}\n\n.-esm-patient-vitals__vitals-header__customButton___YgXJf {\n  display: inline-flex !important;\n  align-items: center !important;\n  background-color: #cadbf4 !important; /* custom blue */\n  color: rgb(0, 0, 0) !important;\n  border-radius: 8px !important;\n  padding: 0.75rem 1.5rem !important;\n  font-size: 1.25rem; /* text size */\n  font-weight: 600;\n  border: 1.5px solid #2f80ed !important; /* optional border for definition */\n  line-height: 1.5 !important;\n  min-height: 2rem;\n}\n\n.-esm-patient-vitals__vitals-header__customButton___YgXJf:hover {\n  background-color: #487be0 !important; /* subtle hover */\n  color: #000 !important;\n}\n\n.-esm-patient-vitals__vitals-header__customButton___YgXJf .-esm-patient-vitals__vitals-header__cds--btn__icon___yXOUQ {\n  margin-left: 0.75rem !important;\n}\n\n.-esm-patient-vitals__vitals-header__introBox___KZzTM {\n  background: #f0f6ff;\n  border: 1px solid #2f80ed;\n  border-radius: 8px;\n  padding: 1rem;\n  margin-bottom: 1rem;\n  max-width: 100%;\n}\n\n.-esm-patient-vitals__vitals-header__introText___6IkH9 {\n  font-size: var(--cds-body-01-font-size, 0.875rem);\n  font-weight: var(--cds-body-01-font-weight, 400);\n  line-height: var(--cds-body-01-line-height, 1.42857);\n  letter-spacing: var(--cds-body-01-letter-spacing, 0.16px);\n  color: #161616;\n  line-height: 1.6;\n  margin: 0;\n  white-space: normal;\n  word-break: break-word;\n  font-size: medium;\n  font-weight: bolder;\n  font-size: 1.25rem;\n}\n\n.-esm-patient-vitals__vitals-header__headerItems___Fdj8S {\n  display: flex;\n  align-items: baseline;\n  flex-flow: row wrap;\n  gap: 0.25rem 0.75rem;\n}\n\n.-esm-patient-vitals__vitals-header__heading___Srnfj {\n  font-size: var(--cds-heading-compact-02-font-size, 1rem);\n  font-weight: var(--cds-heading-compact-02-font-weight, 600);\n  line-height: var(--cds-heading-compact-02-line-height, 1.375);\n  letter-spacing: var(--cds-heading-compact-02-letter-spacing, 0);\n  /* Carbon Design's compact heading style */\n  color: #161616 !important; /* Light text color for contrast */\n  text-align: center; /* Center the text */\n  padding: 0.5rem 1rem; /* Add padding around the text */\n  margin-bottom: 1rem; /* Margin below the heading */\n  background-color: #cadbf4; /* Light blue background */\n  border: 2px solid #2f80ed; /* Darker blue border for contrast */\n  border-radius: 8px; /* Optional rounded corners */\n  box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1); /* Light shadow for depth */\n  max-width: 100%; /* Prevent overflow */\n  word-wrap: break-word; /* Prevent text overflow */\n  /* Default font size */\n  font-size: 1.75rem; /* Smaller font size for desktop (about 19px) */\n  /* Responsive adjustments */\n}\n@media (max-width: 768px) {\n  .-esm-patient-vitals__vitals-header__heading___Srnfj {\n    font-size: 1rem; /* Smaller font size for tablets (about 16px) */\n    padding: 0.25rem 0.75rem; /* Adjust padding for smaller screens */\n  }\n}\n@media (max-width: 480px) {\n  .-esm-patient-vitals__vitals-header__heading___Srnfj {\n    font-size: 0.875rem; /* Font size for mobile (about 14px) */\n    padding: 0.25rem; /* Less padding on small screens */\n  }\n}\n\n.-esm-patient-vitals__vitals-header__rowContainer___f\\+Wmh {\n  width: 100%;\n}\n\n.-esm-patient-vitals__vitals-header__row___8nanu {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  max-width: 100vw;\n}\n\n.omrs-breakpoint-lt-desktop .-esm-patient-vitals__vitals-header__row___8nanu,\n.-esm-patient-vitals__vitals-header__workspaceOpen___bYJWD .-esm-patient-vitals__vitals-header__row___8nanu {\n  display: grid;\n  grid-template-columns: repeat(4, minmax(0, 1fr));\n  column-gap: 5rem;\n}\n\n.-esm-patient-vitals__vitals-header__loading___qROQq {\n  display: flex;\n  background-color: #f4f4f4;\n  justify-content: center;\n  min-height: 3rem;\n}\n\n.-esm-patient-vitals__vitals-header__tag___t6IiR {\n  margin-right: 0;\n}\n\n.-esm-patient-vitals__vitals-header__overdueIndicator___aMN3R {\n  display: flex;\n  align-items: center;\n  min-inline-size: max-content;\n  color: #a2191f;\n}\n.-esm-patient-vitals__vitals-header__overdueIndicator___aMN3R svg {\n  margin-right: 0.25rem;\n}\n\n.-esm-patient-vitals__vitals-header__buttonContainer___igUqQ {\n  display: flex;\n  align-items: center;\n  justify-content: right;\n}\n\n.-esm-patient-vitals__vitals-header__recordVitalsButton___kpFyI {\n  font-size: var(--cds-body-compact-01-font-size, 0.875rem);\n  font-weight: var(--cds-body-compact-01-font-weight, 400);\n  line-height: var(--cds-body-compact-01-line-height, 1.28572);\n  letter-spacing: var(--cds-body-compact-01-letter-spacing, 0.16px);\n}\n.-esm-patient-vitals__vitals-header__recordVitalsButton___kpFyI:not([disabled]) svg {\n  fill: #0f62fe;\n}\n\n.-esm-patient-vitals__vitals-header__recordVitalsIconButton___GnJNF {\n  display: flex;\n  align-items: baseline;\n  justify-content: center;\n  cursor: pointer;\n  margin-left: 0.5rem;\n}\n\n.-esm-patient-vitals__vitals-header__bodyText___xc5mx, .-esm-patient-vitals__vitals-header__link___Ap0jJ {\n  font-size: var(--cds-label-01-font-size, 0.75rem);\n  font-weight: var(--cds-label-01-font-weight, 400);\n  line-height: var(--cds-label-01-line-height, 1.33333);\n  letter-spacing: var(--cds-label-01-letter-spacing, 0.32px);\n  color: #525252;\n}\n\n.-esm-patient-vitals__vitals-header__link___Ap0jJ {\n  text-decoration-line: none;\n  color: #0f62fe;\n}\n\n.-esm-patient-vitals__vitals-header__hidden___wPcqp {\n  display: none;\n}\n\nhtml[dir=rtl] .-esm-patient-vitals__vitals-header__container___2PKEF > span:nth-child(2) {\n  margin-right: 0.5rem;\n}\n\n.-esm-patient-vitals__vitals-header__modernButton___mKykl {\n  position: relative;\n  overflow: hidden;\n  border-radius: 20px;\n  padding-left: 1.5rem !important;\n  padding-right: 1.5rem !important;\n  box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);\n  transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);\n  border: none !important;\n}\n.-esm-patient-vitals__vitals-header__modernButton___mKykl::before {\n  content: \"\";\n  position: absolute;\n  top: 0;\n  left: -100%;\n  width: 100%;\n  height: 100%;\n  background: linear-gradient(90deg, rgba(255, 255, 255, 0) 0%, rgba(255, 255, 255, 0.2) 50%, rgba(255, 255, 255, 0) 100%);\n  transition: all 0.6s ease;\n  z-index: 1;\n}\n.-esm-patient-vitals__vitals-header__modernButton___mKykl::after {\n  content: \"\";\n  position: absolute;\n  bottom: -5px;\n  right: -5px;\n  width: 15px;\n  height: 15px;\n  background-color: rgba(255, 255, 255, 0.5);\n  border-radius: 50%;\n  transition: all 0.3s ease;\n  z-index: 0;\n}\n.-esm-patient-vitals__vitals-header__modernButton___mKykl:hover {\n  transform: translateY(-3px) scale(1.02);\n  box-shadow: 0 8px 20px rgba(0, 0, 0, 0.25);\n}\n.-esm-patient-vitals__vitals-header__modernButton___mKykl:hover::before {\n  left: 100%;\n}\n.-esm-patient-vitals__vitals-header__modernButton___mKykl:hover::after {\n  transform: scale(5);\n  opacity: 0;\n}\n.-esm-patient-vitals__vitals-header__modernButton___mKykl:active {\n  transform: translateY(1px);\n  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.2);\n}\n.-esm-patient-vitals__vitals-header__modernButton___mKykl .-esm-patient-vitals__vitals-header__cds--btn__icon___yXOUQ {\n  margin-left: 24px !important;\n}\n.-esm-patient-vitals__vitals-header__modernButton___mKykl {\n  display: flex !important;\n  align-items: center !important;\n  justify-content: center !important;\n}\n.-esm-patient-vitals__vitals-header__modernButton___mKykl svg {\n  transition: transform 0.3s ease;\n}\n.-esm-patient-vitals__vitals-header__modernButton___mKykl:hover svg {\n  transform: translateX(3px);\n}", "",{"version":3,"sources":["webpack://./../../node_modules/@openmrs/esm-styleguide/src/_vars.scss","webpack://./src/vitals-and-biometrics-header/vitals-header.scss","webpack://./../../node_modules/@carbon/layout/scss/generated/_spacing.scss","webpack://./../../node_modules/@carbon/type/scss/_styles.scss","webpack://./../../node_modules/@carbon/colors/index.scss"],"names":[],"mappings":"AAkCA,0EAAA;AAoBA;EACE,mBAAA;EACA,mBAAA;EACA,mBAAA;EACA,yBAAA;EACA,+BAAA;EACA,oGAAA;EACA,2GAAA;ACpDF;;ADgEA,8DAAA;ACpEA;EACE,yBDewB;ECdxB,yBAAA;EACA,gCAAA;AAQF;;AALA;EACE,aAAA;EACA,8BAAA;EACA,mBAAA;EACA,gBC0BW;EDzBX,aAAA;EACA,2BAAA;AAQF;;AALA;EACE,aAAA;EACA,8BAAA;EACA,mBAAA;EACA,eAAA;EACA,gBC0BW;EDzBX,aAAA;EACA,2BAAA;EACA,gCAAA;AAQF;AANE;EACE,mBAAA;EACA,UAAA;EACA,aAAA;EACA,mBAAA;EACA,uBAAA;EACA,WAAA;AAQJ;AALE;EACE,mBCnBS;AD0Bb;;AAHA;EACE,8BAAA,EAAA,iBAAA;EACA,mBAAA,EAAA,0CAAA;EACA,YAAA;AAMF;;AAHA;EACE,+BAAA;EACA,8BAAA;EACA,oCAAA,EAAA,gBAAA;EACA,8BAAA;EACA,6BAAA;EACA,kCAAA;EACA,kBAAA,EAAA,cAAA;EACA,gBAAA;EACA,sCAAA,EAAA,mCAAA;EACA,2BAAA;EACA,gBCpBW;AD0Bb;;AAHA;EACE,oCAAA,EAAA,iBAAA;EACA,sBAAA;AAMF;;AAHA;EACE,+BAAA;AAMF;;AAJA;EACE,mBAAA;EACA,yBAAA;EACA,kBAAA;EACA,aAAA;EACA,mBAAA;EACA,eAAA;AAOF;;AAJA;EEixBI,iDAAA;EAAA,gDAAA;EAAA,oDAAA;EAAA,yDAAA;EF/wBF,cD7EM;EC8EN,gBAAA;EACA,SAAA;EACA,mBAAA;EACA,sBAAA;EACA,iBAAA;EACA,mBAAA;EACA,kBAAA;AAUF;;AAPA;EACE,aAAA;EACA,qBAAA;EACA,mBAAA;EACA,oBAAA;AAUF;;AAPA;EE8vBI,wDAAA;EAAA,2DAAA;EAAA,6DAAA;EAAA,+DAAA;EF7vB8C,0CAAA;EAChD,yBAAA,EAAA,kCAAA;EACA,kBAAA,EAAA,oBAAA;EACA,oBAAA,EAAA,gCAAA;EACA,mBC1EW,ED0EwB,6BAAA;EACnC,yBAAA,EAAA,0BAAA;EACA,yBAAA,EAAA,oCAAA;EACA,kBAAA,EAAA,6BAAA;EACA,wCAAA,EAAA,2BAAA;EACA,eAAA,EAAA,qBAAA;EACA,qBAAA,EAAA,0BAAA;EAEA,sBAAA;EACA,kBAAA,EAAA,+CAAA;EAEA,2BAAA;AAYF;AAXE;EAjBF;IAkBI,eAAA,EAAA,+CAAA;IACA,wBAAA,EAAA,uCAAA;EAcF;AACF;AAZE;EAtBF;IAuBI,mBAAA,EAAA,sCAAA;IACA,gBC5GS,ED4GoB,kCAAA;EAe/B;AACF;;AAZA;EACE,WAAA;AAeF;;AAZA;EACE,aAAA;EACA,8BAAA;EACA,mBAAA;EACA,gBAAA;AAeF;;AAVE;;EACE,aAAA;EACA,gDAAA;EACA,gBCnFS;ADiGb;;AAVA;EACE,aAAA;EACA,yBDjIwB;ECkIxB,uBAAA;EACA,gBCrGW;ADkHb;;AAVA;EACE,eAAA;AAaF;;AAVA;EACE,aAAA;EACA,mBAAA;EACA,4BAAA;EACA,cGjEO;AH8ET;AAXE;EACE,qBCtJS;ADmKb;;AATA;EACE,aAAA;EACA,mBAAA;EACA,sBAAA;AAYF;;AATA;EEkrBI,yDAAA;EAAA,wDAAA;EAAA,4DAAA;EAAA,iEAAA;AFlqBJ;AAbE;EACE,aDvKc;ACsLlB;;AAXA;EACE,aAAA;EACA,qBAAA;EACA,uBAAA;EACA,eAAA;EACA,mBCxKW;ADsLb;;AAXA;EEkqBI,iDAAA;EAAA,iDAAA;EAAA,qDAAA;EAAA,0DAAA;EFhqBF,cD3LQ;AC4MV;;AAdA;EAEE,0BAAA;EACA,cDjLe;ACiMjB;;AAdA;EACE,aAAA;AAiBF;;AAXI;EACE,oBC7LO;AD2Mb;;AATA;EACE,kBAAA;EACA,gBAAA;EACA,mBAAA;EACA,+BAAA;EACA,gCAAA;EACA,yCAAA;EACA,4DAAA;EACA,uBAAA;AAYF;AAVE;EACE,WAAA;EACA,kBAAA;EACA,MAAA;EACA,WAAA;EACA,WAAA;EACA,YAAA;EACA,wHAAA;EAMA,yBAAA;EACA,UAAA;AAOJ;AAJE;EACE,WAAA;EACA,kBAAA;EACA,YAAA;EACA,WAAA;EACA,WAAA;EACA,YAAA;EACA,0CAAA;EACA,kBAAA;EACA,yBAAA;EACA,UAAA;AAMJ;AAHE;EACE,uCAAA;EACA,0CAAA;AAKJ;AAHI;EACE,UAAA;AAKN;AAFI;EACE,mBAAA;EACA,UAAA;AAIN;AAAE;EACE,0BAAA;EACA,yCAAA;AAEJ;AAEE;EACE,4BAAA;AAAJ;AA7DA;EAiEE,wBAAA;EACA,8BAAA;EACA,kCAAA;AADF;AAGE;EACE,+BAAA;AADJ;AAIE;EACE,0BAAA;AAFJ","sourcesContent":["@use '@carbon/layout';\n\n$ui-01: #f4f4f4;\n$ui-02: #ffffff;\n$ui-03: #e0e0e0;\n$ui-04: #8d8d8d;\n$ui-05: #161616;\n$text-02: #525252;\n$text-03: #a8a8a8;\n$ui-background: #ffffff;\n$color-gray-30: #c6c6c6;\n$color-gray-70: #525252;\n$color-gray-100: #161616;\n$color-blue-60-2: #0f62fe;\n$color-blue-10: #edf5ff;\n$color-yellow-50: #feecae;\n$carbon--red-50: #fa4d56;\n$inverse-link: #78a9ff;\n$support-02: #24a148;\n$inverse-support-03: #f1c21b;\n$warning-background: #fff8e1;\n$openmrs-background-grey: #f4f4f4;\n$danger: #da1e28;\n$interactive-01: #0f62fe;\n$field-01: #f4f4f4;\n$grey-2: #e0e0e0;\n$labeldropdown: #c6c6c6;\n\n$brand-primary-10: #d9fbfb;\n$brand-primary-20: #9ef0f0;\n$brand-primary-30: #3ddbd9;\n$brand-primary-40: #08bdba;\n$brand-primary-50: #009d9a;\n\n/* 60,70 and 80 are already declared as brand-01, 02 and 03 respectively */\n\n$brand-primary-90: #022b30;\n$brand-primary-100: #081a1c;\n\n@mixin brand-01($property) {\n  #{$property}: #005d5d;\n  #{$property}: var(--brand-01);\n}\n\n@mixin brand-02($property) {\n  #{$property}: #004144;\n  #{$property}: var(--brand-02);\n}\n\n@mixin brand-03($property) {\n  #{$property}: #007d79;\n  #{$property}: var(--brand-03);\n}\n\n:root {\n  --brand-01: #005d5d;\n  --brand-02: #004144;\n  --brand-03: #007d79;\n  --bottom-nav-height: #{layout.$spacing-10};\n  --workspace-header-height: #{layout.$spacing-09};\n  --tablet-workspace-window-height: calc(100vh - var(--omrs-navbar-height) - var(--bottom-nav-height));\n  --desktop-workspace-window-height: calc(100vh - var(--omrs-navbar-height) - var(--workspace-header-height));\n}\n\n$breakpoint-phone-min: 0px;\n$breakpoint-phone-max: 600px;\n$breakpoint-tablet-min: 601px;\n$breakpoint-tablet-max: 1023px;\n$breakpoint-small-desktop-min: 1024px;\n$breakpoint-small-desktop-max: 1439px;\n$breakpoint-large-desktop-min: 1440px;\n$breakpoint-large-desktop-max: 99999999px;\n\n/* These color variables will be removed in a future release */\n$brand-teal-01: #007d79;\n$brand-01: #005d5d;\n$brand-02: #004144;\n","@use '@carbon/colors';\r\n@use '@carbon/layout';\r\n@use '@carbon/type';\r\n@use '@openmrs/esm-styleguide/src/vars' as *;\r\n\r\n.container {\r\n  background-color: $openmrs-background-grey;\r\n  padding: layout.$spacing-03 layout.$spacing-05 layout.$spacing-05;\r\n  border-bottom: 1px solid $ui-03;\r\n}\r\n\r\n.vitalsHeader {\r\n  display: flex;\r\n  justify-content: space-between;\r\n  align-items: center;\r\n  min-height: layout.$spacing-07;\r\n  outline: none;\r\n  pointer-events: visibleFill;\r\n}\r\n\r\n.emptyStateVitalsHeader {\r\n  display: flex;\r\n  justify-content: space-between;\r\n  align-items: center;\r\n  padding: 0 layout.$spacing-05;\r\n  min-height: layout.$spacing-09;\r\n  outline: none;\r\n  pointer-events: visibleFill;\r\n  border-bottom: 1px solid $ui-03;\r\n\r\n  .container {\r\n    border-bottom: none;\r\n    padding: 0;\r\n    display: flex;\r\n    align-items: center;\r\n    justify-content: center;\r\n    gap: 1.5rem;\r\n  }\r\n\r\n  .bodyText {\r\n    margin-left: layout.$spacing-03;\r\n  }\r\n}\r\n\r\n.separator {\r\n  border-left: 2px solid #000000; /* change color */\r\n  align-self: stretch; /* makes it grow full height of siblings */\r\n  margin: 1rem;\r\n}\r\n\r\n.customButton {\r\n  display: inline-flex !important;\r\n  align-items: center !important;\r\n  background-color: #cadbf4 !important; /* custom blue */\r\n  color: rgb(0, 0, 0) !important;\r\n  border-radius: 8px !important;\r\n  padding: 0.75rem 1.5rem !important;\r\n  font-size: 1.25rem; /* text size */\r\n  font-weight: 600;\r\n  border: 1.5px solid #2f80ed !important; /* optional border for definition */\r\n  line-height: 1.5 !important;\r\n  min-height: layout.$spacing-07;\r\n}\r\n\r\n.customButton:hover {\r\n  background-color: #487be0 !important; /* subtle hover */\r\n  color: #000 !important;\r\n}\r\n\r\n.customButton .cds--btn__icon {\r\n  margin-left: 0.75rem !important;\r\n}\r\n.introBox {\r\n  background: #f0f6ff;\r\n  border: 1px solid #2f80ed;\r\n  border-radius: 8px;\r\n  padding: 1rem;\r\n  margin-bottom: 1rem;\r\n  max-width: 100%;\r\n}\r\n\r\n.introText {\r\n  @include type.type-style('body-01');\r\n  color: $ui-05;\r\n  line-height: 1.6;\r\n  margin: 0;\r\n  white-space: normal;\r\n  word-break: break-word;\r\n  font-size: medium;\r\n  font-weight: bolder;\r\n  font-size: 1.25rem;\r\n}\r\n\r\n.headerItems {\r\n  display: flex;\r\n  align-items: baseline;\r\n  flex-flow: row wrap;\r\n  gap: layout.$spacing-02 layout.$spacing-04;\r\n}\r\n\r\n.heading {\r\n  @include type.type-style('heading-compact-02'); /* Carbon Design's compact heading style */\r\n  color: $ui-05 !important; /* Light text color for contrast */\r\n  text-align: center; /* Center the text */\r\n  padding: layout.$spacing-03 layout.$spacing-05; /* Add padding around the text */\r\n  margin-bottom: layout.$spacing-05; /* Margin below the heading */\r\n  background-color: #cadbf4; /* Light blue background */\r\n  border: 2px solid #2f80ed; /* Darker blue border for contrast */\r\n  border-radius: 8px; /* Optional rounded corners */\r\n  box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1); /* Light shadow for depth */\r\n  max-width: 100%; /* Prevent overflow */\r\n  word-wrap: break-word; /* Prevent text overflow */\r\n\r\n  /* Default font size */\r\n  font-size: 1.75rem; /* Smaller font size for desktop (about 19px) */\r\n\r\n  /* Responsive adjustments */\r\n  @media (max-width: 768px) {\r\n    font-size: 1rem; /* Smaller font size for tablets (about 16px) */\r\n    padding: layout.$spacing-02 layout.$spacing-04; /* Adjust padding for smaller screens */\r\n  }\r\n\r\n  @media (max-width: 480px) {\r\n    font-size: 0.875rem; /* Font size for mobile (about 14px) */\r\n    padding: layout.$spacing-02; /* Less padding on small screens */\r\n  }\r\n}\r\n\r\n.rowContainer {\r\n  width: 100%;\r\n}\r\n\r\n.row {\r\n  display: flex;\r\n  justify-content: space-between;\r\n  align-items: center;\r\n  max-width: 100vw;\r\n}\r\n\r\n:global(.omrs-breakpoint-lt-desktop),\r\n.workspaceOpen {\r\n  .row {\r\n    display: grid;\r\n    grid-template-columns: repeat(4, minmax(0, 1fr));\r\n    column-gap: layout.$spacing-11;\r\n  }\r\n}\r\n\r\n.loading {\r\n  display: flex;\r\n  background-color: $openmrs-background-grey;\r\n  justify-content: center;\r\n  min-height: layout.$spacing-09;\r\n}\r\n\r\n.tag {\r\n  margin-right: 0;\r\n}\r\n\r\n.overdueIndicator {\r\n  display: flex;\r\n  align-items: center;\r\n  min-inline-size: max-content;\r\n  color: colors.$red-70;\r\n\r\n  svg {\r\n    margin-right: layout.$spacing-02;\r\n  }\r\n}\r\n\r\n.buttonContainer {\r\n  display: flex;\r\n  align-items: center;\r\n  justify-content: right;\r\n}\r\n\r\n.recordVitalsButton {\r\n  @include type.type-style('body-compact-01');\r\n\r\n  &:not([disabled]) svg {\r\n    fill: $color-blue-60-2;\r\n  }\r\n}\r\n\r\n.recordVitalsIconButton {\r\n  display: flex;\r\n  align-items: baseline;\r\n  justify-content: center;\r\n  cursor: pointer;\r\n  margin-left: layout.$spacing-03;\r\n}\r\n\r\n.bodyText {\r\n  @include type.type-style('label-01');\r\n  color: $text-02;\r\n}\r\n\r\n.link {\r\n  @extend .bodyText;\r\n  text-decoration-line: none;\r\n  color: $interactive-01;\r\n}\r\n.hidden {\r\n  display: none;\r\n}\r\n\r\n// Overriding styles for RTL support\r\nhtml[dir='rtl'] {\r\n  .container {\r\n    & > span:nth-child(2) {\r\n      margin-right: layout.$spacing-03;\r\n    }\r\n  }\r\n}\r\n\r\n.modernButton {\r\n  position: relative;\r\n  overflow: hidden;\r\n  border-radius: 20px;\r\n  padding-left: 1.5rem !important;\r\n  padding-right: 1.5rem !important;\r\n  box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);\r\n  transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);\r\n  border: none !important;\r\n\r\n  &::before {\r\n    content: '';\r\n    position: absolute;\r\n    top: 0;\r\n    left: -100%;\r\n    width: 100%;\r\n    height: 100%;\r\n    background: linear-gradient(\r\n      90deg,\r\n      rgba(255, 255, 255, 0) 0%,\r\n      rgba(255, 255, 255, 0.2) 50%,\r\n      rgba(255, 255, 255, 0) 100%\r\n    );\r\n    transition: all 0.6s ease;\r\n    z-index: 1;\r\n  }\r\n\r\n  &::after {\r\n    content: '';\r\n    position: absolute;\r\n    bottom: -5px;\r\n    right: -5px;\r\n    width: 15px;\r\n    height: 15px;\r\n    background-color: rgba(255, 255, 255, 0.5);\r\n    border-radius: 50%;\r\n    transition: all 0.3s ease;\r\n    z-index: 0;\r\n  }\r\n\r\n  &:hover {\r\n    transform: translateY(-3px) scale(1.02);\r\n    box-shadow: 0 8px 20px rgba(0, 0, 0, 0.25);\r\n\r\n    &::before {\r\n      left: 100%;\r\n    }\r\n\r\n    &::after {\r\n      transform: scale(5);\r\n      opacity: 0;\r\n    }\r\n  }\r\n\r\n  &:active {\r\n    transform: translateY(1px);\r\n    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.2);\r\n  }\r\n\r\n  // Fix spacing between text and icon - target Carbon button internalsss\r\n  .cds--btn__icon {\r\n    margin-left: 24px !important; // Increased spacing between text and icon\r\n  }\r\n\r\n  // Ensure text and icon are properly aligned\r\n  display: flex !important;\r\n  align-items: center !important;\r\n  justify-content: center !important;\r\n\r\n  svg {\r\n    transition: transform 0.3s ease;\r\n  }\r\n\r\n  &:hover svg {\r\n    transform: translateX(3px);\r\n  }\r\n}\r\n","// Code generated by @carbon/layout. DO NOT EDIT.\n//\n// Copyright IBM Corp. 2018, 2023\n//\n// This source code is licensed under the Apache-2.0 license found in the\n// LICENSE file in the root directory of this source tree.\n//\n\n/// @type Number\n/// @access public\n/// @group @carbon/layout\n$spacing-01: 0.125rem !default;\n\n/// @type Number\n/// @access public\n/// @group @carbon/layout\n$spacing-02: 0.25rem !default;\n\n/// @type Number\n/// @access public\n/// @group @carbon/layout\n$spacing-03: 0.5rem !default;\n\n/// @type Number\n/// @access public\n/// @group @carbon/layout\n$spacing-04: 0.75rem !default;\n\n/// @type Number\n/// @access public\n/// @group @carbon/layout\n$spacing-05: 1rem !default;\n\n/// @type Number\n/// @access public\n/// @group @carbon/layout\n$spacing-06: 1.5rem !default;\n\n/// @type Number\n/// @access public\n/// @group @carbon/layout\n$spacing-07: 2rem !default;\n\n/// @type Number\n/// @access public\n/// @group @carbon/layout\n$spacing-08: 2.5rem !default;\n\n/// @type Number\n/// @access public\n/// @group @carbon/layout\n$spacing-09: 3rem !default;\n\n/// @type Number\n/// @access public\n/// @group @carbon/layout\n$spacing-10: 4rem !default;\n\n/// @type Number\n/// @access public\n/// @group @carbon/layout\n$spacing-11: 5rem !default;\n\n/// @type Number\n/// @access public\n/// @group @carbon/layout\n$spacing-12: 6rem !default;\n\n/// @type Number\n/// @access public\n/// @group @carbon/layout\n$spacing-13: 10rem !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/layout\n$spacing: (\n  spacing-01: $spacing-01,\n  spacing-02: $spacing-02,\n  spacing-03: $spacing-03,\n  spacing-04: $spacing-04,\n  spacing-05: $spacing-05,\n  spacing-06: $spacing-06,\n  spacing-07: $spacing-07,\n  spacing-08: $spacing-08,\n  spacing-09: $spacing-09,\n  spacing-10: $spacing-10,\n  spacing-11: $spacing-11,\n  spacing-12: $spacing-12,\n  spacing-13: $spacing-13,\n);\n","//\n// Copyright IBM Corp. 2018, 2023\n//\n// This source code is licensed under the Apache-2.0 license found in the\n// LICENSE file in the root directory of this source tree.\n//\n\n// stylelint-disable number-max-precision\n\n@use 'sass:map';\n@use 'sass:math';\n@use '@carbon/grid/scss/config' as gridconfig;\n@use '@carbon/grid/scss/breakpoint' as grid;\n@use 'prefix' as *;\n@use 'font-family';\n@use 'scale';\n\n/// @type Map\n/// @access public\n/// @deprecated\n/// @group @carbon/type\n$caption-01: (\n  font-size: scale.type-scale(1),\n  font-weight: font-family.font-weight('regular'),\n  line-height: 1.33333,\n  letter-spacing: 0.32px,\n) !default;\n\n/// @type Map\n/// @access public\n/// @deprecated\n/// @group @carbon/type\n$caption-02: (\n  font-size: scale.type-scale(2),\n  font-weight: font-family.font-weight('regular'),\n  line-height: 1.28572,\n  letter-spacing: 0.32px,\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$label-01: (\n  font-size: scale.type-scale(1),\n  font-weight: font-family.font-weight('regular'),\n  line-height: 1.33333,\n  letter-spacing: 0.32px,\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$label-02: (\n  font-size: scale.type-scale(2),\n  font-weight: font-family.font-weight('regular'),\n  line-height: 1.28572,\n  letter-spacing: 0.16px,\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$legal-01: (\n  font-size: scale.type-scale(1),\n  font-weight: font-family.font-weight('regular'),\n  line-height: 1.33333,\n  letter-spacing: 0.32px,\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$legal-02: (\n  font-size: scale.type-scale(2),\n  font-weight: font-family.font-weight('regular'),\n  line-height: 1.28572,\n  letter-spacing: 0.16px,\n) !default;\n\n/// @type Map\n/// @access public\n/// @deprecated\n/// @group @carbon/type\n$helper-text-01: (\n  font-size: scale.type-scale(1),\n  line-height: 1.33333,\n  letter-spacing: 0.32px,\n) !default;\n\n/// @type Map\n/// @access public\n/// @deprecated\n/// @group @carbon/type\n$helper-text-02: (\n  font-size: scale.type-scale(2),\n  font-weight: font-family.font-weight('regular'),\n  line-height: 1.28572,\n  letter-spacing: 0.16px,\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$body-short-01: (\n  font-size: scale.type-scale(2),\n  font-weight: font-family.font-weight('regular'),\n  line-height: 1.28572,\n  letter-spacing: 0.16px,\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$body-compact-01: $body-short-01 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$body-long-01: (\n  font-size: scale.type-scale(2),\n  font-weight: font-family.font-weight('regular'),\n  line-height: 1.42857,\n  letter-spacing: 0.16px,\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$body-01: $body-long-01 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$body-short-02: (\n  font-size: scale.type-scale(3),\n  font-weight: font-family.font-weight('regular'),\n  line-height: 1.375,\n  letter-spacing: 0,\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$body-compact-02: $body-short-02 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$body-long-02: (\n  font-size: scale.type-scale(3),\n  font-weight: font-family.font-weight('regular'),\n  line-height: 1.5,\n  letter-spacing: 0,\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$body-02: $body-long-02 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$code-01: (\n  font-family: font-family.font-family('mono'),\n  font-size: scale.type-scale(1),\n  font-weight: font-family.font-weight('regular'),\n  line-height: 1.33333,\n  letter-spacing: 0.32px,\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$code-02: (\n  font-family: font-family.font-family('mono'),\n  font-size: scale.type-scale(2),\n  font-weight: font-family.font-weight('regular'),\n  line-height: 1.42857,\n  letter-spacing: 0.32px,\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$heading-01: (\n  font-size: scale.type-scale(2),\n  font-weight: font-family.font-weight('semibold'),\n  line-height: 1.42857,\n  letter-spacing: 0.16px,\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$productive-heading-01: (\n  font-size: scale.type-scale(2),\n  font-weight: font-family.font-weight('semibold'),\n  line-height: 1.28572,\n  letter-spacing: 0.16px,\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$heading-compact-01: $productive-heading-01 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$heading-02: (\n  font-size: scale.type-scale(3),\n  font-weight: font-family.font-weight('semibold'),\n  line-height: 1.5,\n  letter-spacing: 0,\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$productive-heading-02: (\n  font-size: scale.type-scale(3),\n  font-weight: font-family.font-weight('semibold'),\n  line-height: 1.375,\n  letter-spacing: 0,\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$heading-compact-02: $productive-heading-02 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$productive-heading-03: (\n  font-size: scale.type-scale(5),\n  font-weight: font-family.font-weight('regular'),\n  line-height: 1.4,\n  letter-spacing: 0,\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$heading-03: $productive-heading-03 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$productive-heading-04: (\n  font-size: scale.type-scale(7),\n  font-weight: font-family.font-weight('regular'),\n  line-height: 1.28572,\n  letter-spacing: 0,\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$heading-04: $productive-heading-04 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$productive-heading-05: (\n  font-size: scale.type-scale(8),\n  font-weight: font-family.font-weight('regular'),\n  line-height: 1.25,\n  letter-spacing: 0,\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$heading-05: $productive-heading-05 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$productive-heading-06: (\n  font-size: scale.type-scale(10),\n  font-weight: font-family.font-weight('light'),\n  // Extra digit needed for precision in Chrome\n  line-height: 1.199,\n  letter-spacing: 0,\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$heading-06: $productive-heading-06 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$productive-heading-07: (\n  font-size: scale.type-scale(12),\n  font-weight: font-family.font-weight('light'),\n  line-height: 1.19,\n  letter-spacing: 0,\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$heading-07: $productive-heading-07 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$expressive-heading-01: $heading-01 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$expressive-heading-02: $heading-02 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$expressive-heading-03: (\n  font-size: scale.type-scale(5),\n  font-weight: font-family.font-weight('regular'),\n  line-height: 1.4,\n  letter-spacing: 0,\n  breakpoints: (\n    xlg: (\n      font-size: scale.type-scale(5),\n      line-height: 1.4,\n    ),\n    max: (\n      font-size: scale.type-scale(6),\n      line-height: 1.334,\n    ),\n  ),\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$fluid-heading-03: $expressive-heading-03 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$expressive-heading-04: (\n  font-size: scale.type-scale(7),\n  font-weight: font-family.font-weight('regular'),\n  line-height: 1.28572,\n  letter-spacing: 0,\n  breakpoints: (\n    xlg: (\n      font-size: scale.type-scale(8),\n      line-height: 1.25,\n      font-weight: font-family.font-weight('regular'),\n    ),\n    max: (\n      font-size: scale.type-scale(8),\n      font-weight: font-family.font-weight('regular'),\n    ),\n  ),\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$fluid-heading-04: $expressive-heading-04 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$expressive-heading-05: (\n  font-size: scale.type-scale(8),\n  font-weight: font-family.font-weight('regular'),\n  line-height: 1.25,\n  letter-spacing: 0,\n  breakpoints: (\n    md: (\n      font-size: scale.type-scale(9),\n      font-weight: font-family.font-weight('light'),\n      line-height: 1.22,\n    ),\n    lg: (\n      font-size: scale.type-scale(10),\n      line-height: 1.19,\n    ),\n    xlg: (\n      font-size: scale.type-scale(11),\n      line-height: 1.17,\n    ),\n    max: (\n      font-size: scale.type-scale(13),\n    ),\n  ),\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$fluid-heading-05: $expressive-heading-05 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$expressive-heading-06: (\n  font-size: scale.type-scale(8),\n  font-weight: font-family.font-weight('semibold'),\n  line-height: 1.25,\n  letter-spacing: 0,\n  breakpoints: (\n    md: (\n      font-size: scale.type-scale(9),\n      line-height: 1.22,\n    ),\n    lg: (\n      font-size: scale.type-scale(10),\n      line-height: 1.19,\n    ),\n    xlg: (\n      font-size: scale.type-scale(11),\n      line-height: 1.17,\n    ),\n    max: (\n      font-size: scale.type-scale(13),\n    ),\n  ),\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$fluid-heading-06: $expressive-heading-06 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$expressive-paragraph-01: (\n  font-size: scale.type-scale(6),\n  font-weight: font-family.font-weight('light'),\n  line-height: 1.334,\n  letter-spacing: 0,\n  breakpoints: (\n    lg: (\n      font-size: scale.type-scale(7),\n      line-height: 1.28572,\n    ),\n    max: (\n      font-size: scale.type-scale(8),\n      line-height: 1.25,\n    ),\n  ),\n);\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$fluid-paragraph-01: $expressive-paragraph-01 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$quotation-01: (\n  font-family: font-family.font-family('serif'),\n  font-size: scale.type-scale(5),\n  font-weight: font-family.font-weight('regular'),\n  line-height: 1.3,\n  letter-spacing: 0,\n  breakpoints: (\n    md: (\n      font-size: scale.type-scale(5),\n    ),\n    lg: (\n      font-size: scale.type-scale(6),\n      line-height: 1.334,\n    ),\n    xlg: (\n      font-size: scale.type-scale(7),\n      line-height: 1.28572,\n    ),\n    max: (\n      font-size: scale.type-scale(8),\n      line-height: 1.25,\n    ),\n  ),\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$fluid-quotation-01: $quotation-01 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$quotation-02: (\n  font-family: font-family.font-family('serif'),\n  font-size: scale.type-scale(8),\n  font-weight: font-family.font-weight('light'),\n  line-height: 1.25,\n  letter-spacing: 0,\n  breakpoints: (\n    md: (\n      font-size: scale.type-scale(9),\n      line-height: 1.22,\n    ),\n    lg: (\n      font-size: scale.type-scale(10),\n      line-height: 1.19,\n    ),\n    xlg: (\n      font-size: scale.type-scale(11),\n      line-height: 1.17,\n    ),\n    max: (\n      font-size: scale.type-scale(13),\n    ),\n  ),\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$fluid-quotation-02: $quotation-02 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$display-01: (\n  font-size: scale.type-scale(10),\n  font-weight: font-family.font-weight('light'),\n  line-height: 1.19,\n  letter-spacing: 0,\n  breakpoints: (\n    md: (\n      font-size: scale.type-scale(10),\n    ),\n    lg: (\n      font-size: scale.type-scale(12),\n    ),\n    xlg: (\n      font-size: scale.type-scale(13),\n      line-height: 1.17,\n    ),\n    max: (\n      font-size: scale.type-scale(15),\n      line-height: 1.13,\n    ),\n  ),\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$fluid-display-01: $display-01 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$display-02: (\n  font-size: scale.type-scale(10),\n  font-weight: font-family.font-weight('semibold'),\n  line-height: 1.19,\n  letter-spacing: 0,\n  breakpoints: (\n    md: (\n      font-size: scale.type-scale(10),\n    ),\n    lg: (\n      font-size: scale.type-scale(12),\n    ),\n    xlg: (\n      font-size: scale.type-scale(13),\n      line-height: 1.16,\n    ),\n    max: (\n      font-size: scale.type-scale(15),\n      line-height: 1.13,\n    ),\n  ),\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$fluid-display-02: $display-02 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$display-03: (\n  font-size: scale.type-scale(10),\n  font-weight: font-family.font-weight('light'),\n  line-height: 1.19,\n  letter-spacing: 0,\n  breakpoints: (\n    md: (\n      font-size: scale.type-scale(12),\n      line-height: 1.18,\n    ),\n    lg: (\n      font-size: scale.type-scale(13),\n      line-height: 1.16,\n      letter-spacing: -0.64px,\n    ),\n    xlg: (\n      font-size: scale.type-scale(15),\n      line-height: 1.13,\n      letter-spacing: -0.64px,\n    ),\n    max: (\n      font-size: scale.type-scale(16),\n      line-height: 1.11,\n      letter-spacing: -0.96px,\n    ),\n  ),\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$fluid-display-03: $display-03 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$display-04: (\n  font-size: scale.type-scale(10),\n  font-weight: font-family.font-weight('light'),\n  line-height: 1.19,\n  letter-spacing: 0,\n  breakpoints: (\n    md: (\n      font-size: scale.type-scale(14),\n      line-height: 1.15,\n    ),\n    lg: (\n      font-size: scale.type-scale(17),\n      line-height: 1.11,\n      letter-spacing: -0.64px,\n    ),\n    xlg: (\n      font-size: scale.type-scale(20),\n      line-height: 1.07,\n      letter-spacing: -0.64px,\n    ),\n    max: (\n      font-size: scale.type-scale(23),\n      line-height: 1.05,\n      letter-spacing: -0.96px,\n    ),\n  ),\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$fluid-display-04: $display-04 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$tokens: (\n  caption-01: $caption-01,\n  caption-02: $caption-02,\n  label-01: $label-01,\n  label-02: $label-02,\n  helper-text-01: $helper-text-01,\n  helper-text-02: $helper-text-02,\n  body-short-01: $body-short-01,\n  body-short-02: $body-short-02,\n  body-long-01: $body-long-01,\n  body-long-02: $body-long-02,\n  code-01: $code-01,\n  code-02: $code-02,\n  heading-01: $heading-01,\n  heading-02: $heading-02,\n  productive-heading-01: $productive-heading-01,\n  productive-heading-02: $productive-heading-02,\n  productive-heading-03: $productive-heading-03,\n  productive-heading-04: $productive-heading-04,\n  productive-heading-05: $productive-heading-05,\n  productive-heading-06: $productive-heading-06,\n  productive-heading-07: $productive-heading-07,\n  expressive-paragraph-01: $expressive-paragraph-01,\n  expressive-heading-01: $expressive-heading-01,\n  expressive-heading-02: $expressive-heading-02,\n  expressive-heading-03: $expressive-heading-03,\n  expressive-heading-04: $expressive-heading-04,\n  expressive-heading-05: $expressive-heading-05,\n  expressive-heading-06: $expressive-heading-06,\n  quotation-01: $quotation-01,\n  quotation-02: $quotation-02,\n  display-01: $display-01,\n  display-02: $display-02,\n  display-03: $display-03,\n  display-04: $display-04,\n  // V11 Tokens\n  legal-01: $legal-01,\n  legal-02: $legal-02,\n  body-compact-01: $body-compact-01,\n  body-compact-02: $body-compact-02,\n  heading-compact-01: $heading-compact-01,\n  heading-compact-02: $heading-compact-02,\n  body-01: $body-01,\n  body-02: $body-02,\n  heading-03: $heading-03,\n  heading-04: $heading-04,\n  heading-05: $heading-05,\n  heading-06: $heading-06,\n  heading-07: $heading-07,\n  fluid-heading-03: $fluid-heading-03,\n  fluid-heading-04: $fluid-heading-04,\n  fluid-heading-05: $fluid-heading-05,\n  fluid-heading-06: $fluid-heading-06,\n  fluid-paragraph-01: $fluid-paragraph-01,\n  fluid-quotation-01: $fluid-quotation-01,\n  fluid-quotation-02: $fluid-quotation-02,\n  fluid-display-01: $fluid-display-01,\n  fluid-display-02: $fluid-display-02,\n  fluid-display-03: $fluid-display-03,\n  fluid-display-04: $fluid-display-04,\n) !default;\n\n/// @param {Map} $map\n/// @access public\n/// @group @carbon/type\n@mixin properties($map) {\n  @each $name, $value in $map {\n    #{$name}: $value;\n  }\n}\n\n/// @param {Number} $value - Number with units\n/// @return {Number} Without units\n/// @access public\n/// @group @carbon/type\n@function strip-unit($value) {\n  @return math.div($value, $value * 0 + 1);\n}\n\n/// This helper includes fluid type styles for the given token value. Fluid type\n/// means that the `font-size` is computed using `calc()` in order to be\n/// determined by the screen size instead of a breakpoint. As a result, fluid\n/// styles should be used with caution in fixed width contexts.\n///\n/// In addition, we make use of %-based line-heights so that the line-height of\n/// each type style is computed correctly due to the dynamic nature of the\n/// `font-size`.\n///\n/// Most of the logic for this work comes from CSS Tricks:\n/// https://css-tricks.com/snippets/css/fluid-typography/\n///\n/// @param {Map} $type-styles - The value of a given type token\n/// @param {Map} $breakpoints [$grid-breakpoints] - Custom breakpoints to use\n/// @access public\n/// @group @carbon/type\n@mixin fluid-type($type-styles, $breakpoints: gridconfig.$grid-breakpoints) {\n  // Include the initial styles for the given token by default without any\n  // media query guard. This includes `font-size` as a fallback in the case\n  // that a browser does not support `calc()`\n  @include properties(map.remove($type-styles, breakpoints));\n  // We also need to include the `sm` styles by default since they don't\n  // appear in the fluid styles for tokens\n  @include fluid-type-size($type-styles, sm, $breakpoints);\n\n  // Finally, we need to go through all the breakpoints defined in the type\n  // token and apply the properties and fluid type size for that given\n  // breakpoint\n  @each $name, $values in map.get($type-styles, breakpoints) {\n    @include grid.breakpoint($name) {\n      @include properties($values);\n      @include fluid-type-size($type-styles, $name, $breakpoints);\n    }\n  }\n}\n\n/// Computes the fluid `font-size` for a given type style and breakpoint\n/// @param {Map} $type-styles - The styles for a given token\n/// @param {String} $name - The name of the breakpoint to which we apply the fluid\n/// @param {Map} $breakpoints [$grid-breakpoints] - The breakpoints for the grid system\n/// @access public\n/// @group @carbon/type\n@mixin fluid-type-size(\n  $type-styles,\n  $name,\n  $breakpoints: gridconfig.$grid-breakpoints\n) {\n  // Get the information about the breakpoint we're currently working in. Useful\n  // for getting initial width information\n  $breakpoint: map.get($breakpoints, $name);\n\n  // Our fluid styles are captured under the 'breakpoints' property in our type\n  // styles map. These define what values to treat as `max-` variables below\n  $fluid-sizes: map.get($type-styles, breakpoints);\n  $fluid-breakpoint: ();\n  // Special case for `sm` because the styles for small are on the type style\n  // directly\n  @if $name == sm {\n    $fluid-breakpoint: map.remove($type-styles, breakpoints);\n  } @else {\n    $fluid-breakpoint: map.get($fluid-sizes, $name);\n  }\n\n  // Initialize our font-sizes to the default size for the type style\n  $max-font-size: map.get($type-styles, font-size);\n  $min-font-size: map.get($type-styles, font-size);\n  @if map.has-key($fluid-breakpoint, font-size) {\n    $min-font-size: map.get($fluid-breakpoint, font-size);\n  }\n\n  // Initialize our min and max width to the width of the current breakpoint\n  $max-vw: map.get($breakpoint, width);\n  $min-vw: map.get($breakpoint, width);\n\n  // We can use `breakpoint-next` to see if there is another breakpoint we can\n  // use to update `max-font-size` and `max-vw` with larger values\n  $next-breakpoint-available: grid.breakpoint-next($name, $breakpoints);\n  $next-fluid-breakpoint-name: null;\n\n  // We need to figure out what the next available fluid breakpoint is for our\n  // given $type-styles. In this loop we try and iterate through breakpoints\n  // until we either manually set $next-breakpoint-available to null or\n  // `breakpoint-next` returns null.\n  @while $next-breakpoint-available {\n    @if map.has-key($fluid-sizes, $next-breakpoint-available) {\n      $next-fluid-breakpoint-name: $next-breakpoint-available;\n      $next-breakpoint-available: null;\n    } @else {\n      $next-breakpoint-available: grid.breakpoint-next(\n        $next-breakpoint-available,\n        $breakpoints\n      );\n    }\n  }\n\n  // If we have found the next available fluid breakpoint name, then we know\n  // that we have values that we can use to set max-font-size and max-vw as both\n  // values derive from the next breakpoint\n  @if $next-fluid-breakpoint-name {\n    $next-fluid-breakpoint: map.get($breakpoints, $next-fluid-breakpoint-name);\n    $max-font-size: map.get(\n      map.get($fluid-sizes, $next-fluid-breakpoint-name),\n      font-size\n    );\n    $max-vw: map.get($next-fluid-breakpoint, width);\n\n    // prettier-ignore\n    font-size: calc(#{$min-font-size} +\n      #{strip-unit($max-font-size - $min-font-size)} *\n      ((100vw - #{$min-vw}) / #{strip-unit($max-vw - $min-vw)})\n    );\n  } @else {\n    // Otherwise, just default to setting the font size found from the type\n    // style or the given fluid breakpoint in the type style\n    font-size: $min-font-size;\n  }\n}\n\n// TODO move following variable and `custom-property` mixin into shared file for\n// both `@carbon/type` and `@carbon/themes`\n\n/// @access private\n/// @group @carbon/type\n@mixin custom-properties($name, $value) {\n  @each $property, $value in $value {\n    #{$property}: var(\n      --#{$custom-property-prefix}-#{$name}-#{$property},\n      #{$value}\n    );\n  }\n}\n\n/// Helper mixin to include the styles for a given token in any selector in your\n/// project. Also includes an optional fluid option that will enable fluid\n/// styles for the token if they are defined. Fluid styles will cause the\n/// token's font-size to be computed based on the viewport size. As a result, use\n/// with caution in fixed contexts.\n/// @param {String} $name - The name of the token to get the styles for\n/// @param {Boolean} $fluid [false] - Specify whether to include fluid styles for the\n/// @param {Map} $breakpoints [$grid-breakpoints] - Provide a custom breakpoint map to use\n/// @access public\n/// @group @carbon/type\n@mixin type-style(\n  $name,\n  $fluid: false,\n  $breakpoints: gridconfig.$grid-breakpoints\n) {\n  @if not map.has-key($tokens, $name) {\n    @error 'Unable to find a token with the name: `#{$name}`';\n  }\n\n  $token: map.get($tokens, $name);\n\n  // If $fluid is set to true and the token has breakpoints defined for fluid\n  // styles, delegate to the fluid-type helper for the given token\n  @if $fluid == true and map.has-key($token, 'breakpoints') {\n    @include fluid-type($token, $breakpoints);\n  } @else {\n    @include custom-properties($name, $token);\n  }\n}\n","// Code generated by @carbon/colors. DO NOT EDIT.\n//\n// Copyright IBM Corp. 2018, 2023\n//\n// This source code is licensed under the Apache-2.0 license found in the\n// LICENSE file in the root directory of this source tree.\n//\n\n$black: #000000 !default;\n$white: #ffffff !default;\n\n$black-100: #000000 !default;\n$blue-10: #edf5ff !default;\n$blue-20: #d0e2ff !default;\n$blue-30: #a6c8ff !default;\n$blue-40: #78a9ff !default;\n$blue-50: #4589ff !default;\n$blue-60: #0f62fe !default;\n$blue-70: #0043ce !default;\n$blue-80: #002d9c !default;\n$blue-90: #001d6c !default;\n$blue-100: #001141 !default;\n$cool-gray-10: #f2f4f8 !default;\n$cool-gray-20: #dde1e6 !default;\n$cool-gray-30: #c1c7cd !default;\n$cool-gray-40: #a2a9b0 !default;\n$cool-gray-50: #878d96 !default;\n$cool-gray-60: #697077 !default;\n$cool-gray-70: #4d5358 !default;\n$cool-gray-80: #343a3f !default;\n$cool-gray-90: #21272a !default;\n$cool-gray-100: #121619 !default;\n$cyan-10: #e5f6ff !default;\n$cyan-20: #bae6ff !default;\n$cyan-30: #82cfff !default;\n$cyan-40: #33b1ff !default;\n$cyan-50: #1192e8 !default;\n$cyan-60: #0072c3 !default;\n$cyan-70: #00539a !default;\n$cyan-80: #003a6d !default;\n$cyan-90: #012749 !default;\n$cyan-100: #061727 !default;\n$gray-10: #f4f4f4 !default;\n$gray-20: #e0e0e0 !default;\n$gray-30: #c6c6c6 !default;\n$gray-40: #a8a8a8 !default;\n$gray-50: #8d8d8d !default;\n$gray-60: #6f6f6f !default;\n$gray-70: #525252 !default;\n$gray-80: #393939 !default;\n$gray-90: #262626 !default;\n$gray-100: #161616 !default;\n$green-10: #defbe6 !default;\n$green-20: #a7f0ba !default;\n$green-30: #6fdc8c !default;\n$green-40: #42be65 !default;\n$green-50: #24a148 !default;\n$green-60: #198038 !default;\n$green-70: #0e6027 !default;\n$green-80: #044317 !default;\n$green-90: #022d0d !default;\n$green-100: #071908 !default;\n$magenta-10: #fff0f7 !default;\n$magenta-20: #ffd6e8 !default;\n$magenta-30: #ffafd2 !default;\n$magenta-40: #ff7eb6 !default;\n$magenta-50: #ee5396 !default;\n$magenta-60: #d02670 !default;\n$magenta-70: #9f1853 !default;\n$magenta-80: #740937 !default;\n$magenta-90: #510224 !default;\n$magenta-100: #2a0a18 !default;\n$orange-10: #fff2e8 !default;\n$orange-20: #ffd9be !default;\n$orange-30: #ffb784 !default;\n$orange-40: #ff832b !default;\n$orange-50: #eb6200 !default;\n$orange-60: #ba4e00 !default;\n$orange-70: #8a3800 !default;\n$orange-80: #5e2900 !default;\n$orange-90: #3e1a00 !default;\n$orange-100: #231000 !default;\n$purple-10: #f6f2ff !default;\n$purple-20: #e8daff !default;\n$purple-30: #d4bbff !default;\n$purple-40: #be95ff !default;\n$purple-50: #a56eff !default;\n$purple-60: #8a3ffc !default;\n$purple-70: #6929c4 !default;\n$purple-80: #491d8b !default;\n$purple-90: #31135e !default;\n$purple-100: #1c0f30 !default;\n$red-10: #fff1f1 !default;\n$red-20: #ffd7d9 !default;\n$red-30: #ffb3b8 !default;\n$red-40: #ff8389 !default;\n$red-50: #fa4d56 !default;\n$red-60: #da1e28 !default;\n$red-70: #a2191f !default;\n$red-80: #750e13 !default;\n$red-90: #520408 !default;\n$red-100: #2d0709 !default;\n$teal-10: #d9fbfb !default;\n$teal-20: #9ef0f0 !default;\n$teal-30: #3ddbd9 !default;\n$teal-40: #08bdba !default;\n$teal-50: #009d9a !default;\n$teal-60: #007d79 !default;\n$teal-70: #005d5d !default;\n$teal-80: #004144 !default;\n$teal-90: #022b30 !default;\n$teal-100: #081a1c !default;\n$warm-gray-10: #f7f3f2 !default;\n$warm-gray-20: #e5e0df !default;\n$warm-gray-30: #cac5c4 !default;\n$warm-gray-40: #ada8a8 !default;\n$warm-gray-50: #8f8b8b !default;\n$warm-gray-60: #726e6e !default;\n$warm-gray-70: #565151 !default;\n$warm-gray-80: #3c3838 !default;\n$warm-gray-90: #272525 !default;\n$warm-gray-100: #171414 !default;\n$white-0: #ffffff !default;\n$yellow-10: #fcf4d6 !default;\n$yellow-20: #fddc69 !default;\n$yellow-30: #f1c21b !default;\n$yellow-40: #d2a106 !default;\n$yellow-50: #b28600 !default;\n$yellow-60: #8e6a00 !default;\n$yellow-70: #684e00 !default;\n$yellow-80: #483700 !default;\n$yellow-90: #302400 !default;\n$yellow-100: #1c1500 !default;\n\n$white-hover: #e8e8e8 !default;\n$black-hover: #212121 !default;\n$blue-10-hover: #dbebff !default;\n$blue-20-hover: #b8d3ff !default;\n$blue-30-hover: #8ab6ff !default;\n$blue-40-hover: #5c97ff !default;\n$blue-50-hover: #1f70ff !default;\n$blue-60-hover: #0050e6 !default;\n$blue-70-hover: #0053ff !default;\n$blue-80-hover: #0039c7 !default;\n$blue-90-hover: #00258a !default;\n$blue-100-hover: #001f75 !default;\n$cool-gray-10-hover: #e4e9f1 !default;\n$cool-gray-20-hover: #cdd3da !default;\n$cool-gray-30-hover: #adb5bd !default;\n$cool-gray-40-hover: #9199a1 !default;\n$cool-gray-50-hover: #757b85 !default;\n$cool-gray-60-hover: #585e64 !default;\n$cool-gray-70-hover: #5d646a !default;\n$cool-gray-80-hover: #434a51 !default;\n$cool-gray-90-hover: #2b3236 !default;\n$cool-gray-100-hover: #222a2f !default;\n$cyan-10-hover: #cceeff !default;\n$cyan-20-hover: #99daff !default;\n$cyan-30-hover: #57beff !default;\n$cyan-40-hover: #059fff !default;\n$cyan-50-hover: #0f7ec8 !default;\n$cyan-60-hover: #005fa3 !default;\n$cyan-70-hover: #0066bd !default;\n$cyan-80-hover: #00498a !default;\n$cyan-90-hover: #013360 !default;\n$cyan-100-hover: #0b2947 !default;\n$gray-10-hover: #e8e8e8 !default;\n$gray-20-hover: #d1d1d1 !default;\n$gray-30-hover: #b5b5b5 !default;\n$gray-40-hover: #999999 !default;\n$gray-50-hover: #7a7a7a !default;\n$gray-60-hover: #5e5e5e !default;\n$gray-70-hover: #636363 !default;\n$gray-80-hover: #474747 !default;\n$gray-90-hover: #333333 !default;\n$gray-100-hover: #292929 !default;\n$green-10-hover: #b6f6c8 !default;\n$green-20-hover: #74e792 !default;\n$green-30-hover: #36ce5e !default;\n$green-40-hover: #3bab5a !default;\n$green-50-hover: #208e3f !default;\n$green-60-hover: #166f31 !default;\n$green-70-hover: #11742f !default;\n$green-80-hover: #05521c !default;\n$green-90-hover: #033b11 !default;\n$green-100-hover: #0d300f !default;\n$magenta-10-hover: #ffe0ef !default;\n$magenta-20-hover: #ffbdda !default;\n$magenta-30-hover: #ff94c3 !default;\n$magenta-40-hover: #ff57a0 !default;\n$magenta-50-hover: #e3176f !default;\n$magenta-60-hover: #b0215f !default;\n$magenta-70-hover: #bf1d63 !default;\n$magenta-80-hover: #8e0b43 !default;\n$magenta-90-hover: #68032e !default;\n$magenta-100-hover: #53142f !default;\n$orange-10-hover: #ffe2cc !default;\n$orange-20-hover: #ffc69e !default;\n$orange-30-hover: #ff9d57 !default;\n$orange-40-hover: #fa6800 !default;\n$orange-50-hover: #cc5500 !default;\n$orange-60-hover: #9e4200 !default;\n$orange-70-hover: #a84400 !default;\n$orange-80-hover: #753300 !default;\n$orange-90-hover: #522200 !default;\n$orange-100-hover: #421e00 !default;\n$purple-10-hover: #ede5ff !default;\n$purple-20-hover: #dcc7ff !default;\n$purple-30-hover: #c5a3ff !default;\n$purple-40-hover: #ae7aff !default;\n$purple-50-hover: #9352ff !default;\n$purple-60-hover: #7822fb !default;\n$purple-70-hover: #7c3dd6 !default;\n$purple-80-hover: #5b24ad !default;\n$purple-90-hover: #40197b !default;\n$purple-100-hover: #341c59 !default;\n$red-10-hover: #ffe0e0 !default;\n$red-20-hover: #ffc2c5 !default;\n$red-30-hover: #ff99a0 !default;\n$red-40-hover: #ff6168 !default;\n$red-50-hover: #ee0713 !default;\n$red-60-hover: #b81922 !default;\n$red-70-hover: #c21e25 !default;\n$red-80-hover: #921118 !default;\n$red-90-hover: #66050a !default;\n$red-100-hover: #540d11 !default;\n$teal-10-hover: #acf6f6 !default;\n$teal-20-hover: #57e5e5 !default;\n$teal-30-hover: #25cac8 !default;\n$teal-40-hover: #07aba9 !default;\n$teal-50-hover: #008a87 !default;\n$teal-60-hover: #006b68 !default;\n$teal-70-hover: #007070 !default;\n$teal-80-hover: #005357 !default;\n$teal-90-hover: #033940 !default;\n$teal-100-hover: #0f3034 !default;\n$warm-gray-10-hover: #f0e8e6 !default;\n$warm-gray-20-hover: #d8d0cf !default;\n$warm-gray-30-hover: #b9b3b1 !default;\n$warm-gray-40-hover: #9c9696 !default;\n$warm-gray-50-hover: #7f7b7b !default;\n$warm-gray-60-hover: #605d5d !default;\n$warm-gray-70-hover: #696363 !default;\n$warm-gray-80-hover: #4c4848 !default;\n$warm-gray-90-hover: #343232 !default;\n$warm-gray-100-hover: #2c2626 !default;\n$yellow-10-hover: #f8e6a0 !default;\n$yellow-20-hover: #fccd27 !default;\n$yellow-30-hover: #ddb00e !default;\n$yellow-40-hover: #bc9005 !default;\n$yellow-50-hover: #9e7700 !default;\n$yellow-60-hover: #755800 !default;\n$yellow-70-hover: #806000 !default;\n$yellow-80-hover: #5c4600 !default;\n$yellow-90-hover: #3d2e00 !default;\n$yellow-100-hover: #332600 !default;\n\n/// Colors from the IBM Design Language\n/// @access public\n/// @group @carbon/colors\n$colors: (\n  black: (\n    100: #000000,\n  ),\n  blue: (\n    10: #edf5ff,\n    20: #d0e2ff,\n    30: #a6c8ff,\n    40: #78a9ff,\n    50: #4589ff,\n    60: #0f62fe,\n    70: #0043ce,\n    80: #002d9c,\n    90: #001d6c,\n    100: #001141,\n  ),\n  cool-gray: (\n    10: #f2f4f8,\n    20: #dde1e6,\n    30: #c1c7cd,\n    40: #a2a9b0,\n    50: #878d96,\n    60: #697077,\n    70: #4d5358,\n    80: #343a3f,\n    90: #21272a,\n    100: #121619,\n  ),\n  cyan: (\n    10: #e5f6ff,\n    20: #bae6ff,\n    30: #82cfff,\n    40: #33b1ff,\n    50: #1192e8,\n    60: #0072c3,\n    70: #00539a,\n    80: #003a6d,\n    90: #012749,\n    100: #061727,\n  ),\n  gray: (\n    10: #f4f4f4,\n    20: #e0e0e0,\n    30: #c6c6c6,\n    40: #a8a8a8,\n    50: #8d8d8d,\n    60: #6f6f6f,\n    70: #525252,\n    80: #393939,\n    90: #262626,\n    100: #161616,\n  ),\n  green: (\n    10: #defbe6,\n    20: #a7f0ba,\n    30: #6fdc8c,\n    40: #42be65,\n    50: #24a148,\n    60: #198038,\n    70: #0e6027,\n    80: #044317,\n    90: #022d0d,\n    100: #071908,\n  ),\n  magenta: (\n    10: #fff0f7,\n    20: #ffd6e8,\n    30: #ffafd2,\n    40: #ff7eb6,\n    50: #ee5396,\n    60: #d02670,\n    70: #9f1853,\n    80: #740937,\n    90: #510224,\n    100: #2a0a18,\n  ),\n  orange: (\n    10: #fff2e8,\n    20: #ffd9be,\n    30: #ffb784,\n    40: #ff832b,\n    50: #eb6200,\n    60: #ba4e00,\n    70: #8a3800,\n    80: #5e2900,\n    90: #3e1a00,\n    100: #231000,\n  ),\n  purple: (\n    10: #f6f2ff,\n    20: #e8daff,\n    30: #d4bbff,\n    40: #be95ff,\n    50: #a56eff,\n    60: #8a3ffc,\n    70: #6929c4,\n    80: #491d8b,\n    90: #31135e,\n    100: #1c0f30,\n  ),\n  red: (\n    10: #fff1f1,\n    20: #ffd7d9,\n    30: #ffb3b8,\n    40: #ff8389,\n    50: #fa4d56,\n    60: #da1e28,\n    70: #a2191f,\n    80: #750e13,\n    90: #520408,\n    100: #2d0709,\n  ),\n  teal: (\n    10: #d9fbfb,\n    20: #9ef0f0,\n    30: #3ddbd9,\n    40: #08bdba,\n    50: #009d9a,\n    60: #007d79,\n    70: #005d5d,\n    80: #004144,\n    90: #022b30,\n    100: #081a1c,\n  ),\n  warm-gray: (\n    10: #f7f3f2,\n    20: #e5e0df,\n    30: #cac5c4,\n    40: #ada8a8,\n    50: #8f8b8b,\n    60: #726e6e,\n    70: #565151,\n    80: #3c3838,\n    90: #272525,\n    100: #171414,\n  ),\n  white: (\n    0: #ffffff,\n  ),\n  yellow: (\n    10: #fcf4d6,\n    20: #fddc69,\n    30: #f1c21b,\n    40: #d2a106,\n    50: #b28600,\n    60: #8e6a00,\n    70: #684e00,\n    80: #483700,\n    90: #302400,\n    100: #1c1500,\n  ),\n) !default;\n"],"sourceRoot":""}]);
// Exports
___CSS_LOADER_EXPORT___.locals = {
	"container": "-esm-patient-vitals__vitals-header__container___2PKEF",
	"vitalsHeader": "-esm-patient-vitals__vitals-header__vitalsHeader___nN7c6",
	"emptyStateVitalsHeader": "-esm-patient-vitals__vitals-header__emptyStateVitalsHeader___81-z0",
	"bodyText": "-esm-patient-vitals__vitals-header__bodyText___xc5mx",
	"link": "-esm-patient-vitals__vitals-header__link___Ap0jJ",
	"separator": "-esm-patient-vitals__vitals-header__separator___cZnKr",
	"customButton": "-esm-patient-vitals__vitals-header__customButton___YgXJf",
	"cds--btn__icon": "-esm-patient-vitals__vitals-header__cds--btn__icon___yXOUQ",
	"introBox": "-esm-patient-vitals__vitals-header__introBox___KZzTM",
	"introText": "-esm-patient-vitals__vitals-header__introText___6IkH9",
	"headerItems": "-esm-patient-vitals__vitals-header__headerItems___Fdj8S",
	"heading": "-esm-patient-vitals__vitals-header__heading___Srnfj",
	"rowContainer": "-esm-patient-vitals__vitals-header__rowContainer___f+Wmh",
	"row": "-esm-patient-vitals__vitals-header__row___8nanu",
	"workspaceOpen": "-esm-patient-vitals__vitals-header__workspaceOpen___bYJWD",
	"loading": "-esm-patient-vitals__vitals-header__loading___qROQq",
	"tag": "-esm-patient-vitals__vitals-header__tag___t6IiR",
	"overdueIndicator": "-esm-patient-vitals__vitals-header__overdueIndicator___aMN3R",
	"buttonContainer": "-esm-patient-vitals__vitals-header__buttonContainer___igUqQ",
	"recordVitalsButton": "-esm-patient-vitals__vitals-header__recordVitalsButton___kpFyI",
	"recordVitalsIconButton": "-esm-patient-vitals__vitals-header__recordVitalsIconButton___GnJNF",
	"hidden": "-esm-patient-vitals__vitals-header__hidden___wPcqp",
	"modernButton": "-esm-patient-vitals__vitals-header__modernButton___mKykl"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "../../node_modules/openmrs/node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[2].use[1]!../../node_modules/openmrs/node_modules/sass-loader/dist/cjs.js??ruleSet[1].rules[2].use[2]!./src/vitals/paginated-vitals.scss":
/*!*********************************************************************************************************************************************************************************************************************************!*\
  !*** ../../node_modules/openmrs/node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[2].use[1]!../../node_modules/openmrs/node_modules/sass-loader/dist/cjs.js??ruleSet[1].rules[2].use[2]!./src/vitals/paginated-vitals.scss ***!
  \*********************************************************************************************************************************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_openmrs_node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../../node_modules/openmrs/node_modules/css-loader/dist/runtime/cssWithMappingToString.js */ "../../node_modules/openmrs/node_modules/css-loader/dist/runtime/cssWithMappingToString.js");
/* harmony import */ var _node_modules_openmrs_node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_openmrs_node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_openmrs_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../../node_modules/openmrs/node_modules/css-loader/dist/runtime/api.js */ "../../node_modules/openmrs/node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_openmrs_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_openmrs_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_openmrs_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_openmrs_node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0___default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, "@charset \"UTF-8\";\n.-esm-patient-vitals__paginated-vitals__table___AxhjH td {\n  white-space: nowrap;\n  border-top: 1px solid #e0e0e0;\n  border-bottom: none !important;\n}\n\n.-esm-patient-vitals__paginated-vitals__criticallyLow___e1lPl td:nth-child(2),\n.-esm-patient-vitals__paginated-vitals__criticallyHigh___aV4Dd td:nth-child(2),\n.-esm-patient-vitals__paginated-vitals__low___sD3mz td:nth-child(2),\n.-esm-patient-vitals__paginated-vitals__high___fZjma td:nth-child(2) {\n  font-size: var(--cds-heading-compact-01-font-size, 0.875rem);\n  font-weight: var(--cds-heading-compact-01-font-weight, 600);\n  line-height: var(--cds-heading-compact-01-line-height, 1.28572);\n  letter-spacing: var(--cds-heading-compact-01-letter-spacing, 0.16px);\n}\n\n.-esm-patient-vitals__paginated-vitals__criticallyHigh___aV4Dd,\n.-esm-patient-vitals__paginated-vitals__criticallyLow___e1lPl {\n  border-top: 1px solid #ffc2c5 !important;\n  background-color: #ffd7d9 !important;\n}\n\n.-esm-patient-vitals__paginated-vitals__high___fZjma,\n.-esm-patient-vitals__paginated-vitals__low___sD3mz {\n  border-top: 1px solid #ffd9be !important;\n  background-color: #fff2e8 !important;\n}\n\n.-esm-patient-vitals__paginated-vitals__criticallyLow___e1lPl td:nth-child(2)::after {\n  content: \" ↓↓\";\n}\n\n.-esm-patient-vitals__paginated-vitals__criticallyHigh___aV4Dd td:nth-child(2)::after {\n  content: \" ↑↑\";\n}\n\n.-esm-patient-vitals__paginated-vitals__low___sD3mz td:nth-child(2)::after {\n  content: \" ↓\";\n}\n\n.-esm-patient-vitals__paginated-vitals__high___fZjma td:nth-child(2)::after {\n  content: \" ↑\";\n}\n\n.-esm-patient-vitals__paginated-vitals__off-scale-low___4AL-6 td:nth-child(2)::after {\n  content: \" ↓↓↓\";\n}\n\n.-esm-patient-vitals__paginated-vitals__off-scale-high___eOuDB td:nth-child(2)::after {\n  content: \" ↑↑↑\";\n}\n\n.-esm-patient-vitals__paginated-vitals__offScaleHigh___z2WH8,\n.-esm-patient-vitals__paginated-vitals__offScaleLow___WpL60,\n.-esm-patient-vitals__paginated-vitals__criticallyHigh___aV4Dd,\n.-esm-patient-vitals__paginated-vitals__criticallyLow___e1lPl,\n.-esm-patient-vitals__paginated-vitals__high___fZjma,\n.-esm-patient-vitals__paginated-vitals__low___sD3mz {\n  font-size: var(--cds-heading-compact-01-font-size, 0.875rem);\n  font-weight: var(--cds-heading-compact-01-font-weight, 600);\n  line-height: var(--cds-heading-compact-01-line-height, 1.28572);\n  letter-spacing: var(--cds-heading-compact-01-letter-spacing, 0.16px);\n  color: #161616 !important;\n}\n\n.-esm-patient-vitals__paginated-vitals__criticallyLow___e1lPl::after {\n  content: \" ↓↓\";\n}\n\n.-esm-patient-vitals__paginated-vitals__criticallyHigh___aV4Dd::after {\n  content: \" ↑↑\";\n}\n\n.-esm-patient-vitals__paginated-vitals__low___sD3mz::after {\n  content: \" ↓\";\n}\n\n.-esm-patient-vitals__paginated-vitals__high___fZjma::after {\n  content: \" ↑\";\n}\n\n.-esm-patient-vitals__paginated-vitals__cds--table-cell___PQ0vM {\n  white-space: pre-line;\n}", "",{"version":3,"sources":["webpack://./src/vitals/paginated-vitals.scss","webpack://./../../node_modules/@carbon/type/scss/_styles.scss"],"names":[],"mappings":"AAAA,gBAAgB;AAKd;EACE,mBAAA;EACA,6BAAA;EACA,8BAAA;AAHJ;;AAWE;;;;ECk1BE,4DAAA;EAAA,2DAAA;EAAA,+DAAA;EAAA,oEAAA;ADn1BJ;;AAMA;;EAEE,wCAAA;EACA,oCAAA;AAHF;;AAMA;;EAEE,wCAAA;EACA,oCAAA;AAHF;;AAOE;EACE,cAAA;AAJJ;;AASE;EACE,cAAA;AANJ;;AAWE;EACE,aAAA;AARJ;;AAaE;EACE,aAAA;AAVJ;;AAeE;EACE,eAAA;AAZJ;;AAiBE;EACE,eAAA;AAdJ;;AAkBA;;;;;;EC6xBI,4DAAA;EAAA,2DAAA;EAAA,+DAAA;EAAA,oEAAA;EDtxBF,yBAAA;AAZF;;AAeA;EACE,cAAA;AAZF;;AAeA;EACE,cAAA;AAZF;;AAeA;EACE,aAAA;AAZF;;AAeA;EACE,aAAA;AAZF;;AAcA;EACE,qBAAA;AAXF","sourcesContent":["@use '@carbon/colors';\r\n@use '@carbon/layout';\r\n@use '@carbon/type';\r\n\r\n.table {\r\n  td {\r\n    white-space: nowrap;\r\n    border-top: 1px solid colors.$gray-20;\r\n    border-bottom: none !important;\r\n  }\r\n}\r\n\r\n.criticallyLow,\r\n.criticallyHigh,\r\n.low,\r\n.high {\r\n  td:nth-child(2) {\r\n    @include type.type-style('heading-compact-01');\r\n  }\r\n}\r\n\r\n.criticallyHigh,\r\n.criticallyLow {\r\n  border-top: 1px solid colors.$red-20-hover !important;\r\n  background-color: colors.$red-20 !important;\r\n}\r\n\r\n.high,\r\n.low {\r\n  border-top: 1px solid colors.$orange-20 !important;\r\n  background-color: colors.$orange-10 !important;\r\n}\r\n\r\n.criticallyLow {\r\n  td:nth-child(2)::after {\r\n    content: ' ↓↓';\r\n  }\r\n}\r\n\r\n.criticallyHigh {\r\n  td:nth-child(2)::after {\r\n    content: ' ↑↑';\r\n  }\r\n}\r\n\r\n.low {\r\n  td:nth-child(2)::after {\r\n    content: ' ↓';\r\n  }\r\n}\r\n\r\n.high {\r\n  td:nth-child(2)::after {\r\n    content: ' ↑';\r\n  }\r\n}\r\n\r\n.off-scale-low {\r\n  td:nth-child(2)::after {\r\n    content: ' ↓↓↓';\r\n  }\r\n}\r\n\r\n.off-scale-high {\r\n  td:nth-child(2)::after {\r\n    content: ' ↑↑↑';\r\n  }\r\n}\r\n\r\n.offScaleHigh,\r\n.offScaleLow,\r\n.criticallyHigh,\r\n.criticallyLow,\r\n.high,\r\n.low {\r\n  @include type.type-style('heading-compact-01');\r\n  color: colors.$gray-100 !important;\r\n}\r\n\r\n.criticallyLow::after {\r\n  content: ' ↓↓';\r\n}\r\n\r\n.criticallyHigh::after {\r\n  content: ' ↑↑';\r\n}\r\n\r\n.low::after {\r\n  content: ' ↓';\r\n}\r\n\r\n.high::after {\r\n  content: ' ↑';\r\n}\r\n.cds--table-cell {\r\n  white-space: pre-line;\r\n}\r\n","//\n// Copyright IBM Corp. 2018, 2023\n//\n// This source code is licensed under the Apache-2.0 license found in the\n// LICENSE file in the root directory of this source tree.\n//\n\n// stylelint-disable number-max-precision\n\n@use 'sass:map';\n@use 'sass:math';\n@use '@carbon/grid/scss/config' as gridconfig;\n@use '@carbon/grid/scss/breakpoint' as grid;\n@use 'prefix' as *;\n@use 'font-family';\n@use 'scale';\n\n/// @type Map\n/// @access public\n/// @deprecated\n/// @group @carbon/type\n$caption-01: (\n  font-size: scale.type-scale(1),\n  font-weight: font-family.font-weight('regular'),\n  line-height: 1.33333,\n  letter-spacing: 0.32px,\n) !default;\n\n/// @type Map\n/// @access public\n/// @deprecated\n/// @group @carbon/type\n$caption-02: (\n  font-size: scale.type-scale(2),\n  font-weight: font-family.font-weight('regular'),\n  line-height: 1.28572,\n  letter-spacing: 0.32px,\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$label-01: (\n  font-size: scale.type-scale(1),\n  font-weight: font-family.font-weight('regular'),\n  line-height: 1.33333,\n  letter-spacing: 0.32px,\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$label-02: (\n  font-size: scale.type-scale(2),\n  font-weight: font-family.font-weight('regular'),\n  line-height: 1.28572,\n  letter-spacing: 0.16px,\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$legal-01: (\n  font-size: scale.type-scale(1),\n  font-weight: font-family.font-weight('regular'),\n  line-height: 1.33333,\n  letter-spacing: 0.32px,\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$legal-02: (\n  font-size: scale.type-scale(2),\n  font-weight: font-family.font-weight('regular'),\n  line-height: 1.28572,\n  letter-spacing: 0.16px,\n) !default;\n\n/// @type Map\n/// @access public\n/// @deprecated\n/// @group @carbon/type\n$helper-text-01: (\n  font-size: scale.type-scale(1),\n  line-height: 1.33333,\n  letter-spacing: 0.32px,\n) !default;\n\n/// @type Map\n/// @access public\n/// @deprecated\n/// @group @carbon/type\n$helper-text-02: (\n  font-size: scale.type-scale(2),\n  font-weight: font-family.font-weight('regular'),\n  line-height: 1.28572,\n  letter-spacing: 0.16px,\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$body-short-01: (\n  font-size: scale.type-scale(2),\n  font-weight: font-family.font-weight('regular'),\n  line-height: 1.28572,\n  letter-spacing: 0.16px,\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$body-compact-01: $body-short-01 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$body-long-01: (\n  font-size: scale.type-scale(2),\n  font-weight: font-family.font-weight('regular'),\n  line-height: 1.42857,\n  letter-spacing: 0.16px,\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$body-01: $body-long-01 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$body-short-02: (\n  font-size: scale.type-scale(3),\n  font-weight: font-family.font-weight('regular'),\n  line-height: 1.375,\n  letter-spacing: 0,\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$body-compact-02: $body-short-02 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$body-long-02: (\n  font-size: scale.type-scale(3),\n  font-weight: font-family.font-weight('regular'),\n  line-height: 1.5,\n  letter-spacing: 0,\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$body-02: $body-long-02 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$code-01: (\n  font-family: font-family.font-family('mono'),\n  font-size: scale.type-scale(1),\n  font-weight: font-family.font-weight('regular'),\n  line-height: 1.33333,\n  letter-spacing: 0.32px,\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$code-02: (\n  font-family: font-family.font-family('mono'),\n  font-size: scale.type-scale(2),\n  font-weight: font-family.font-weight('regular'),\n  line-height: 1.42857,\n  letter-spacing: 0.32px,\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$heading-01: (\n  font-size: scale.type-scale(2),\n  font-weight: font-family.font-weight('semibold'),\n  line-height: 1.42857,\n  letter-spacing: 0.16px,\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$productive-heading-01: (\n  font-size: scale.type-scale(2),\n  font-weight: font-family.font-weight('semibold'),\n  line-height: 1.28572,\n  letter-spacing: 0.16px,\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$heading-compact-01: $productive-heading-01 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$heading-02: (\n  font-size: scale.type-scale(3),\n  font-weight: font-family.font-weight('semibold'),\n  line-height: 1.5,\n  letter-spacing: 0,\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$productive-heading-02: (\n  font-size: scale.type-scale(3),\n  font-weight: font-family.font-weight('semibold'),\n  line-height: 1.375,\n  letter-spacing: 0,\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$heading-compact-02: $productive-heading-02 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$productive-heading-03: (\n  font-size: scale.type-scale(5),\n  font-weight: font-family.font-weight('regular'),\n  line-height: 1.4,\n  letter-spacing: 0,\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$heading-03: $productive-heading-03 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$productive-heading-04: (\n  font-size: scale.type-scale(7),\n  font-weight: font-family.font-weight('regular'),\n  line-height: 1.28572,\n  letter-spacing: 0,\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$heading-04: $productive-heading-04 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$productive-heading-05: (\n  font-size: scale.type-scale(8),\n  font-weight: font-family.font-weight('regular'),\n  line-height: 1.25,\n  letter-spacing: 0,\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$heading-05: $productive-heading-05 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$productive-heading-06: (\n  font-size: scale.type-scale(10),\n  font-weight: font-family.font-weight('light'),\n  // Extra digit needed for precision in Chrome\n  line-height: 1.199,\n  letter-spacing: 0,\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$heading-06: $productive-heading-06 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$productive-heading-07: (\n  font-size: scale.type-scale(12),\n  font-weight: font-family.font-weight('light'),\n  line-height: 1.19,\n  letter-spacing: 0,\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$heading-07: $productive-heading-07 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$expressive-heading-01: $heading-01 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$expressive-heading-02: $heading-02 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$expressive-heading-03: (\n  font-size: scale.type-scale(5),\n  font-weight: font-family.font-weight('regular'),\n  line-height: 1.4,\n  letter-spacing: 0,\n  breakpoints: (\n    xlg: (\n      font-size: scale.type-scale(5),\n      line-height: 1.4,\n    ),\n    max: (\n      font-size: scale.type-scale(6),\n      line-height: 1.334,\n    ),\n  ),\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$fluid-heading-03: $expressive-heading-03 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$expressive-heading-04: (\n  font-size: scale.type-scale(7),\n  font-weight: font-family.font-weight('regular'),\n  line-height: 1.28572,\n  letter-spacing: 0,\n  breakpoints: (\n    xlg: (\n      font-size: scale.type-scale(8),\n      line-height: 1.25,\n      font-weight: font-family.font-weight('regular'),\n    ),\n    max: (\n      font-size: scale.type-scale(8),\n      font-weight: font-family.font-weight('regular'),\n    ),\n  ),\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$fluid-heading-04: $expressive-heading-04 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$expressive-heading-05: (\n  font-size: scale.type-scale(8),\n  font-weight: font-family.font-weight('regular'),\n  line-height: 1.25,\n  letter-spacing: 0,\n  breakpoints: (\n    md: (\n      font-size: scale.type-scale(9),\n      font-weight: font-family.font-weight('light'),\n      line-height: 1.22,\n    ),\n    lg: (\n      font-size: scale.type-scale(10),\n      line-height: 1.19,\n    ),\n    xlg: (\n      font-size: scale.type-scale(11),\n      line-height: 1.17,\n    ),\n    max: (\n      font-size: scale.type-scale(13),\n    ),\n  ),\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$fluid-heading-05: $expressive-heading-05 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$expressive-heading-06: (\n  font-size: scale.type-scale(8),\n  font-weight: font-family.font-weight('semibold'),\n  line-height: 1.25,\n  letter-spacing: 0,\n  breakpoints: (\n    md: (\n      font-size: scale.type-scale(9),\n      line-height: 1.22,\n    ),\n    lg: (\n      font-size: scale.type-scale(10),\n      line-height: 1.19,\n    ),\n    xlg: (\n      font-size: scale.type-scale(11),\n      line-height: 1.17,\n    ),\n    max: (\n      font-size: scale.type-scale(13),\n    ),\n  ),\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$fluid-heading-06: $expressive-heading-06 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$expressive-paragraph-01: (\n  font-size: scale.type-scale(6),\n  font-weight: font-family.font-weight('light'),\n  line-height: 1.334,\n  letter-spacing: 0,\n  breakpoints: (\n    lg: (\n      font-size: scale.type-scale(7),\n      line-height: 1.28572,\n    ),\n    max: (\n      font-size: scale.type-scale(8),\n      line-height: 1.25,\n    ),\n  ),\n);\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$fluid-paragraph-01: $expressive-paragraph-01 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$quotation-01: (\n  font-family: font-family.font-family('serif'),\n  font-size: scale.type-scale(5),\n  font-weight: font-family.font-weight('regular'),\n  line-height: 1.3,\n  letter-spacing: 0,\n  breakpoints: (\n    md: (\n      font-size: scale.type-scale(5),\n    ),\n    lg: (\n      font-size: scale.type-scale(6),\n      line-height: 1.334,\n    ),\n    xlg: (\n      font-size: scale.type-scale(7),\n      line-height: 1.28572,\n    ),\n    max: (\n      font-size: scale.type-scale(8),\n      line-height: 1.25,\n    ),\n  ),\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$fluid-quotation-01: $quotation-01 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$quotation-02: (\n  font-family: font-family.font-family('serif'),\n  font-size: scale.type-scale(8),\n  font-weight: font-family.font-weight('light'),\n  line-height: 1.25,\n  letter-spacing: 0,\n  breakpoints: (\n    md: (\n      font-size: scale.type-scale(9),\n      line-height: 1.22,\n    ),\n    lg: (\n      font-size: scale.type-scale(10),\n      line-height: 1.19,\n    ),\n    xlg: (\n      font-size: scale.type-scale(11),\n      line-height: 1.17,\n    ),\n    max: (\n      font-size: scale.type-scale(13),\n    ),\n  ),\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$fluid-quotation-02: $quotation-02 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$display-01: (\n  font-size: scale.type-scale(10),\n  font-weight: font-family.font-weight('light'),\n  line-height: 1.19,\n  letter-spacing: 0,\n  breakpoints: (\n    md: (\n      font-size: scale.type-scale(10),\n    ),\n    lg: (\n      font-size: scale.type-scale(12),\n    ),\n    xlg: (\n      font-size: scale.type-scale(13),\n      line-height: 1.17,\n    ),\n    max: (\n      font-size: scale.type-scale(15),\n      line-height: 1.13,\n    ),\n  ),\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$fluid-display-01: $display-01 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$display-02: (\n  font-size: scale.type-scale(10),\n  font-weight: font-family.font-weight('semibold'),\n  line-height: 1.19,\n  letter-spacing: 0,\n  breakpoints: (\n    md: (\n      font-size: scale.type-scale(10),\n    ),\n    lg: (\n      font-size: scale.type-scale(12),\n    ),\n    xlg: (\n      font-size: scale.type-scale(13),\n      line-height: 1.16,\n    ),\n    max: (\n      font-size: scale.type-scale(15),\n      line-height: 1.13,\n    ),\n  ),\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$fluid-display-02: $display-02 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$display-03: (\n  font-size: scale.type-scale(10),\n  font-weight: font-family.font-weight('light'),\n  line-height: 1.19,\n  letter-spacing: 0,\n  breakpoints: (\n    md: (\n      font-size: scale.type-scale(12),\n      line-height: 1.18,\n    ),\n    lg: (\n      font-size: scale.type-scale(13),\n      line-height: 1.16,\n      letter-spacing: -0.64px,\n    ),\n    xlg: (\n      font-size: scale.type-scale(15),\n      line-height: 1.13,\n      letter-spacing: -0.64px,\n    ),\n    max: (\n      font-size: scale.type-scale(16),\n      line-height: 1.11,\n      letter-spacing: -0.96px,\n    ),\n  ),\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$fluid-display-03: $display-03 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$display-04: (\n  font-size: scale.type-scale(10),\n  font-weight: font-family.font-weight('light'),\n  line-height: 1.19,\n  letter-spacing: 0,\n  breakpoints: (\n    md: (\n      font-size: scale.type-scale(14),\n      line-height: 1.15,\n    ),\n    lg: (\n      font-size: scale.type-scale(17),\n      line-height: 1.11,\n      letter-spacing: -0.64px,\n    ),\n    xlg: (\n      font-size: scale.type-scale(20),\n      line-height: 1.07,\n      letter-spacing: -0.64px,\n    ),\n    max: (\n      font-size: scale.type-scale(23),\n      line-height: 1.05,\n      letter-spacing: -0.96px,\n    ),\n  ),\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$fluid-display-04: $display-04 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$tokens: (\n  caption-01: $caption-01,\n  caption-02: $caption-02,\n  label-01: $label-01,\n  label-02: $label-02,\n  helper-text-01: $helper-text-01,\n  helper-text-02: $helper-text-02,\n  body-short-01: $body-short-01,\n  body-short-02: $body-short-02,\n  body-long-01: $body-long-01,\n  body-long-02: $body-long-02,\n  code-01: $code-01,\n  code-02: $code-02,\n  heading-01: $heading-01,\n  heading-02: $heading-02,\n  productive-heading-01: $productive-heading-01,\n  productive-heading-02: $productive-heading-02,\n  productive-heading-03: $productive-heading-03,\n  productive-heading-04: $productive-heading-04,\n  productive-heading-05: $productive-heading-05,\n  productive-heading-06: $productive-heading-06,\n  productive-heading-07: $productive-heading-07,\n  expressive-paragraph-01: $expressive-paragraph-01,\n  expressive-heading-01: $expressive-heading-01,\n  expressive-heading-02: $expressive-heading-02,\n  expressive-heading-03: $expressive-heading-03,\n  expressive-heading-04: $expressive-heading-04,\n  expressive-heading-05: $expressive-heading-05,\n  expressive-heading-06: $expressive-heading-06,\n  quotation-01: $quotation-01,\n  quotation-02: $quotation-02,\n  display-01: $display-01,\n  display-02: $display-02,\n  display-03: $display-03,\n  display-04: $display-04,\n  // V11 Tokens\n  legal-01: $legal-01,\n  legal-02: $legal-02,\n  body-compact-01: $body-compact-01,\n  body-compact-02: $body-compact-02,\n  heading-compact-01: $heading-compact-01,\n  heading-compact-02: $heading-compact-02,\n  body-01: $body-01,\n  body-02: $body-02,\n  heading-03: $heading-03,\n  heading-04: $heading-04,\n  heading-05: $heading-05,\n  heading-06: $heading-06,\n  heading-07: $heading-07,\n  fluid-heading-03: $fluid-heading-03,\n  fluid-heading-04: $fluid-heading-04,\n  fluid-heading-05: $fluid-heading-05,\n  fluid-heading-06: $fluid-heading-06,\n  fluid-paragraph-01: $fluid-paragraph-01,\n  fluid-quotation-01: $fluid-quotation-01,\n  fluid-quotation-02: $fluid-quotation-02,\n  fluid-display-01: $fluid-display-01,\n  fluid-display-02: $fluid-display-02,\n  fluid-display-03: $fluid-display-03,\n  fluid-display-04: $fluid-display-04,\n) !default;\n\n/// @param {Map} $map\n/// @access public\n/// @group @carbon/type\n@mixin properties($map) {\n  @each $name, $value in $map {\n    #{$name}: $value;\n  }\n}\n\n/// @param {Number} $value - Number with units\n/// @return {Number} Without units\n/// @access public\n/// @group @carbon/type\n@function strip-unit($value) {\n  @return math.div($value, $value * 0 + 1);\n}\n\n/// This helper includes fluid type styles for the given token value. Fluid type\n/// means that the `font-size` is computed using `calc()` in order to be\n/// determined by the screen size instead of a breakpoint. As a result, fluid\n/// styles should be used with caution in fixed width contexts.\n///\n/// In addition, we make use of %-based line-heights so that the line-height of\n/// each type style is computed correctly due to the dynamic nature of the\n/// `font-size`.\n///\n/// Most of the logic for this work comes from CSS Tricks:\n/// https://css-tricks.com/snippets/css/fluid-typography/\n///\n/// @param {Map} $type-styles - The value of a given type token\n/// @param {Map} $breakpoints [$grid-breakpoints] - Custom breakpoints to use\n/// @access public\n/// @group @carbon/type\n@mixin fluid-type($type-styles, $breakpoints: gridconfig.$grid-breakpoints) {\n  // Include the initial styles for the given token by default without any\n  // media query guard. This includes `font-size` as a fallback in the case\n  // that a browser does not support `calc()`\n  @include properties(map.remove($type-styles, breakpoints));\n  // We also need to include the `sm` styles by default since they don't\n  // appear in the fluid styles for tokens\n  @include fluid-type-size($type-styles, sm, $breakpoints);\n\n  // Finally, we need to go through all the breakpoints defined in the type\n  // token and apply the properties and fluid type size for that given\n  // breakpoint\n  @each $name, $values in map.get($type-styles, breakpoints) {\n    @include grid.breakpoint($name) {\n      @include properties($values);\n      @include fluid-type-size($type-styles, $name, $breakpoints);\n    }\n  }\n}\n\n/// Computes the fluid `font-size` for a given type style and breakpoint\n/// @param {Map} $type-styles - The styles for a given token\n/// @param {String} $name - The name of the breakpoint to which we apply the fluid\n/// @param {Map} $breakpoints [$grid-breakpoints] - The breakpoints for the grid system\n/// @access public\n/// @group @carbon/type\n@mixin fluid-type-size(\n  $type-styles,\n  $name,\n  $breakpoints: gridconfig.$grid-breakpoints\n) {\n  // Get the information about the breakpoint we're currently working in. Useful\n  // for getting initial width information\n  $breakpoint: map.get($breakpoints, $name);\n\n  // Our fluid styles are captured under the 'breakpoints' property in our type\n  // styles map. These define what values to treat as `max-` variables below\n  $fluid-sizes: map.get($type-styles, breakpoints);\n  $fluid-breakpoint: ();\n  // Special case for `sm` because the styles for small are on the type style\n  // directly\n  @if $name == sm {\n    $fluid-breakpoint: map.remove($type-styles, breakpoints);\n  } @else {\n    $fluid-breakpoint: map.get($fluid-sizes, $name);\n  }\n\n  // Initialize our font-sizes to the default size for the type style\n  $max-font-size: map.get($type-styles, font-size);\n  $min-font-size: map.get($type-styles, font-size);\n  @if map.has-key($fluid-breakpoint, font-size) {\n    $min-font-size: map.get($fluid-breakpoint, font-size);\n  }\n\n  // Initialize our min and max width to the width of the current breakpoint\n  $max-vw: map.get($breakpoint, width);\n  $min-vw: map.get($breakpoint, width);\n\n  // We can use `breakpoint-next` to see if there is another breakpoint we can\n  // use to update `max-font-size` and `max-vw` with larger values\n  $next-breakpoint-available: grid.breakpoint-next($name, $breakpoints);\n  $next-fluid-breakpoint-name: null;\n\n  // We need to figure out what the next available fluid breakpoint is for our\n  // given $type-styles. In this loop we try and iterate through breakpoints\n  // until we either manually set $next-breakpoint-available to null or\n  // `breakpoint-next` returns null.\n  @while $next-breakpoint-available {\n    @if map.has-key($fluid-sizes, $next-breakpoint-available) {\n      $next-fluid-breakpoint-name: $next-breakpoint-available;\n      $next-breakpoint-available: null;\n    } @else {\n      $next-breakpoint-available: grid.breakpoint-next(\n        $next-breakpoint-available,\n        $breakpoints\n      );\n    }\n  }\n\n  // If we have found the next available fluid breakpoint name, then we know\n  // that we have values that we can use to set max-font-size and max-vw as both\n  // values derive from the next breakpoint\n  @if $next-fluid-breakpoint-name {\n    $next-fluid-breakpoint: map.get($breakpoints, $next-fluid-breakpoint-name);\n    $max-font-size: map.get(\n      map.get($fluid-sizes, $next-fluid-breakpoint-name),\n      font-size\n    );\n    $max-vw: map.get($next-fluid-breakpoint, width);\n\n    // prettier-ignore\n    font-size: calc(#{$min-font-size} +\n      #{strip-unit($max-font-size - $min-font-size)} *\n      ((100vw - #{$min-vw}) / #{strip-unit($max-vw - $min-vw)})\n    );\n  } @else {\n    // Otherwise, just default to setting the font size found from the type\n    // style or the given fluid breakpoint in the type style\n    font-size: $min-font-size;\n  }\n}\n\n// TODO move following variable and `custom-property` mixin into shared file for\n// both `@carbon/type` and `@carbon/themes`\n\n/// @access private\n/// @group @carbon/type\n@mixin custom-properties($name, $value) {\n  @each $property, $value in $value {\n    #{$property}: var(\n      --#{$custom-property-prefix}-#{$name}-#{$property},\n      #{$value}\n    );\n  }\n}\n\n/// Helper mixin to include the styles for a given token in any selector in your\n/// project. Also includes an optional fluid option that will enable fluid\n/// styles for the token if they are defined. Fluid styles will cause the\n/// token's font-size to be computed based on the viewport size. As a result, use\n/// with caution in fixed contexts.\n/// @param {String} $name - The name of the token to get the styles for\n/// @param {Boolean} $fluid [false] - Specify whether to include fluid styles for the\n/// @param {Map} $breakpoints [$grid-breakpoints] - Provide a custom breakpoint map to use\n/// @access public\n/// @group @carbon/type\n@mixin type-style(\n  $name,\n  $fluid: false,\n  $breakpoints: gridconfig.$grid-breakpoints\n) {\n  @if not map.has-key($tokens, $name) {\n    @error 'Unable to find a token with the name: `#{$name}`';\n  }\n\n  $token: map.get($tokens, $name);\n\n  // If $fluid is set to true and the token has breakpoints defined for fluid\n  // styles, delegate to the fluid-type helper for the given token\n  @if $fluid == true and map.has-key($token, 'breakpoints') {\n    @include fluid-type($token, $breakpoints);\n  } @else {\n    @include custom-properties($name, $token);\n  }\n}\n"],"sourceRoot":""}]);
// Exports
___CSS_LOADER_EXPORT___.locals = {
	"table": "-esm-patient-vitals__paginated-vitals__table___AxhjH",
	"criticallyLow": "-esm-patient-vitals__paginated-vitals__criticallyLow___e1lPl",
	"criticallyHigh": "-esm-patient-vitals__paginated-vitals__criticallyHigh___aV4Dd",
	"low": "-esm-patient-vitals__paginated-vitals__low___sD3mz",
	"high": "-esm-patient-vitals__paginated-vitals__high___fZjma",
	"off-scale-low": "-esm-patient-vitals__paginated-vitals__off-scale-low___4AL-6",
	"off-scale-high": "-esm-patient-vitals__paginated-vitals__off-scale-high___eOuDB",
	"offScaleHigh": "-esm-patient-vitals__paginated-vitals__offScaleHigh___z2WH8",
	"offScaleLow": "-esm-patient-vitals__paginated-vitals__offScaleLow___WpL60",
	"cds--table-cell": "-esm-patient-vitals__paginated-vitals__cds--table-cell___PQ0vM"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "../../node_modules/openmrs/node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[2].use[1]!../../node_modules/openmrs/node_modules/sass-loader/dist/cjs.js??ruleSet[1].rules[2].use[2]!./src/vitals/print/print.scss":
/*!****************************************************************************************************************************************************************************************************************************!*\
  !*** ../../node_modules/openmrs/node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[2].use[1]!../../node_modules/openmrs/node_modules/sass-loader/dist/cjs.js??ruleSet[1].rules[2].use[2]!./src/vitals/print/print.scss ***!
  \****************************************************************************************************************************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_openmrs_node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../../../node_modules/openmrs/node_modules/css-loader/dist/runtime/cssWithMappingToString.js */ "../../node_modules/openmrs/node_modules/css-loader/dist/runtime/cssWithMappingToString.js");
/* harmony import */ var _node_modules_openmrs_node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_openmrs_node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_openmrs_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../../../node_modules/openmrs/node_modules/css-loader/dist/runtime/api.js */ "../../node_modules/openmrs/node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_openmrs_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_openmrs_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_openmrs_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_openmrs_node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0___default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, "@media screen {\n  .-esm-patient-vitals__print__printPage___7BQnq {\n    background-color: #ffffff;\n    display: none;\n  }\n}\n@media print {\n  @page {\n    size: auto;\n    margin: 2.5rem;\n  }\n  .-esm-patient-vitals__print__header___7GY7x {\n    display: flex;\n    align-items: center;\n    justify-content: space-between;\n    background-color: #ffffff;\n  }\n  .-esm-patient-vitals__print__patientDetails___7jMXF {\n    font-size: var(--cds-body-compact-02-font-size, 1rem);\n    font-weight: var(--cds-body-compact-02-font-weight, 400);\n    line-height: var(--cds-body-compact-02-line-height, 1.375);\n    letter-spacing: var(--cds-body-compact-02-letter-spacing, 0);\n    margin: 0 0.5rem;\n  }\n  .-esm-patient-vitals__print__patientInfo___LIJzR {\n    color: #393939;\n    font-size: var(--cds-body-compact-02-font-size, 1rem);\n    font-weight: var(--cds-body-compact-02-font-weight, 400);\n    line-height: var(--cds-body-compact-02-line-height, 1.375);\n    letter-spacing: var(--cds-body-compact-02-letter-spacing, 0);\n  }\n  .-esm-patient-vitals__print__name___gfvQ9 {\n    font-size: var(--cds-heading-compact-02-font-size, 1rem);\n    font-weight: var(--cds-heading-compact-02-font-weight, 600);\n    line-height: var(--cds-heading-compact-02-line-height, 1.375);\n    letter-spacing: var(--cds-heading-compact-02-letter-spacing, 0);\n    margin-right: 0.5rem;\n  }\n  .-esm-patient-vitals__print__footer___dK9c- {\n    font-size: 0.75rem;\n    display: flex;\n  }\n  .-esm-patient-vitals__print__date___56Z1T {\n    margin-left: 1.5rem;\n  }\n  .-esm-patient-vitals__print__gender___V7a6G {\n    text-transform: capitalize;\n  }\n  .-esm-patient-vitals__print__printedBy___y3CK\\+ {\n    font-size: var(--cds-body-compact-01-font-size, 0.875rem);\n    font-weight: var(--cds-body-compact-01-font-weight, 400);\n    line-height: var(--cds-body-compact-01-line-height, 1.28572);\n    letter-spacing: var(--cds-body-compact-01-letter-spacing, 0.16px);\n    margin: 0 0.25rem;\n  }\n  .-esm-patient-vitals__print__subheader___iXVg7 {\n    font-size: var(--cds-heading-03-font-size, 1.25rem);\n    font-weight: var(--cds-heading-03-font-weight, 400);\n    line-height: var(--cds-heading-03-line-height, 1.4);\n    letter-spacing: var(--cds-heading-03-letter-spacing, 0);\n    color: #525252;\n    padding: 0.5rem;\n    text-align: center;\n  }\n}", "",{"version":3,"sources":["webpack://./src/vitals/print/print.scss","webpack://./../../node_modules/@carbon/colors/index.scss","webpack://./../../node_modules/@carbon/layout/scss/generated/_spacing.scss","webpack://./../../node_modules/@carbon/type/scss/_styles.scss"],"names":[],"mappings":"AAIA;EACE;IACE,yBCGI;IDFJ,aAAA;EAHF;AACF;AAMA;EACE;IACE,UAAA;IACA,cEgCS;EFpCX;EAOA;IACE,aAAA;IACA,mBAAA;IACA,8BAAA;IACA,yBCZI;EDON;EAQA;IG00BE,qDAAA;IAAA,wDAAA;IAAA,0DAAA;IAAA,4DAAA;IHx0BA,gBAAA;EAHF;EAMA;IACE,cCmBM;IEizBN,qDAAA;IAAA,wDAAA;IAAA,0DAAA;IAAA,4DAAA;EHp0BF;EAIA;IGg0BE,wDAAA;IAAA,2DAAA;IAAA,6DAAA;IAAA,+DAAA;IH9zBA,oBEfS;EFgBX;EAEA;IACE,kBEdS;IFeT,aAAA;EAAF;EAGA;IACE,mBETS;EFQX;EAIA;IACE,0BAAA;EAFF;EAKA;IG8yBE,yDAAA;IAAA,wDAAA;IAAA,4DAAA;IAAA,iEAAA;IH5yBA,iBAAA;EAAF;EAGA;IGyyBE,mDAAA;IAAA,mDAAA;IAAA,mDAAA;IAAA,uDAAA;IHvyBA,cCXM;IDYN,eEvCS;IFwCT,kBAAA;EAEF;AACF","sourcesContent":["@use '@carbon/colors';\r\n@use '@carbon/layout';\r\n@use '@carbon/type';\r\n\r\n@media screen {\r\n  .printPage {\r\n    background-color: colors.$white;\r\n    display: none;\r\n  }\r\n}\r\n\r\n@media print {\r\n  @page {\r\n    size: auto;\r\n    margin: layout.$spacing-08;\r\n  }\r\n\r\n  .header {\r\n    display: flex;\r\n    align-items: center;\r\n    justify-content: space-between;\r\n    background-color: colors.$white;\r\n  }\r\n\r\n  .patientDetails {\r\n    @include type.type-style('body-compact-02');\r\n    margin: 0 layout.$spacing-03;\r\n  }\r\n\r\n  .patientInfo {\r\n    color: colors.$gray-80;\r\n    @include type.type-style('body-compact-02');\r\n  }\r\n\r\n  .name {\r\n    @include type.type-style('heading-compact-02');\r\n    margin-right: layout.$spacing-03;\r\n  }\r\n\r\n  .footer {\r\n    font-size: layout.$spacing-04;\r\n    display: flex;\r\n  }\r\n\r\n  .date {\r\n    margin-left: layout.$spacing-06;\r\n  }\r\n\r\n  .gender {\r\n    text-transform: capitalize;\r\n  }\r\n\r\n  .printedBy {\r\n    @include type.type-style('body-compact-01');\r\n    margin: 0 layout.$spacing-02;\r\n  }\r\n\r\n  .subheader {\r\n    @include type.type-style('heading-03');\r\n    color: colors.$gray-70;\r\n    padding: layout.$spacing-03;\r\n    text-align: center;\r\n  }\r\n}\r\n","// Code generated by @carbon/colors. DO NOT EDIT.\n//\n// Copyright IBM Corp. 2018, 2023\n//\n// This source code is licensed under the Apache-2.0 license found in the\n// LICENSE file in the root directory of this source tree.\n//\n\n$black: #000000 !default;\n$white: #ffffff !default;\n\n$black-100: #000000 !default;\n$blue-10: #edf5ff !default;\n$blue-20: #d0e2ff !default;\n$blue-30: #a6c8ff !default;\n$blue-40: #78a9ff !default;\n$blue-50: #4589ff !default;\n$blue-60: #0f62fe !default;\n$blue-70: #0043ce !default;\n$blue-80: #002d9c !default;\n$blue-90: #001d6c !default;\n$blue-100: #001141 !default;\n$cool-gray-10: #f2f4f8 !default;\n$cool-gray-20: #dde1e6 !default;\n$cool-gray-30: #c1c7cd !default;\n$cool-gray-40: #a2a9b0 !default;\n$cool-gray-50: #878d96 !default;\n$cool-gray-60: #697077 !default;\n$cool-gray-70: #4d5358 !default;\n$cool-gray-80: #343a3f !default;\n$cool-gray-90: #21272a !default;\n$cool-gray-100: #121619 !default;\n$cyan-10: #e5f6ff !default;\n$cyan-20: #bae6ff !default;\n$cyan-30: #82cfff !default;\n$cyan-40: #33b1ff !default;\n$cyan-50: #1192e8 !default;\n$cyan-60: #0072c3 !default;\n$cyan-70: #00539a !default;\n$cyan-80: #003a6d !default;\n$cyan-90: #012749 !default;\n$cyan-100: #061727 !default;\n$gray-10: #f4f4f4 !default;\n$gray-20: #e0e0e0 !default;\n$gray-30: #c6c6c6 !default;\n$gray-40: #a8a8a8 !default;\n$gray-50: #8d8d8d !default;\n$gray-60: #6f6f6f !default;\n$gray-70: #525252 !default;\n$gray-80: #393939 !default;\n$gray-90: #262626 !default;\n$gray-100: #161616 !default;\n$green-10: #defbe6 !default;\n$green-20: #a7f0ba !default;\n$green-30: #6fdc8c !default;\n$green-40: #42be65 !default;\n$green-50: #24a148 !default;\n$green-60: #198038 !default;\n$green-70: #0e6027 !default;\n$green-80: #044317 !default;\n$green-90: #022d0d !default;\n$green-100: #071908 !default;\n$magenta-10: #fff0f7 !default;\n$magenta-20: #ffd6e8 !default;\n$magenta-30: #ffafd2 !default;\n$magenta-40: #ff7eb6 !default;\n$magenta-50: #ee5396 !default;\n$magenta-60: #d02670 !default;\n$magenta-70: #9f1853 !default;\n$magenta-80: #740937 !default;\n$magenta-90: #510224 !default;\n$magenta-100: #2a0a18 !default;\n$orange-10: #fff2e8 !default;\n$orange-20: #ffd9be !default;\n$orange-30: #ffb784 !default;\n$orange-40: #ff832b !default;\n$orange-50: #eb6200 !default;\n$orange-60: #ba4e00 !default;\n$orange-70: #8a3800 !default;\n$orange-80: #5e2900 !default;\n$orange-90: #3e1a00 !default;\n$orange-100: #231000 !default;\n$purple-10: #f6f2ff !default;\n$purple-20: #e8daff !default;\n$purple-30: #d4bbff !default;\n$purple-40: #be95ff !default;\n$purple-50: #a56eff !default;\n$purple-60: #8a3ffc !default;\n$purple-70: #6929c4 !default;\n$purple-80: #491d8b !default;\n$purple-90: #31135e !default;\n$purple-100: #1c0f30 !default;\n$red-10: #fff1f1 !default;\n$red-20: #ffd7d9 !default;\n$red-30: #ffb3b8 !default;\n$red-40: #ff8389 !default;\n$red-50: #fa4d56 !default;\n$red-60: #da1e28 !default;\n$red-70: #a2191f !default;\n$red-80: #750e13 !default;\n$red-90: #520408 !default;\n$red-100: #2d0709 !default;\n$teal-10: #d9fbfb !default;\n$teal-20: #9ef0f0 !default;\n$teal-30: #3ddbd9 !default;\n$teal-40: #08bdba !default;\n$teal-50: #009d9a !default;\n$teal-60: #007d79 !default;\n$teal-70: #005d5d !default;\n$teal-80: #004144 !default;\n$teal-90: #022b30 !default;\n$teal-100: #081a1c !default;\n$warm-gray-10: #f7f3f2 !default;\n$warm-gray-20: #e5e0df !default;\n$warm-gray-30: #cac5c4 !default;\n$warm-gray-40: #ada8a8 !default;\n$warm-gray-50: #8f8b8b !default;\n$warm-gray-60: #726e6e !default;\n$warm-gray-70: #565151 !default;\n$warm-gray-80: #3c3838 !default;\n$warm-gray-90: #272525 !default;\n$warm-gray-100: #171414 !default;\n$white-0: #ffffff !default;\n$yellow-10: #fcf4d6 !default;\n$yellow-20: #fddc69 !default;\n$yellow-30: #f1c21b !default;\n$yellow-40: #d2a106 !default;\n$yellow-50: #b28600 !default;\n$yellow-60: #8e6a00 !default;\n$yellow-70: #684e00 !default;\n$yellow-80: #483700 !default;\n$yellow-90: #302400 !default;\n$yellow-100: #1c1500 !default;\n\n$white-hover: #e8e8e8 !default;\n$black-hover: #212121 !default;\n$blue-10-hover: #dbebff !default;\n$blue-20-hover: #b8d3ff !default;\n$blue-30-hover: #8ab6ff !default;\n$blue-40-hover: #5c97ff !default;\n$blue-50-hover: #1f70ff !default;\n$blue-60-hover: #0050e6 !default;\n$blue-70-hover: #0053ff !default;\n$blue-80-hover: #0039c7 !default;\n$blue-90-hover: #00258a !default;\n$blue-100-hover: #001f75 !default;\n$cool-gray-10-hover: #e4e9f1 !default;\n$cool-gray-20-hover: #cdd3da !default;\n$cool-gray-30-hover: #adb5bd !default;\n$cool-gray-40-hover: #9199a1 !default;\n$cool-gray-50-hover: #757b85 !default;\n$cool-gray-60-hover: #585e64 !default;\n$cool-gray-70-hover: #5d646a !default;\n$cool-gray-80-hover: #434a51 !default;\n$cool-gray-90-hover: #2b3236 !default;\n$cool-gray-100-hover: #222a2f !default;\n$cyan-10-hover: #cceeff !default;\n$cyan-20-hover: #99daff !default;\n$cyan-30-hover: #57beff !default;\n$cyan-40-hover: #059fff !default;\n$cyan-50-hover: #0f7ec8 !default;\n$cyan-60-hover: #005fa3 !default;\n$cyan-70-hover: #0066bd !default;\n$cyan-80-hover: #00498a !default;\n$cyan-90-hover: #013360 !default;\n$cyan-100-hover: #0b2947 !default;\n$gray-10-hover: #e8e8e8 !default;\n$gray-20-hover: #d1d1d1 !default;\n$gray-30-hover: #b5b5b5 !default;\n$gray-40-hover: #999999 !default;\n$gray-50-hover: #7a7a7a !default;\n$gray-60-hover: #5e5e5e !default;\n$gray-70-hover: #636363 !default;\n$gray-80-hover: #474747 !default;\n$gray-90-hover: #333333 !default;\n$gray-100-hover: #292929 !default;\n$green-10-hover: #b6f6c8 !default;\n$green-20-hover: #74e792 !default;\n$green-30-hover: #36ce5e !default;\n$green-40-hover: #3bab5a !default;\n$green-50-hover: #208e3f !default;\n$green-60-hover: #166f31 !default;\n$green-70-hover: #11742f !default;\n$green-80-hover: #05521c !default;\n$green-90-hover: #033b11 !default;\n$green-100-hover: #0d300f !default;\n$magenta-10-hover: #ffe0ef !default;\n$magenta-20-hover: #ffbdda !default;\n$magenta-30-hover: #ff94c3 !default;\n$magenta-40-hover: #ff57a0 !default;\n$magenta-50-hover: #e3176f !default;\n$magenta-60-hover: #b0215f !default;\n$magenta-70-hover: #bf1d63 !default;\n$magenta-80-hover: #8e0b43 !default;\n$magenta-90-hover: #68032e !default;\n$magenta-100-hover: #53142f !default;\n$orange-10-hover: #ffe2cc !default;\n$orange-20-hover: #ffc69e !default;\n$orange-30-hover: #ff9d57 !default;\n$orange-40-hover: #fa6800 !default;\n$orange-50-hover: #cc5500 !default;\n$orange-60-hover: #9e4200 !default;\n$orange-70-hover: #a84400 !default;\n$orange-80-hover: #753300 !default;\n$orange-90-hover: #522200 !default;\n$orange-100-hover: #421e00 !default;\n$purple-10-hover: #ede5ff !default;\n$purple-20-hover: #dcc7ff !default;\n$purple-30-hover: #c5a3ff !default;\n$purple-40-hover: #ae7aff !default;\n$purple-50-hover: #9352ff !default;\n$purple-60-hover: #7822fb !default;\n$purple-70-hover: #7c3dd6 !default;\n$purple-80-hover: #5b24ad !default;\n$purple-90-hover: #40197b !default;\n$purple-100-hover: #341c59 !default;\n$red-10-hover: #ffe0e0 !default;\n$red-20-hover: #ffc2c5 !default;\n$red-30-hover: #ff99a0 !default;\n$red-40-hover: #ff6168 !default;\n$red-50-hover: #ee0713 !default;\n$red-60-hover: #b81922 !default;\n$red-70-hover: #c21e25 !default;\n$red-80-hover: #921118 !default;\n$red-90-hover: #66050a !default;\n$red-100-hover: #540d11 !default;\n$teal-10-hover: #acf6f6 !default;\n$teal-20-hover: #57e5e5 !default;\n$teal-30-hover: #25cac8 !default;\n$teal-40-hover: #07aba9 !default;\n$teal-50-hover: #008a87 !default;\n$teal-60-hover: #006b68 !default;\n$teal-70-hover: #007070 !default;\n$teal-80-hover: #005357 !default;\n$teal-90-hover: #033940 !default;\n$teal-100-hover: #0f3034 !default;\n$warm-gray-10-hover: #f0e8e6 !default;\n$warm-gray-20-hover: #d8d0cf !default;\n$warm-gray-30-hover: #b9b3b1 !default;\n$warm-gray-40-hover: #9c9696 !default;\n$warm-gray-50-hover: #7f7b7b !default;\n$warm-gray-60-hover: #605d5d !default;\n$warm-gray-70-hover: #696363 !default;\n$warm-gray-80-hover: #4c4848 !default;\n$warm-gray-90-hover: #343232 !default;\n$warm-gray-100-hover: #2c2626 !default;\n$yellow-10-hover: #f8e6a0 !default;\n$yellow-20-hover: #fccd27 !default;\n$yellow-30-hover: #ddb00e !default;\n$yellow-40-hover: #bc9005 !default;\n$yellow-50-hover: #9e7700 !default;\n$yellow-60-hover: #755800 !default;\n$yellow-70-hover: #806000 !default;\n$yellow-80-hover: #5c4600 !default;\n$yellow-90-hover: #3d2e00 !default;\n$yellow-100-hover: #332600 !default;\n\n/// Colors from the IBM Design Language\n/// @access public\n/// @group @carbon/colors\n$colors: (\n  black: (\n    100: #000000,\n  ),\n  blue: (\n    10: #edf5ff,\n    20: #d0e2ff,\n    30: #a6c8ff,\n    40: #78a9ff,\n    50: #4589ff,\n    60: #0f62fe,\n    70: #0043ce,\n    80: #002d9c,\n    90: #001d6c,\n    100: #001141,\n  ),\n  cool-gray: (\n    10: #f2f4f8,\n    20: #dde1e6,\n    30: #c1c7cd,\n    40: #a2a9b0,\n    50: #878d96,\n    60: #697077,\n    70: #4d5358,\n    80: #343a3f,\n    90: #21272a,\n    100: #121619,\n  ),\n  cyan: (\n    10: #e5f6ff,\n    20: #bae6ff,\n    30: #82cfff,\n    40: #33b1ff,\n    50: #1192e8,\n    60: #0072c3,\n    70: #00539a,\n    80: #003a6d,\n    90: #012749,\n    100: #061727,\n  ),\n  gray: (\n    10: #f4f4f4,\n    20: #e0e0e0,\n    30: #c6c6c6,\n    40: #a8a8a8,\n    50: #8d8d8d,\n    60: #6f6f6f,\n    70: #525252,\n    80: #393939,\n    90: #262626,\n    100: #161616,\n  ),\n  green: (\n    10: #defbe6,\n    20: #a7f0ba,\n    30: #6fdc8c,\n    40: #42be65,\n    50: #24a148,\n    60: #198038,\n    70: #0e6027,\n    80: #044317,\n    90: #022d0d,\n    100: #071908,\n  ),\n  magenta: (\n    10: #fff0f7,\n    20: #ffd6e8,\n    30: #ffafd2,\n    40: #ff7eb6,\n    50: #ee5396,\n    60: #d02670,\n    70: #9f1853,\n    80: #740937,\n    90: #510224,\n    100: #2a0a18,\n  ),\n  orange: (\n    10: #fff2e8,\n    20: #ffd9be,\n    30: #ffb784,\n    40: #ff832b,\n    50: #eb6200,\n    60: #ba4e00,\n    70: #8a3800,\n    80: #5e2900,\n    90: #3e1a00,\n    100: #231000,\n  ),\n  purple: (\n    10: #f6f2ff,\n    20: #e8daff,\n    30: #d4bbff,\n    40: #be95ff,\n    50: #a56eff,\n    60: #8a3ffc,\n    70: #6929c4,\n    80: #491d8b,\n    90: #31135e,\n    100: #1c0f30,\n  ),\n  red: (\n    10: #fff1f1,\n    20: #ffd7d9,\n    30: #ffb3b8,\n    40: #ff8389,\n    50: #fa4d56,\n    60: #da1e28,\n    70: #a2191f,\n    80: #750e13,\n    90: #520408,\n    100: #2d0709,\n  ),\n  teal: (\n    10: #d9fbfb,\n    20: #9ef0f0,\n    30: #3ddbd9,\n    40: #08bdba,\n    50: #009d9a,\n    60: #007d79,\n    70: #005d5d,\n    80: #004144,\n    90: #022b30,\n    100: #081a1c,\n  ),\n  warm-gray: (\n    10: #f7f3f2,\n    20: #e5e0df,\n    30: #cac5c4,\n    40: #ada8a8,\n    50: #8f8b8b,\n    60: #726e6e,\n    70: #565151,\n    80: #3c3838,\n    90: #272525,\n    100: #171414,\n  ),\n  white: (\n    0: #ffffff,\n  ),\n  yellow: (\n    10: #fcf4d6,\n    20: #fddc69,\n    30: #f1c21b,\n    40: #d2a106,\n    50: #b28600,\n    60: #8e6a00,\n    70: #684e00,\n    80: #483700,\n    90: #302400,\n    100: #1c1500,\n  ),\n) !default;\n","// Code generated by @carbon/layout. DO NOT EDIT.\n//\n// Copyright IBM Corp. 2018, 2023\n//\n// This source code is licensed under the Apache-2.0 license found in the\n// LICENSE file in the root directory of this source tree.\n//\n\n/// @type Number\n/// @access public\n/// @group @carbon/layout\n$spacing-01: 0.125rem !default;\n\n/// @type Number\n/// @access public\n/// @group @carbon/layout\n$spacing-02: 0.25rem !default;\n\n/// @type Number\n/// @access public\n/// @group @carbon/layout\n$spacing-03: 0.5rem !default;\n\n/// @type Number\n/// @access public\n/// @group @carbon/layout\n$spacing-04: 0.75rem !default;\n\n/// @type Number\n/// @access public\n/// @group @carbon/layout\n$spacing-05: 1rem !default;\n\n/// @type Number\n/// @access public\n/// @group @carbon/layout\n$spacing-06: 1.5rem !default;\n\n/// @type Number\n/// @access public\n/// @group @carbon/layout\n$spacing-07: 2rem !default;\n\n/// @type Number\n/// @access public\n/// @group @carbon/layout\n$spacing-08: 2.5rem !default;\n\n/// @type Number\n/// @access public\n/// @group @carbon/layout\n$spacing-09: 3rem !default;\n\n/// @type Number\n/// @access public\n/// @group @carbon/layout\n$spacing-10: 4rem !default;\n\n/// @type Number\n/// @access public\n/// @group @carbon/layout\n$spacing-11: 5rem !default;\n\n/// @type Number\n/// @access public\n/// @group @carbon/layout\n$spacing-12: 6rem !default;\n\n/// @type Number\n/// @access public\n/// @group @carbon/layout\n$spacing-13: 10rem !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/layout\n$spacing: (\n  spacing-01: $spacing-01,\n  spacing-02: $spacing-02,\n  spacing-03: $spacing-03,\n  spacing-04: $spacing-04,\n  spacing-05: $spacing-05,\n  spacing-06: $spacing-06,\n  spacing-07: $spacing-07,\n  spacing-08: $spacing-08,\n  spacing-09: $spacing-09,\n  spacing-10: $spacing-10,\n  spacing-11: $spacing-11,\n  spacing-12: $spacing-12,\n  spacing-13: $spacing-13,\n);\n","//\n// Copyright IBM Corp. 2018, 2023\n//\n// This source code is licensed under the Apache-2.0 license found in the\n// LICENSE file in the root directory of this source tree.\n//\n\n// stylelint-disable number-max-precision\n\n@use 'sass:map';\n@use 'sass:math';\n@use '@carbon/grid/scss/config' as gridconfig;\n@use '@carbon/grid/scss/breakpoint' as grid;\n@use 'prefix' as *;\n@use 'font-family';\n@use 'scale';\n\n/// @type Map\n/// @access public\n/// @deprecated\n/// @group @carbon/type\n$caption-01: (\n  font-size: scale.type-scale(1),\n  font-weight: font-family.font-weight('regular'),\n  line-height: 1.33333,\n  letter-spacing: 0.32px,\n) !default;\n\n/// @type Map\n/// @access public\n/// @deprecated\n/// @group @carbon/type\n$caption-02: (\n  font-size: scale.type-scale(2),\n  font-weight: font-family.font-weight('regular'),\n  line-height: 1.28572,\n  letter-spacing: 0.32px,\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$label-01: (\n  font-size: scale.type-scale(1),\n  font-weight: font-family.font-weight('regular'),\n  line-height: 1.33333,\n  letter-spacing: 0.32px,\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$label-02: (\n  font-size: scale.type-scale(2),\n  font-weight: font-family.font-weight('regular'),\n  line-height: 1.28572,\n  letter-spacing: 0.16px,\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$legal-01: (\n  font-size: scale.type-scale(1),\n  font-weight: font-family.font-weight('regular'),\n  line-height: 1.33333,\n  letter-spacing: 0.32px,\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$legal-02: (\n  font-size: scale.type-scale(2),\n  font-weight: font-family.font-weight('regular'),\n  line-height: 1.28572,\n  letter-spacing: 0.16px,\n) !default;\n\n/// @type Map\n/// @access public\n/// @deprecated\n/// @group @carbon/type\n$helper-text-01: (\n  font-size: scale.type-scale(1),\n  line-height: 1.33333,\n  letter-spacing: 0.32px,\n) !default;\n\n/// @type Map\n/// @access public\n/// @deprecated\n/// @group @carbon/type\n$helper-text-02: (\n  font-size: scale.type-scale(2),\n  font-weight: font-family.font-weight('regular'),\n  line-height: 1.28572,\n  letter-spacing: 0.16px,\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$body-short-01: (\n  font-size: scale.type-scale(2),\n  font-weight: font-family.font-weight('regular'),\n  line-height: 1.28572,\n  letter-spacing: 0.16px,\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$body-compact-01: $body-short-01 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$body-long-01: (\n  font-size: scale.type-scale(2),\n  font-weight: font-family.font-weight('regular'),\n  line-height: 1.42857,\n  letter-spacing: 0.16px,\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$body-01: $body-long-01 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$body-short-02: (\n  font-size: scale.type-scale(3),\n  font-weight: font-family.font-weight('regular'),\n  line-height: 1.375,\n  letter-spacing: 0,\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$body-compact-02: $body-short-02 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$body-long-02: (\n  font-size: scale.type-scale(3),\n  font-weight: font-family.font-weight('regular'),\n  line-height: 1.5,\n  letter-spacing: 0,\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$body-02: $body-long-02 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$code-01: (\n  font-family: font-family.font-family('mono'),\n  font-size: scale.type-scale(1),\n  font-weight: font-family.font-weight('regular'),\n  line-height: 1.33333,\n  letter-spacing: 0.32px,\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$code-02: (\n  font-family: font-family.font-family('mono'),\n  font-size: scale.type-scale(2),\n  font-weight: font-family.font-weight('regular'),\n  line-height: 1.42857,\n  letter-spacing: 0.32px,\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$heading-01: (\n  font-size: scale.type-scale(2),\n  font-weight: font-family.font-weight('semibold'),\n  line-height: 1.42857,\n  letter-spacing: 0.16px,\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$productive-heading-01: (\n  font-size: scale.type-scale(2),\n  font-weight: font-family.font-weight('semibold'),\n  line-height: 1.28572,\n  letter-spacing: 0.16px,\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$heading-compact-01: $productive-heading-01 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$heading-02: (\n  font-size: scale.type-scale(3),\n  font-weight: font-family.font-weight('semibold'),\n  line-height: 1.5,\n  letter-spacing: 0,\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$productive-heading-02: (\n  font-size: scale.type-scale(3),\n  font-weight: font-family.font-weight('semibold'),\n  line-height: 1.375,\n  letter-spacing: 0,\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$heading-compact-02: $productive-heading-02 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$productive-heading-03: (\n  font-size: scale.type-scale(5),\n  font-weight: font-family.font-weight('regular'),\n  line-height: 1.4,\n  letter-spacing: 0,\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$heading-03: $productive-heading-03 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$productive-heading-04: (\n  font-size: scale.type-scale(7),\n  font-weight: font-family.font-weight('regular'),\n  line-height: 1.28572,\n  letter-spacing: 0,\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$heading-04: $productive-heading-04 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$productive-heading-05: (\n  font-size: scale.type-scale(8),\n  font-weight: font-family.font-weight('regular'),\n  line-height: 1.25,\n  letter-spacing: 0,\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$heading-05: $productive-heading-05 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$productive-heading-06: (\n  font-size: scale.type-scale(10),\n  font-weight: font-family.font-weight('light'),\n  // Extra digit needed for precision in Chrome\n  line-height: 1.199,\n  letter-spacing: 0,\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$heading-06: $productive-heading-06 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$productive-heading-07: (\n  font-size: scale.type-scale(12),\n  font-weight: font-family.font-weight('light'),\n  line-height: 1.19,\n  letter-spacing: 0,\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$heading-07: $productive-heading-07 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$expressive-heading-01: $heading-01 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$expressive-heading-02: $heading-02 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$expressive-heading-03: (\n  font-size: scale.type-scale(5),\n  font-weight: font-family.font-weight('regular'),\n  line-height: 1.4,\n  letter-spacing: 0,\n  breakpoints: (\n    xlg: (\n      font-size: scale.type-scale(5),\n      line-height: 1.4,\n    ),\n    max: (\n      font-size: scale.type-scale(6),\n      line-height: 1.334,\n    ),\n  ),\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$fluid-heading-03: $expressive-heading-03 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$expressive-heading-04: (\n  font-size: scale.type-scale(7),\n  font-weight: font-family.font-weight('regular'),\n  line-height: 1.28572,\n  letter-spacing: 0,\n  breakpoints: (\n    xlg: (\n      font-size: scale.type-scale(8),\n      line-height: 1.25,\n      font-weight: font-family.font-weight('regular'),\n    ),\n    max: (\n      font-size: scale.type-scale(8),\n      font-weight: font-family.font-weight('regular'),\n    ),\n  ),\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$fluid-heading-04: $expressive-heading-04 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$expressive-heading-05: (\n  font-size: scale.type-scale(8),\n  font-weight: font-family.font-weight('regular'),\n  line-height: 1.25,\n  letter-spacing: 0,\n  breakpoints: (\n    md: (\n      font-size: scale.type-scale(9),\n      font-weight: font-family.font-weight('light'),\n      line-height: 1.22,\n    ),\n    lg: (\n      font-size: scale.type-scale(10),\n      line-height: 1.19,\n    ),\n    xlg: (\n      font-size: scale.type-scale(11),\n      line-height: 1.17,\n    ),\n    max: (\n      font-size: scale.type-scale(13),\n    ),\n  ),\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$fluid-heading-05: $expressive-heading-05 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$expressive-heading-06: (\n  font-size: scale.type-scale(8),\n  font-weight: font-family.font-weight('semibold'),\n  line-height: 1.25,\n  letter-spacing: 0,\n  breakpoints: (\n    md: (\n      font-size: scale.type-scale(9),\n      line-height: 1.22,\n    ),\n    lg: (\n      font-size: scale.type-scale(10),\n      line-height: 1.19,\n    ),\n    xlg: (\n      font-size: scale.type-scale(11),\n      line-height: 1.17,\n    ),\n    max: (\n      font-size: scale.type-scale(13),\n    ),\n  ),\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$fluid-heading-06: $expressive-heading-06 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$expressive-paragraph-01: (\n  font-size: scale.type-scale(6),\n  font-weight: font-family.font-weight('light'),\n  line-height: 1.334,\n  letter-spacing: 0,\n  breakpoints: (\n    lg: (\n      font-size: scale.type-scale(7),\n      line-height: 1.28572,\n    ),\n    max: (\n      font-size: scale.type-scale(8),\n      line-height: 1.25,\n    ),\n  ),\n);\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$fluid-paragraph-01: $expressive-paragraph-01 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$quotation-01: (\n  font-family: font-family.font-family('serif'),\n  font-size: scale.type-scale(5),\n  font-weight: font-family.font-weight('regular'),\n  line-height: 1.3,\n  letter-spacing: 0,\n  breakpoints: (\n    md: (\n      font-size: scale.type-scale(5),\n    ),\n    lg: (\n      font-size: scale.type-scale(6),\n      line-height: 1.334,\n    ),\n    xlg: (\n      font-size: scale.type-scale(7),\n      line-height: 1.28572,\n    ),\n    max: (\n      font-size: scale.type-scale(8),\n      line-height: 1.25,\n    ),\n  ),\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$fluid-quotation-01: $quotation-01 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$quotation-02: (\n  font-family: font-family.font-family('serif'),\n  font-size: scale.type-scale(8),\n  font-weight: font-family.font-weight('light'),\n  line-height: 1.25,\n  letter-spacing: 0,\n  breakpoints: (\n    md: (\n      font-size: scale.type-scale(9),\n      line-height: 1.22,\n    ),\n    lg: (\n      font-size: scale.type-scale(10),\n      line-height: 1.19,\n    ),\n    xlg: (\n      font-size: scale.type-scale(11),\n      line-height: 1.17,\n    ),\n    max: (\n      font-size: scale.type-scale(13),\n    ),\n  ),\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$fluid-quotation-02: $quotation-02 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$display-01: (\n  font-size: scale.type-scale(10),\n  font-weight: font-family.font-weight('light'),\n  line-height: 1.19,\n  letter-spacing: 0,\n  breakpoints: (\n    md: (\n      font-size: scale.type-scale(10),\n    ),\n    lg: (\n      font-size: scale.type-scale(12),\n    ),\n    xlg: (\n      font-size: scale.type-scale(13),\n      line-height: 1.17,\n    ),\n    max: (\n      font-size: scale.type-scale(15),\n      line-height: 1.13,\n    ),\n  ),\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$fluid-display-01: $display-01 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$display-02: (\n  font-size: scale.type-scale(10),\n  font-weight: font-family.font-weight('semibold'),\n  line-height: 1.19,\n  letter-spacing: 0,\n  breakpoints: (\n    md: (\n      font-size: scale.type-scale(10),\n    ),\n    lg: (\n      font-size: scale.type-scale(12),\n    ),\n    xlg: (\n      font-size: scale.type-scale(13),\n      line-height: 1.16,\n    ),\n    max: (\n      font-size: scale.type-scale(15),\n      line-height: 1.13,\n    ),\n  ),\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$fluid-display-02: $display-02 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$display-03: (\n  font-size: scale.type-scale(10),\n  font-weight: font-family.font-weight('light'),\n  line-height: 1.19,\n  letter-spacing: 0,\n  breakpoints: (\n    md: (\n      font-size: scale.type-scale(12),\n      line-height: 1.18,\n    ),\n    lg: (\n      font-size: scale.type-scale(13),\n      line-height: 1.16,\n      letter-spacing: -0.64px,\n    ),\n    xlg: (\n      font-size: scale.type-scale(15),\n      line-height: 1.13,\n      letter-spacing: -0.64px,\n    ),\n    max: (\n      font-size: scale.type-scale(16),\n      line-height: 1.11,\n      letter-spacing: -0.96px,\n    ),\n  ),\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$fluid-display-03: $display-03 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$display-04: (\n  font-size: scale.type-scale(10),\n  font-weight: font-family.font-weight('light'),\n  line-height: 1.19,\n  letter-spacing: 0,\n  breakpoints: (\n    md: (\n      font-size: scale.type-scale(14),\n      line-height: 1.15,\n    ),\n    lg: (\n      font-size: scale.type-scale(17),\n      line-height: 1.11,\n      letter-spacing: -0.64px,\n    ),\n    xlg: (\n      font-size: scale.type-scale(20),\n      line-height: 1.07,\n      letter-spacing: -0.64px,\n    ),\n    max: (\n      font-size: scale.type-scale(23),\n      line-height: 1.05,\n      letter-spacing: -0.96px,\n    ),\n  ),\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$fluid-display-04: $display-04 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$tokens: (\n  caption-01: $caption-01,\n  caption-02: $caption-02,\n  label-01: $label-01,\n  label-02: $label-02,\n  helper-text-01: $helper-text-01,\n  helper-text-02: $helper-text-02,\n  body-short-01: $body-short-01,\n  body-short-02: $body-short-02,\n  body-long-01: $body-long-01,\n  body-long-02: $body-long-02,\n  code-01: $code-01,\n  code-02: $code-02,\n  heading-01: $heading-01,\n  heading-02: $heading-02,\n  productive-heading-01: $productive-heading-01,\n  productive-heading-02: $productive-heading-02,\n  productive-heading-03: $productive-heading-03,\n  productive-heading-04: $productive-heading-04,\n  productive-heading-05: $productive-heading-05,\n  productive-heading-06: $productive-heading-06,\n  productive-heading-07: $productive-heading-07,\n  expressive-paragraph-01: $expressive-paragraph-01,\n  expressive-heading-01: $expressive-heading-01,\n  expressive-heading-02: $expressive-heading-02,\n  expressive-heading-03: $expressive-heading-03,\n  expressive-heading-04: $expressive-heading-04,\n  expressive-heading-05: $expressive-heading-05,\n  expressive-heading-06: $expressive-heading-06,\n  quotation-01: $quotation-01,\n  quotation-02: $quotation-02,\n  display-01: $display-01,\n  display-02: $display-02,\n  display-03: $display-03,\n  display-04: $display-04,\n  // V11 Tokens\n  legal-01: $legal-01,\n  legal-02: $legal-02,\n  body-compact-01: $body-compact-01,\n  body-compact-02: $body-compact-02,\n  heading-compact-01: $heading-compact-01,\n  heading-compact-02: $heading-compact-02,\n  body-01: $body-01,\n  body-02: $body-02,\n  heading-03: $heading-03,\n  heading-04: $heading-04,\n  heading-05: $heading-05,\n  heading-06: $heading-06,\n  heading-07: $heading-07,\n  fluid-heading-03: $fluid-heading-03,\n  fluid-heading-04: $fluid-heading-04,\n  fluid-heading-05: $fluid-heading-05,\n  fluid-heading-06: $fluid-heading-06,\n  fluid-paragraph-01: $fluid-paragraph-01,\n  fluid-quotation-01: $fluid-quotation-01,\n  fluid-quotation-02: $fluid-quotation-02,\n  fluid-display-01: $fluid-display-01,\n  fluid-display-02: $fluid-display-02,\n  fluid-display-03: $fluid-display-03,\n  fluid-display-04: $fluid-display-04,\n) !default;\n\n/// @param {Map} $map\n/// @access public\n/// @group @carbon/type\n@mixin properties($map) {\n  @each $name, $value in $map {\n    #{$name}: $value;\n  }\n}\n\n/// @param {Number} $value - Number with units\n/// @return {Number} Without units\n/// @access public\n/// @group @carbon/type\n@function strip-unit($value) {\n  @return math.div($value, $value * 0 + 1);\n}\n\n/// This helper includes fluid type styles for the given token value. Fluid type\n/// means that the `font-size` is computed using `calc()` in order to be\n/// determined by the screen size instead of a breakpoint. As a result, fluid\n/// styles should be used with caution in fixed width contexts.\n///\n/// In addition, we make use of %-based line-heights so that the line-height of\n/// each type style is computed correctly due to the dynamic nature of the\n/// `font-size`.\n///\n/// Most of the logic for this work comes from CSS Tricks:\n/// https://css-tricks.com/snippets/css/fluid-typography/\n///\n/// @param {Map} $type-styles - The value of a given type token\n/// @param {Map} $breakpoints [$grid-breakpoints] - Custom breakpoints to use\n/// @access public\n/// @group @carbon/type\n@mixin fluid-type($type-styles, $breakpoints: gridconfig.$grid-breakpoints) {\n  // Include the initial styles for the given token by default without any\n  // media query guard. This includes `font-size` as a fallback in the case\n  // that a browser does not support `calc()`\n  @include properties(map.remove($type-styles, breakpoints));\n  // We also need to include the `sm` styles by default since they don't\n  // appear in the fluid styles for tokens\n  @include fluid-type-size($type-styles, sm, $breakpoints);\n\n  // Finally, we need to go through all the breakpoints defined in the type\n  // token and apply the properties and fluid type size for that given\n  // breakpoint\n  @each $name, $values in map.get($type-styles, breakpoints) {\n    @include grid.breakpoint($name) {\n      @include properties($values);\n      @include fluid-type-size($type-styles, $name, $breakpoints);\n    }\n  }\n}\n\n/// Computes the fluid `font-size` for a given type style and breakpoint\n/// @param {Map} $type-styles - The styles for a given token\n/// @param {String} $name - The name of the breakpoint to which we apply the fluid\n/// @param {Map} $breakpoints [$grid-breakpoints] - The breakpoints for the grid system\n/// @access public\n/// @group @carbon/type\n@mixin fluid-type-size(\n  $type-styles,\n  $name,\n  $breakpoints: gridconfig.$grid-breakpoints\n) {\n  // Get the information about the breakpoint we're currently working in. Useful\n  // for getting initial width information\n  $breakpoint: map.get($breakpoints, $name);\n\n  // Our fluid styles are captured under the 'breakpoints' property in our type\n  // styles map. These define what values to treat as `max-` variables below\n  $fluid-sizes: map.get($type-styles, breakpoints);\n  $fluid-breakpoint: ();\n  // Special case for `sm` because the styles for small are on the type style\n  // directly\n  @if $name == sm {\n    $fluid-breakpoint: map.remove($type-styles, breakpoints);\n  } @else {\n    $fluid-breakpoint: map.get($fluid-sizes, $name);\n  }\n\n  // Initialize our font-sizes to the default size for the type style\n  $max-font-size: map.get($type-styles, font-size);\n  $min-font-size: map.get($type-styles, font-size);\n  @if map.has-key($fluid-breakpoint, font-size) {\n    $min-font-size: map.get($fluid-breakpoint, font-size);\n  }\n\n  // Initialize our min and max width to the width of the current breakpoint\n  $max-vw: map.get($breakpoint, width);\n  $min-vw: map.get($breakpoint, width);\n\n  // We can use `breakpoint-next` to see if there is another breakpoint we can\n  // use to update `max-font-size` and `max-vw` with larger values\n  $next-breakpoint-available: grid.breakpoint-next($name, $breakpoints);\n  $next-fluid-breakpoint-name: null;\n\n  // We need to figure out what the next available fluid breakpoint is for our\n  // given $type-styles. In this loop we try and iterate through breakpoints\n  // until we either manually set $next-breakpoint-available to null or\n  // `breakpoint-next` returns null.\n  @while $next-breakpoint-available {\n    @if map.has-key($fluid-sizes, $next-breakpoint-available) {\n      $next-fluid-breakpoint-name: $next-breakpoint-available;\n      $next-breakpoint-available: null;\n    } @else {\n      $next-breakpoint-available: grid.breakpoint-next(\n        $next-breakpoint-available,\n        $breakpoints\n      );\n    }\n  }\n\n  // If we have found the next available fluid breakpoint name, then we know\n  // that we have values that we can use to set max-font-size and max-vw as both\n  // values derive from the next breakpoint\n  @if $next-fluid-breakpoint-name {\n    $next-fluid-breakpoint: map.get($breakpoints, $next-fluid-breakpoint-name);\n    $max-font-size: map.get(\n      map.get($fluid-sizes, $next-fluid-breakpoint-name),\n      font-size\n    );\n    $max-vw: map.get($next-fluid-breakpoint, width);\n\n    // prettier-ignore\n    font-size: calc(#{$min-font-size} +\n      #{strip-unit($max-font-size - $min-font-size)} *\n      ((100vw - #{$min-vw}) / #{strip-unit($max-vw - $min-vw)})\n    );\n  } @else {\n    // Otherwise, just default to setting the font size found from the type\n    // style or the given fluid breakpoint in the type style\n    font-size: $min-font-size;\n  }\n}\n\n// TODO move following variable and `custom-property` mixin into shared file for\n// both `@carbon/type` and `@carbon/themes`\n\n/// @access private\n/// @group @carbon/type\n@mixin custom-properties($name, $value) {\n  @each $property, $value in $value {\n    #{$property}: var(\n      --#{$custom-property-prefix}-#{$name}-#{$property},\n      #{$value}\n    );\n  }\n}\n\n/// Helper mixin to include the styles for a given token in any selector in your\n/// project. Also includes an optional fluid option that will enable fluid\n/// styles for the token if they are defined. Fluid styles will cause the\n/// token's font-size to be computed based on the viewport size. As a result, use\n/// with caution in fixed contexts.\n/// @param {String} $name - The name of the token to get the styles for\n/// @param {Boolean} $fluid [false] - Specify whether to include fluid styles for the\n/// @param {Map} $breakpoints [$grid-breakpoints] - Provide a custom breakpoint map to use\n/// @access public\n/// @group @carbon/type\n@mixin type-style(\n  $name,\n  $fluid: false,\n  $breakpoints: gridconfig.$grid-breakpoints\n) {\n  @if not map.has-key($tokens, $name) {\n    @error 'Unable to find a token with the name: `#{$name}`';\n  }\n\n  $token: map.get($tokens, $name);\n\n  // If $fluid is set to true and the token has breakpoints defined for fluid\n  // styles, delegate to the fluid-type helper for the given token\n  @if $fluid == true and map.has-key($token, 'breakpoints') {\n    @include fluid-type($token, $breakpoints);\n  } @else {\n    @include custom-properties($name, $token);\n  }\n}\n"],"sourceRoot":""}]);
// Exports
___CSS_LOADER_EXPORT___.locals = {
	"printPage": "-esm-patient-vitals__print__printPage___7BQnq",
	"header": "-esm-patient-vitals__print__header___7GY7x",
	"patientDetails": "-esm-patient-vitals__print__patientDetails___7jMXF",
	"patientInfo": "-esm-patient-vitals__print__patientInfo___LIJzR",
	"name": "-esm-patient-vitals__print__name___gfvQ9",
	"footer": "-esm-patient-vitals__print__footer___dK9c-",
	"date": "-esm-patient-vitals__print__date___56Z1T",
	"gender": "-esm-patient-vitals__print__gender___V7a6G",
	"printedBy": "-esm-patient-vitals__print__printedBy___y3CK+",
	"subheader": "-esm-patient-vitals__print__subheader___iXVg7"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "../../node_modules/openmrs/node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[2].use[1]!../../node_modules/openmrs/node_modules/sass-loader/dist/cjs.js??ruleSet[1].rules[2].use[2]!./src/vitals/vitals-chart.scss":
/*!*****************************************************************************************************************************************************************************************************************************!*\
  !*** ../../node_modules/openmrs/node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[2].use[1]!../../node_modules/openmrs/node_modules/sass-loader/dist/cjs.js??ruleSet[1].rules[2].use[2]!./src/vitals/vitals-chart.scss ***!
  \*****************************************************************************************************************************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_openmrs_node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../../node_modules/openmrs/node_modules/css-loader/dist/runtime/cssWithMappingToString.js */ "../../node_modules/openmrs/node_modules/css-loader/dist/runtime/cssWithMappingToString.js");
/* harmony import */ var _node_modules_openmrs_node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_openmrs_node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_openmrs_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../../node_modules/openmrs/node_modules/css-loader/dist/runtime/api.js */ "../../node_modules/openmrs/node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_openmrs_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_openmrs_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_openmrs_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_openmrs_node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0___default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, "/* 60,70 and 80 are already declared as brand-01, 02 and 03 respectively */\n:root {\n  --brand-01: #005d5d;\n  --brand-02: #004144;\n  --brand-03: #007d79;\n  --bottom-nav-height: 4rem;\n  --workspace-header-height: 3rem;\n  --tablet-workspace-window-height: calc(100vh - var(--omrs-navbar-height) - var(--bottom-nav-height));\n  --desktop-workspace-window-height: calc(100vh - var(--omrs-navbar-height) - var(--workspace-header-height));\n}\n\n/* These color variables will be removed in a future release */\n.-esm-patient-vitals__vitals-chart__label01___7a0BS, .-esm-patient-vitals__vitals-chart__vitalsSignLabel___3tJot {\n  font-size: var(--cds-label-01-font-size, 0.75rem);\n  font-weight: var(--cds-label-01-font-weight, 400);\n  line-height: var(--cds-label-01-line-height, 1.33333);\n  letter-spacing: var(--cds-label-01-letter-spacing, 0.32px);\n}\n\n.-esm-patient-vitals__vitals-chart__bodyShort01___fw5MV {\n  font-size: var(--cds-body-compact-01-font-size, 0.875rem);\n  font-weight: var(--cds-body-compact-01-font-weight, 400);\n  line-height: var(--cds-body-compact-01-line-height, 1.28572);\n  letter-spacing: var(--cds-body-compact-01-letter-spacing, 0.16px);\n}\n\n.-esm-patient-vitals__vitals-chart__vitalsChartContainer___0fI1j {\n  display: flex;\n  margin: 0 1rem;\n  flex-direction: row;\n  justify-content: space-between;\n}\n\n.-esm-patient-vitals__vitals-chart__vitalSignsArea___ShIao {\n  flex-grow: 1;\n  margin: 0.5rem 0;\n}\n.-esm-patient-vitals__vitals-chart__vitalSignsArea___ShIao .cds--chart-holder\n      .cds--cc--toolbar\n      .cds--overflow-menu-options\n      .cds--overflow-menu-options__option\n      .cds--overflow-menu-options__btn {\n  max-width: none !important;\n}\n.-esm-patient-vitals__vitals-chart__vitalSignsArea___ShIao .cds--tabs--vertical ~ .cds--tab-content {\n  overflow-y: visible;\n}\n\n.-esm-patient-vitals__vitals-chart__vitalsSignLabel___3tJot {\n  margin-bottom: 1rem;\n  display: inline-block;\n}\n\n.-esm-patient-vitals__vitals-chart__tab___um-oz {\n  outline: 0;\n  outline-offset: 0;\n  min-height: 2rem !important;\n  block-size: 1rem !important;\n}\n.-esm-patient-vitals__vitals-chart__tab___um-oz:active, .-esm-patient-vitals__vitals-chart__tab___um-oz:focus {\n  outline: 0.125rem solid var(--brand-03) !important;\n}\n.-esm-patient-vitals__vitals-chart__tab___um-oz[aria-selected=true] {\n  box-shadow: inset 4px 0 0 0 var(--brand-03) !important;\n  border-bottom: none;\n  font-weight: 600;\n  margin-left: 0 !important;\n}\n.-esm-patient-vitals__vitals-chart__tab___um-oz[aria-selected=false] {\n  border-bottom: none;\n  border-left: 0.125rem solid #e0e0e0;\n  margin-left: 0 !important;\n}\n\n.-esm-patient-vitals__vitals-chart__vitals-value___HqF0a {\n  font-size: 60px;\n  font-weight: 500;\n}", "",{"version":3,"sources":["webpack://./../../node_modules/@openmrs/esm-styleguide/src/_vars.scss","webpack://./src/vitals/vitals-chart.scss","webpack://./../../node_modules/@carbon/type/scss/_styles.scss","webpack://./../../node_modules/@carbon/layout/scss/generated/_spacing.scss"],"names":[],"mappings":"AAkCA,0EAAA;AAoBA;EACE,mBAAA;EACA,mBAAA;EACA,mBAAA;EACA,yBAAA;EACA,+BAAA;EACA,oGAAA;EACA,2GAAA;ACpDF;;ADgEA,8DAAA;ACrEA;EC81BI,iDAAA;EAAA,iDAAA;EAAA,qDAAA;EAAA,0DAAA;ADj1BJ;;AATA;EC01BI,yDAAA;EAAA,wDAAA;EAAA,4DAAA;EAAA,iEAAA;AD10BJ;;AAZA;EACE,aAAA;EACA,cAAA;EACA,mBAAA;EACA,8BAAA;AAeF;;AAZA;EACE,YAAA;EACA,gBAAA;AAeF;AAZE;;;;;EAOE,0BAAA;AAYJ;AARE;EACE,mBAAA;AAUJ;;AANA;EAEE,mBEXW;EFYX,qBAAA;AAQF;;AALA;EACE,UAAA;EACA,iBAAA;EACA,2BAAA;EACA,2BAAA;AAQF;AANE;EAEE,kDAAA;AAOJ;AAJE;EACE,sDAAA;EACA,mBAAA;EACA,gBAAA;EACA,yBAAA;AAMJ;AAHE;EACE,mBAAA;EACA,mCAAA;EACA,yBAAA;AAKJ;;AADA;EACE,eAAA;EACA,gBAAA;AAIF","sourcesContent":["@use '@carbon/layout';\n\n$ui-01: #f4f4f4;\n$ui-02: #ffffff;\n$ui-03: #e0e0e0;\n$ui-04: #8d8d8d;\n$ui-05: #161616;\n$text-02: #525252;\n$text-03: #a8a8a8;\n$ui-background: #ffffff;\n$color-gray-30: #c6c6c6;\n$color-gray-70: #525252;\n$color-gray-100: #161616;\n$color-blue-60-2: #0f62fe;\n$color-blue-10: #edf5ff;\n$color-yellow-50: #feecae;\n$carbon--red-50: #fa4d56;\n$inverse-link: #78a9ff;\n$support-02: #24a148;\n$inverse-support-03: #f1c21b;\n$warning-background: #fff8e1;\n$openmrs-background-grey: #f4f4f4;\n$danger: #da1e28;\n$interactive-01: #0f62fe;\n$field-01: #f4f4f4;\n$grey-2: #e0e0e0;\n$labeldropdown: #c6c6c6;\n\n$brand-primary-10: #d9fbfb;\n$brand-primary-20: #9ef0f0;\n$brand-primary-30: #3ddbd9;\n$brand-primary-40: #08bdba;\n$brand-primary-50: #009d9a;\n\n/* 60,70 and 80 are already declared as brand-01, 02 and 03 respectively */\n\n$brand-primary-90: #022b30;\n$brand-primary-100: #081a1c;\n\n@mixin brand-01($property) {\n  #{$property}: #005d5d;\n  #{$property}: var(--brand-01);\n}\n\n@mixin brand-02($property) {\n  #{$property}: #004144;\n  #{$property}: var(--brand-02);\n}\n\n@mixin brand-03($property) {\n  #{$property}: #007d79;\n  #{$property}: var(--brand-03);\n}\n\n:root {\n  --brand-01: #005d5d;\n  --brand-02: #004144;\n  --brand-03: #007d79;\n  --bottom-nav-height: #{layout.$spacing-10};\n  --workspace-header-height: #{layout.$spacing-09};\n  --tablet-workspace-window-height: calc(100vh - var(--omrs-navbar-height) - var(--bottom-nav-height));\n  --desktop-workspace-window-height: calc(100vh - var(--omrs-navbar-height) - var(--workspace-header-height));\n}\n\n$breakpoint-phone-min: 0px;\n$breakpoint-phone-max: 600px;\n$breakpoint-tablet-min: 601px;\n$breakpoint-tablet-max: 1023px;\n$breakpoint-small-desktop-min: 1024px;\n$breakpoint-small-desktop-max: 1439px;\n$breakpoint-large-desktop-min: 1440px;\n$breakpoint-large-desktop-max: 99999999px;\n\n/* These color variables will be removed in a future release */\n$brand-teal-01: #007d79;\n$brand-01: #005d5d;\n$brand-02: #004144;\n","@use '@carbon/layout';\r\n@use '@carbon/type';\r\n@use '@openmrs/esm-styleguide/src/vars' as *;\r\n\r\n.label01 {\r\n  @include type.type-style('label-01');\r\n}\r\n\r\n.bodyShort01 {\r\n  @include type.type-style('body-compact-01');\r\n}\r\n\r\n.vitalsChartContainer {\r\n  display: flex;\r\n  margin: 0 layout.$spacing-05;\r\n  flex-direction: row;\r\n  justify-content: space-between;\r\n}\r\n\r\n.vitalSignsArea {\r\n  flex-grow: 1;\r\n  margin: layout.$spacing-03 0;\r\n\r\n  // This is a hack to override the max-width of the overflow menu button\r\n  :global(\r\n    .cds--chart-holder\r\n      .cds--cc--toolbar\r\n      .cds--overflow-menu-options\r\n      .cds--overflow-menu-options__option\r\n      .cds--overflow-menu-options__btn\r\n  ) {\r\n    max-width: none !important;\r\n  }\r\n\r\n  // Ensures the chart toolbar tooltips are visible\r\n  :global(.cds--tabs--vertical ~ .cds--tab-content) {\r\n    overflow-y: visible;\r\n  }\r\n}\r\n\r\n.vitalsSignLabel {\r\n  @extend .label01;\r\n  margin-bottom: layout.$spacing-05;\r\n  display: inline-block;\r\n}\r\n\r\n.tab {\r\n  outline: 0;\r\n  outline-offset: 0;\r\n  min-height: layout.$spacing-07 !important;\r\n  block-size: layout.$spacing-05 !important;\r\n\r\n  &:active,\r\n  &:focus {\r\n    outline: layout.$spacing-01 solid var(--brand-03) !important;\r\n  }\r\n\r\n  &[aria-selected='true'] {\r\n    box-shadow: inset 4px 0 0 0 var(--brand-03) !important;\r\n    border-bottom: none;\r\n    font-weight: 600;\r\n    margin-left: 0 !important;\r\n  }\r\n\r\n  &[aria-selected='false'] {\r\n    border-bottom: none;\r\n    border-left: layout.$spacing-01 solid $ui-03;\r\n    margin-left: 0 !important;\r\n  }\r\n}\r\n\r\n.vitals-value {\r\n  font-size: 60px; // adjust as needed\r\n  font-weight: 500;\r\n}\r\n","//\n// Copyright IBM Corp. 2018, 2023\n//\n// This source code is licensed under the Apache-2.0 license found in the\n// LICENSE file in the root directory of this source tree.\n//\n\n// stylelint-disable number-max-precision\n\n@use 'sass:map';\n@use 'sass:math';\n@use '@carbon/grid/scss/config' as gridconfig;\n@use '@carbon/grid/scss/breakpoint' as grid;\n@use 'prefix' as *;\n@use 'font-family';\n@use 'scale';\n\n/// @type Map\n/// @access public\n/// @deprecated\n/// @group @carbon/type\n$caption-01: (\n  font-size: scale.type-scale(1),\n  font-weight: font-family.font-weight('regular'),\n  line-height: 1.33333,\n  letter-spacing: 0.32px,\n) !default;\n\n/// @type Map\n/// @access public\n/// @deprecated\n/// @group @carbon/type\n$caption-02: (\n  font-size: scale.type-scale(2),\n  font-weight: font-family.font-weight('regular'),\n  line-height: 1.28572,\n  letter-spacing: 0.32px,\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$label-01: (\n  font-size: scale.type-scale(1),\n  font-weight: font-family.font-weight('regular'),\n  line-height: 1.33333,\n  letter-spacing: 0.32px,\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$label-02: (\n  font-size: scale.type-scale(2),\n  font-weight: font-family.font-weight('regular'),\n  line-height: 1.28572,\n  letter-spacing: 0.16px,\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$legal-01: (\n  font-size: scale.type-scale(1),\n  font-weight: font-family.font-weight('regular'),\n  line-height: 1.33333,\n  letter-spacing: 0.32px,\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$legal-02: (\n  font-size: scale.type-scale(2),\n  font-weight: font-family.font-weight('regular'),\n  line-height: 1.28572,\n  letter-spacing: 0.16px,\n) !default;\n\n/// @type Map\n/// @access public\n/// @deprecated\n/// @group @carbon/type\n$helper-text-01: (\n  font-size: scale.type-scale(1),\n  line-height: 1.33333,\n  letter-spacing: 0.32px,\n) !default;\n\n/// @type Map\n/// @access public\n/// @deprecated\n/// @group @carbon/type\n$helper-text-02: (\n  font-size: scale.type-scale(2),\n  font-weight: font-family.font-weight('regular'),\n  line-height: 1.28572,\n  letter-spacing: 0.16px,\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$body-short-01: (\n  font-size: scale.type-scale(2),\n  font-weight: font-family.font-weight('regular'),\n  line-height: 1.28572,\n  letter-spacing: 0.16px,\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$body-compact-01: $body-short-01 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$body-long-01: (\n  font-size: scale.type-scale(2),\n  font-weight: font-family.font-weight('regular'),\n  line-height: 1.42857,\n  letter-spacing: 0.16px,\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$body-01: $body-long-01 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$body-short-02: (\n  font-size: scale.type-scale(3),\n  font-weight: font-family.font-weight('regular'),\n  line-height: 1.375,\n  letter-spacing: 0,\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$body-compact-02: $body-short-02 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$body-long-02: (\n  font-size: scale.type-scale(3),\n  font-weight: font-family.font-weight('regular'),\n  line-height: 1.5,\n  letter-spacing: 0,\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$body-02: $body-long-02 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$code-01: (\n  font-family: font-family.font-family('mono'),\n  font-size: scale.type-scale(1),\n  font-weight: font-family.font-weight('regular'),\n  line-height: 1.33333,\n  letter-spacing: 0.32px,\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$code-02: (\n  font-family: font-family.font-family('mono'),\n  font-size: scale.type-scale(2),\n  font-weight: font-family.font-weight('regular'),\n  line-height: 1.42857,\n  letter-spacing: 0.32px,\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$heading-01: (\n  font-size: scale.type-scale(2),\n  font-weight: font-family.font-weight('semibold'),\n  line-height: 1.42857,\n  letter-spacing: 0.16px,\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$productive-heading-01: (\n  font-size: scale.type-scale(2),\n  font-weight: font-family.font-weight('semibold'),\n  line-height: 1.28572,\n  letter-spacing: 0.16px,\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$heading-compact-01: $productive-heading-01 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$heading-02: (\n  font-size: scale.type-scale(3),\n  font-weight: font-family.font-weight('semibold'),\n  line-height: 1.5,\n  letter-spacing: 0,\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$productive-heading-02: (\n  font-size: scale.type-scale(3),\n  font-weight: font-family.font-weight('semibold'),\n  line-height: 1.375,\n  letter-spacing: 0,\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$heading-compact-02: $productive-heading-02 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$productive-heading-03: (\n  font-size: scale.type-scale(5),\n  font-weight: font-family.font-weight('regular'),\n  line-height: 1.4,\n  letter-spacing: 0,\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$heading-03: $productive-heading-03 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$productive-heading-04: (\n  font-size: scale.type-scale(7),\n  font-weight: font-family.font-weight('regular'),\n  line-height: 1.28572,\n  letter-spacing: 0,\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$heading-04: $productive-heading-04 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$productive-heading-05: (\n  font-size: scale.type-scale(8),\n  font-weight: font-family.font-weight('regular'),\n  line-height: 1.25,\n  letter-spacing: 0,\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$heading-05: $productive-heading-05 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$productive-heading-06: (\n  font-size: scale.type-scale(10),\n  font-weight: font-family.font-weight('light'),\n  // Extra digit needed for precision in Chrome\n  line-height: 1.199,\n  letter-spacing: 0,\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$heading-06: $productive-heading-06 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$productive-heading-07: (\n  font-size: scale.type-scale(12),\n  font-weight: font-family.font-weight('light'),\n  line-height: 1.19,\n  letter-spacing: 0,\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$heading-07: $productive-heading-07 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$expressive-heading-01: $heading-01 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$expressive-heading-02: $heading-02 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$expressive-heading-03: (\n  font-size: scale.type-scale(5),\n  font-weight: font-family.font-weight('regular'),\n  line-height: 1.4,\n  letter-spacing: 0,\n  breakpoints: (\n    xlg: (\n      font-size: scale.type-scale(5),\n      line-height: 1.4,\n    ),\n    max: (\n      font-size: scale.type-scale(6),\n      line-height: 1.334,\n    ),\n  ),\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$fluid-heading-03: $expressive-heading-03 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$expressive-heading-04: (\n  font-size: scale.type-scale(7),\n  font-weight: font-family.font-weight('regular'),\n  line-height: 1.28572,\n  letter-spacing: 0,\n  breakpoints: (\n    xlg: (\n      font-size: scale.type-scale(8),\n      line-height: 1.25,\n      font-weight: font-family.font-weight('regular'),\n    ),\n    max: (\n      font-size: scale.type-scale(8),\n      font-weight: font-family.font-weight('regular'),\n    ),\n  ),\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$fluid-heading-04: $expressive-heading-04 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$expressive-heading-05: (\n  font-size: scale.type-scale(8),\n  font-weight: font-family.font-weight('regular'),\n  line-height: 1.25,\n  letter-spacing: 0,\n  breakpoints: (\n    md: (\n      font-size: scale.type-scale(9),\n      font-weight: font-family.font-weight('light'),\n      line-height: 1.22,\n    ),\n    lg: (\n      font-size: scale.type-scale(10),\n      line-height: 1.19,\n    ),\n    xlg: (\n      font-size: scale.type-scale(11),\n      line-height: 1.17,\n    ),\n    max: (\n      font-size: scale.type-scale(13),\n    ),\n  ),\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$fluid-heading-05: $expressive-heading-05 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$expressive-heading-06: (\n  font-size: scale.type-scale(8),\n  font-weight: font-family.font-weight('semibold'),\n  line-height: 1.25,\n  letter-spacing: 0,\n  breakpoints: (\n    md: (\n      font-size: scale.type-scale(9),\n      line-height: 1.22,\n    ),\n    lg: (\n      font-size: scale.type-scale(10),\n      line-height: 1.19,\n    ),\n    xlg: (\n      font-size: scale.type-scale(11),\n      line-height: 1.17,\n    ),\n    max: (\n      font-size: scale.type-scale(13),\n    ),\n  ),\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$fluid-heading-06: $expressive-heading-06 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$expressive-paragraph-01: (\n  font-size: scale.type-scale(6),\n  font-weight: font-family.font-weight('light'),\n  line-height: 1.334,\n  letter-spacing: 0,\n  breakpoints: (\n    lg: (\n      font-size: scale.type-scale(7),\n      line-height: 1.28572,\n    ),\n    max: (\n      font-size: scale.type-scale(8),\n      line-height: 1.25,\n    ),\n  ),\n);\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$fluid-paragraph-01: $expressive-paragraph-01 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$quotation-01: (\n  font-family: font-family.font-family('serif'),\n  font-size: scale.type-scale(5),\n  font-weight: font-family.font-weight('regular'),\n  line-height: 1.3,\n  letter-spacing: 0,\n  breakpoints: (\n    md: (\n      font-size: scale.type-scale(5),\n    ),\n    lg: (\n      font-size: scale.type-scale(6),\n      line-height: 1.334,\n    ),\n    xlg: (\n      font-size: scale.type-scale(7),\n      line-height: 1.28572,\n    ),\n    max: (\n      font-size: scale.type-scale(8),\n      line-height: 1.25,\n    ),\n  ),\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$fluid-quotation-01: $quotation-01 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$quotation-02: (\n  font-family: font-family.font-family('serif'),\n  font-size: scale.type-scale(8),\n  font-weight: font-family.font-weight('light'),\n  line-height: 1.25,\n  letter-spacing: 0,\n  breakpoints: (\n    md: (\n      font-size: scale.type-scale(9),\n      line-height: 1.22,\n    ),\n    lg: (\n      font-size: scale.type-scale(10),\n      line-height: 1.19,\n    ),\n    xlg: (\n      font-size: scale.type-scale(11),\n      line-height: 1.17,\n    ),\n    max: (\n      font-size: scale.type-scale(13),\n    ),\n  ),\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$fluid-quotation-02: $quotation-02 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$display-01: (\n  font-size: scale.type-scale(10),\n  font-weight: font-family.font-weight('light'),\n  line-height: 1.19,\n  letter-spacing: 0,\n  breakpoints: (\n    md: (\n      font-size: scale.type-scale(10),\n    ),\n    lg: (\n      font-size: scale.type-scale(12),\n    ),\n    xlg: (\n      font-size: scale.type-scale(13),\n      line-height: 1.17,\n    ),\n    max: (\n      font-size: scale.type-scale(15),\n      line-height: 1.13,\n    ),\n  ),\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$fluid-display-01: $display-01 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$display-02: (\n  font-size: scale.type-scale(10),\n  font-weight: font-family.font-weight('semibold'),\n  line-height: 1.19,\n  letter-spacing: 0,\n  breakpoints: (\n    md: (\n      font-size: scale.type-scale(10),\n    ),\n    lg: (\n      font-size: scale.type-scale(12),\n    ),\n    xlg: (\n      font-size: scale.type-scale(13),\n      line-height: 1.16,\n    ),\n    max: (\n      font-size: scale.type-scale(15),\n      line-height: 1.13,\n    ),\n  ),\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$fluid-display-02: $display-02 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$display-03: (\n  font-size: scale.type-scale(10),\n  font-weight: font-family.font-weight('light'),\n  line-height: 1.19,\n  letter-spacing: 0,\n  breakpoints: (\n    md: (\n      font-size: scale.type-scale(12),\n      line-height: 1.18,\n    ),\n    lg: (\n      font-size: scale.type-scale(13),\n      line-height: 1.16,\n      letter-spacing: -0.64px,\n    ),\n    xlg: (\n      font-size: scale.type-scale(15),\n      line-height: 1.13,\n      letter-spacing: -0.64px,\n    ),\n    max: (\n      font-size: scale.type-scale(16),\n      line-height: 1.11,\n      letter-spacing: -0.96px,\n    ),\n  ),\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$fluid-display-03: $display-03 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$display-04: (\n  font-size: scale.type-scale(10),\n  font-weight: font-family.font-weight('light'),\n  line-height: 1.19,\n  letter-spacing: 0,\n  breakpoints: (\n    md: (\n      font-size: scale.type-scale(14),\n      line-height: 1.15,\n    ),\n    lg: (\n      font-size: scale.type-scale(17),\n      line-height: 1.11,\n      letter-spacing: -0.64px,\n    ),\n    xlg: (\n      font-size: scale.type-scale(20),\n      line-height: 1.07,\n      letter-spacing: -0.64px,\n    ),\n    max: (\n      font-size: scale.type-scale(23),\n      line-height: 1.05,\n      letter-spacing: -0.96px,\n    ),\n  ),\n) !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$fluid-display-04: $display-04 !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/type\n$tokens: (\n  caption-01: $caption-01,\n  caption-02: $caption-02,\n  label-01: $label-01,\n  label-02: $label-02,\n  helper-text-01: $helper-text-01,\n  helper-text-02: $helper-text-02,\n  body-short-01: $body-short-01,\n  body-short-02: $body-short-02,\n  body-long-01: $body-long-01,\n  body-long-02: $body-long-02,\n  code-01: $code-01,\n  code-02: $code-02,\n  heading-01: $heading-01,\n  heading-02: $heading-02,\n  productive-heading-01: $productive-heading-01,\n  productive-heading-02: $productive-heading-02,\n  productive-heading-03: $productive-heading-03,\n  productive-heading-04: $productive-heading-04,\n  productive-heading-05: $productive-heading-05,\n  productive-heading-06: $productive-heading-06,\n  productive-heading-07: $productive-heading-07,\n  expressive-paragraph-01: $expressive-paragraph-01,\n  expressive-heading-01: $expressive-heading-01,\n  expressive-heading-02: $expressive-heading-02,\n  expressive-heading-03: $expressive-heading-03,\n  expressive-heading-04: $expressive-heading-04,\n  expressive-heading-05: $expressive-heading-05,\n  expressive-heading-06: $expressive-heading-06,\n  quotation-01: $quotation-01,\n  quotation-02: $quotation-02,\n  display-01: $display-01,\n  display-02: $display-02,\n  display-03: $display-03,\n  display-04: $display-04,\n  // V11 Tokens\n  legal-01: $legal-01,\n  legal-02: $legal-02,\n  body-compact-01: $body-compact-01,\n  body-compact-02: $body-compact-02,\n  heading-compact-01: $heading-compact-01,\n  heading-compact-02: $heading-compact-02,\n  body-01: $body-01,\n  body-02: $body-02,\n  heading-03: $heading-03,\n  heading-04: $heading-04,\n  heading-05: $heading-05,\n  heading-06: $heading-06,\n  heading-07: $heading-07,\n  fluid-heading-03: $fluid-heading-03,\n  fluid-heading-04: $fluid-heading-04,\n  fluid-heading-05: $fluid-heading-05,\n  fluid-heading-06: $fluid-heading-06,\n  fluid-paragraph-01: $fluid-paragraph-01,\n  fluid-quotation-01: $fluid-quotation-01,\n  fluid-quotation-02: $fluid-quotation-02,\n  fluid-display-01: $fluid-display-01,\n  fluid-display-02: $fluid-display-02,\n  fluid-display-03: $fluid-display-03,\n  fluid-display-04: $fluid-display-04,\n) !default;\n\n/// @param {Map} $map\n/// @access public\n/// @group @carbon/type\n@mixin properties($map) {\n  @each $name, $value in $map {\n    #{$name}: $value;\n  }\n}\n\n/// @param {Number} $value - Number with units\n/// @return {Number} Without units\n/// @access public\n/// @group @carbon/type\n@function strip-unit($value) {\n  @return math.div($value, $value * 0 + 1);\n}\n\n/// This helper includes fluid type styles for the given token value. Fluid type\n/// means that the `font-size` is computed using `calc()` in order to be\n/// determined by the screen size instead of a breakpoint. As a result, fluid\n/// styles should be used with caution in fixed width contexts.\n///\n/// In addition, we make use of %-based line-heights so that the line-height of\n/// each type style is computed correctly due to the dynamic nature of the\n/// `font-size`.\n///\n/// Most of the logic for this work comes from CSS Tricks:\n/// https://css-tricks.com/snippets/css/fluid-typography/\n///\n/// @param {Map} $type-styles - The value of a given type token\n/// @param {Map} $breakpoints [$grid-breakpoints] - Custom breakpoints to use\n/// @access public\n/// @group @carbon/type\n@mixin fluid-type($type-styles, $breakpoints: gridconfig.$grid-breakpoints) {\n  // Include the initial styles for the given token by default without any\n  // media query guard. This includes `font-size` as a fallback in the case\n  // that a browser does not support `calc()`\n  @include properties(map.remove($type-styles, breakpoints));\n  // We also need to include the `sm` styles by default since they don't\n  // appear in the fluid styles for tokens\n  @include fluid-type-size($type-styles, sm, $breakpoints);\n\n  // Finally, we need to go through all the breakpoints defined in the type\n  // token and apply the properties and fluid type size for that given\n  // breakpoint\n  @each $name, $values in map.get($type-styles, breakpoints) {\n    @include grid.breakpoint($name) {\n      @include properties($values);\n      @include fluid-type-size($type-styles, $name, $breakpoints);\n    }\n  }\n}\n\n/// Computes the fluid `font-size` for a given type style and breakpoint\n/// @param {Map} $type-styles - The styles for a given token\n/// @param {String} $name - The name of the breakpoint to which we apply the fluid\n/// @param {Map} $breakpoints [$grid-breakpoints] - The breakpoints for the grid system\n/// @access public\n/// @group @carbon/type\n@mixin fluid-type-size(\n  $type-styles,\n  $name,\n  $breakpoints: gridconfig.$grid-breakpoints\n) {\n  // Get the information about the breakpoint we're currently working in. Useful\n  // for getting initial width information\n  $breakpoint: map.get($breakpoints, $name);\n\n  // Our fluid styles are captured under the 'breakpoints' property in our type\n  // styles map. These define what values to treat as `max-` variables below\n  $fluid-sizes: map.get($type-styles, breakpoints);\n  $fluid-breakpoint: ();\n  // Special case for `sm` because the styles for small are on the type style\n  // directly\n  @if $name == sm {\n    $fluid-breakpoint: map.remove($type-styles, breakpoints);\n  } @else {\n    $fluid-breakpoint: map.get($fluid-sizes, $name);\n  }\n\n  // Initialize our font-sizes to the default size for the type style\n  $max-font-size: map.get($type-styles, font-size);\n  $min-font-size: map.get($type-styles, font-size);\n  @if map.has-key($fluid-breakpoint, font-size) {\n    $min-font-size: map.get($fluid-breakpoint, font-size);\n  }\n\n  // Initialize our min and max width to the width of the current breakpoint\n  $max-vw: map.get($breakpoint, width);\n  $min-vw: map.get($breakpoint, width);\n\n  // We can use `breakpoint-next` to see if there is another breakpoint we can\n  // use to update `max-font-size` and `max-vw` with larger values\n  $next-breakpoint-available: grid.breakpoint-next($name, $breakpoints);\n  $next-fluid-breakpoint-name: null;\n\n  // We need to figure out what the next available fluid breakpoint is for our\n  // given $type-styles. In this loop we try and iterate through breakpoints\n  // until we either manually set $next-breakpoint-available to null or\n  // `breakpoint-next` returns null.\n  @while $next-breakpoint-available {\n    @if map.has-key($fluid-sizes, $next-breakpoint-available) {\n      $next-fluid-breakpoint-name: $next-breakpoint-available;\n      $next-breakpoint-available: null;\n    } @else {\n      $next-breakpoint-available: grid.breakpoint-next(\n        $next-breakpoint-available,\n        $breakpoints\n      );\n    }\n  }\n\n  // If we have found the next available fluid breakpoint name, then we know\n  // that we have values that we can use to set max-font-size and max-vw as both\n  // values derive from the next breakpoint\n  @if $next-fluid-breakpoint-name {\n    $next-fluid-breakpoint: map.get($breakpoints, $next-fluid-breakpoint-name);\n    $max-font-size: map.get(\n      map.get($fluid-sizes, $next-fluid-breakpoint-name),\n      font-size\n    );\n    $max-vw: map.get($next-fluid-breakpoint, width);\n\n    // prettier-ignore\n    font-size: calc(#{$min-font-size} +\n      #{strip-unit($max-font-size - $min-font-size)} *\n      ((100vw - #{$min-vw}) / #{strip-unit($max-vw - $min-vw)})\n    );\n  } @else {\n    // Otherwise, just default to setting the font size found from the type\n    // style or the given fluid breakpoint in the type style\n    font-size: $min-font-size;\n  }\n}\n\n// TODO move following variable and `custom-property` mixin into shared file for\n// both `@carbon/type` and `@carbon/themes`\n\n/// @access private\n/// @group @carbon/type\n@mixin custom-properties($name, $value) {\n  @each $property, $value in $value {\n    #{$property}: var(\n      --#{$custom-property-prefix}-#{$name}-#{$property},\n      #{$value}\n    );\n  }\n}\n\n/// Helper mixin to include the styles for a given token in any selector in your\n/// project. Also includes an optional fluid option that will enable fluid\n/// styles for the token if they are defined. Fluid styles will cause the\n/// token's font-size to be computed based on the viewport size. As a result, use\n/// with caution in fixed contexts.\n/// @param {String} $name - The name of the token to get the styles for\n/// @param {Boolean} $fluid [false] - Specify whether to include fluid styles for the\n/// @param {Map} $breakpoints [$grid-breakpoints] - Provide a custom breakpoint map to use\n/// @access public\n/// @group @carbon/type\n@mixin type-style(\n  $name,\n  $fluid: false,\n  $breakpoints: gridconfig.$grid-breakpoints\n) {\n  @if not map.has-key($tokens, $name) {\n    @error 'Unable to find a token with the name: `#{$name}`';\n  }\n\n  $token: map.get($tokens, $name);\n\n  // If $fluid is set to true and the token has breakpoints defined for fluid\n  // styles, delegate to the fluid-type helper for the given token\n  @if $fluid == true and map.has-key($token, 'breakpoints') {\n    @include fluid-type($token, $breakpoints);\n  } @else {\n    @include custom-properties($name, $token);\n  }\n}\n","// Code generated by @carbon/layout. DO NOT EDIT.\n//\n// Copyright IBM Corp. 2018, 2023\n//\n// This source code is licensed under the Apache-2.0 license found in the\n// LICENSE file in the root directory of this source tree.\n//\n\n/// @type Number\n/// @access public\n/// @group @carbon/layout\n$spacing-01: 0.125rem !default;\n\n/// @type Number\n/// @access public\n/// @group @carbon/layout\n$spacing-02: 0.25rem !default;\n\n/// @type Number\n/// @access public\n/// @group @carbon/layout\n$spacing-03: 0.5rem !default;\n\n/// @type Number\n/// @access public\n/// @group @carbon/layout\n$spacing-04: 0.75rem !default;\n\n/// @type Number\n/// @access public\n/// @group @carbon/layout\n$spacing-05: 1rem !default;\n\n/// @type Number\n/// @access public\n/// @group @carbon/layout\n$spacing-06: 1.5rem !default;\n\n/// @type Number\n/// @access public\n/// @group @carbon/layout\n$spacing-07: 2rem !default;\n\n/// @type Number\n/// @access public\n/// @group @carbon/layout\n$spacing-08: 2.5rem !default;\n\n/// @type Number\n/// @access public\n/// @group @carbon/layout\n$spacing-09: 3rem !default;\n\n/// @type Number\n/// @access public\n/// @group @carbon/layout\n$spacing-10: 4rem !default;\n\n/// @type Number\n/// @access public\n/// @group @carbon/layout\n$spacing-11: 5rem !default;\n\n/// @type Number\n/// @access public\n/// @group @carbon/layout\n$spacing-12: 6rem !default;\n\n/// @type Number\n/// @access public\n/// @group @carbon/layout\n$spacing-13: 10rem !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/layout\n$spacing: (\n  spacing-01: $spacing-01,\n  spacing-02: $spacing-02,\n  spacing-03: $spacing-03,\n  spacing-04: $spacing-04,\n  spacing-05: $spacing-05,\n  spacing-06: $spacing-06,\n  spacing-07: $spacing-07,\n  spacing-08: $spacing-08,\n  spacing-09: $spacing-09,\n  spacing-10: $spacing-10,\n  spacing-11: $spacing-11,\n  spacing-12: $spacing-12,\n  spacing-13: $spacing-13,\n);\n"],"sourceRoot":""}]);
// Exports
___CSS_LOADER_EXPORT___.locals = {
	"label01": "-esm-patient-vitals__vitals-chart__label01___7a0BS",
	"vitalsSignLabel": "-esm-patient-vitals__vitals-chart__vitalsSignLabel___3tJot",
	"bodyShort01": "-esm-patient-vitals__vitals-chart__bodyShort01___fw5MV",
	"vitalsChartContainer": "-esm-patient-vitals__vitals-chart__vitalsChartContainer___0fI1j",
	"vitalSignsArea": "-esm-patient-vitals__vitals-chart__vitalSignsArea___ShIao",
	"tab": "-esm-patient-vitals__vitals-chart__tab___um-oz",
	"vitals-value": "-esm-patient-vitals__vitals-chart__vitals-value___HqF0a"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "../../node_modules/openmrs/node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[2].use[1]!../../node_modules/openmrs/node_modules/sass-loader/dist/cjs.js??ruleSet[1].rules[2].use[2]!./src/vitals/vitals-overview.scss":
/*!********************************************************************************************************************************************************************************************************************************!*\
  !*** ../../node_modules/openmrs/node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[2].use[1]!../../node_modules/openmrs/node_modules/sass-loader/dist/cjs.js??ruleSet[1].rules[2].use[2]!./src/vitals/vitals-overview.scss ***!
  \********************************************************************************************************************************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_openmrs_node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../../node_modules/openmrs/node_modules/css-loader/dist/runtime/cssWithMappingToString.js */ "../../node_modules/openmrs/node_modules/css-loader/dist/runtime/cssWithMappingToString.js");
/* harmony import */ var _node_modules_openmrs_node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_openmrs_node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_openmrs_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../../node_modules/openmrs/node_modules/css-loader/dist/runtime/api.js */ "../../node_modules/openmrs/node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_openmrs_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_openmrs_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_openmrs_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_openmrs_node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0___default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, "/* 60,70 and 80 are already declared as brand-01, 02 and 03 respectively */\n:root {\n  --brand-01: #005d5d;\n  --brand-02: #004144;\n  --brand-03: #007d79;\n  --bottom-nav-height: 4rem;\n  --workspace-header-height: 3rem;\n  --tablet-workspace-window-height: calc(100vh - var(--omrs-navbar-height) - var(--bottom-nav-height));\n  --desktop-workspace-window-height: calc(100vh - var(--omrs-navbar-height) - var(--workspace-header-height));\n}\n\n/* These color variables will be removed in a future release */\n.-esm-patient-vitals__vitals-overview__widgetCard___ida5k {\n  background-color: #ffffff;\n  border: 1px solid #e0e0e0;\n}\n\n.-esm-patient-vitals__vitals-overview__divider___du\\+jm {\n  width: 1px;\n  height: 1rem;\n  color: #161616;\n  margin: 0 1rem;\n}\n\n.-esm-patient-vitals__vitals-overview__vitalsHeaderActionItems___OhE0b {\n  align-items: center;\n  display: flex;\n  flex: 1 1 0%;\n  justify-content: end;\n}\n.-esm-patient-vitals__vitals-overview__vitalsHeaderActionItems___OhE0b .cds--content-switcher {\n  max-width: max-content;\n}\n.-esm-patient-vitals__vitals-overview__vitalsHeaderActionItems___OhE0b .cds--content-switcher .cds--content-switcher__label {\n  height: 1rem;\n}\n\n.-esm-patient-vitals__vitals-overview__customRow___LVqEW tbody {\n  white-space: nowrap;\n}\n\n.-esm-patient-vitals__vitals-overview__backgroundDataFetchingIndicator___AJ9fR {\n  align-items: center;\n  display: flex;\n  flex: 1 1 0%;\n  justify-content: end;\n}\n\n.-esm-patient-vitals__vitals-overview__printButton___LwyUE {\n  margin-left: 1.25rem;\n}\n\nth {\n  white-space: pre-line;\n  text-align: center;\n  max-width: fit-content;\n  word-break: break-word;\n  overflow-wrap: break-word;\n}\n\n.-esm-patient-vitals__vitals-overview__stigmaChartContainer___S8HQU {\n  margin: 1rem;\n  padding: 1rem;\n  background-color: #ffffff;\n  border-radius: 0.5rem;\n  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);\n  width: calc(100% - 2rem);\n  transition: all 0.3s ease;\n  overflow: hidden;\n}\n.-esm-patient-vitals__vitals-overview__stigmaChartContainer___S8HQU h3 {\n  margin-top: 0;\n  color: #262626;\n}\n\n.-esm-patient-vitals__vitals-overview__stigmaChartButton___lMr1D {\n  position: relative;\n  overflow: hidden;\n  border-radius: 20px;\n  transition: all 0.3s ease;\n}\n.-esm-patient-vitals__vitals-overview__stigmaChartButton___lMr1D:hover {\n  transform: translateY(-2px);\n  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);\n}\n\n.-esm-patient-vitals__vitals-overview__clickableHeader___5ya8e {\n  cursor: pointer;\n  position: relative;\n  transition: all 0.2s ease;\n  display: inline-block;\n  white-space: pre-line;\n  text-align: center;\n}\n.-esm-patient-vitals__vitals-overview__clickableHeader___5ya8e:hover {\n  color: #0f62fe;\n  text-decoration: underline;\n}\n.-esm-patient-vitals__vitals-overview__clickableHeader___5ya8e:focus {\n  outline: 2px solid #0f62fe;\n  outline-offset: 2px;\n}\n\n.-esm-patient-vitals__vitals-overview__clickableIcon___SI2td {\n  margin-left: 4px;\n  opacity: 0.7;\n  font-size: 1rem;\n}\n\n.-esm-patient-vitals__vitals-overview__titleChartButton___FqZpD {\n  padding: 0 0.5rem;\n  min-height: unset;\n  height: auto;\n  font-weight: 600;\n  margin-right: 1rem;\n  font-size: 0.875rem;\n  color: #161616;\n  text-decoration: none;\n  display: flex;\n  align-items: center;\n  transition: all 0.2s ease;\n}\n.-esm-patient-vitals__vitals-overview__titleChartButton___FqZpD:hover, .-esm-patient-vitals__vitals-overview__titleChartButton___FqZpD:focus {\n  color: #0f62fe;\n  text-decoration: underline;\n  background-color: transparent;\n}\n\n.-esm-patient-vitals__vitals-overview__chartIcon___BsCl8 {\n  margin-left: 8px;\n  font-size: 1.2rem;\n  transition: transform 0.3s ease;\n}\n.-esm-patient-vitals__vitals-overview__titleChartButton___FqZpD:hover .-esm-patient-vitals__vitals-overview__chartIcon___BsCl8 {\n  transform: scale(1.2);\n}", "",{"version":3,"sources":["webpack://./../../node_modules/@openmrs/esm-styleguide/src/_vars.scss","webpack://./src/vitals/vitals-overview.scss","webpack://./../../node_modules/@carbon/colors/index.scss","webpack://./../../node_modules/@carbon/layout/scss/generated/_spacing.scss"],"names":[],"mappings":"AAkCA,0EAAA;AAoBA;EACE,mBAAA;EACA,mBAAA;EACA,mBAAA;EACA,yBAAA;EACA,+BAAA;EACA,oGAAA;EACA,2GAAA;ACpDF;;ADgEA,8DAAA;ACrEA;EACE,yBCIM;EDHN,yBAAA;AASF;;AANA;EACE,UAAA;EACA,YEoBW;EFnBX,cDNM;ECON,cAAA;AASF;;AANA;EACE,mBAAA;EACA,aAAA;EACA,YAAA;EACA,oBAAA;AASF;AAPE;EACE,sBAAA;AASJ;AAPI;EACE,YEKO;AFIb;;AAJA;EACE,mBAAA;AAOF;;AAJA;EACE,mBAAA;EACA,aAAA;EACA,YAAA;EACA,oBAAA;AAOF;;AAJA;EACE,oBAAA;AAOF;;AAJA;EACE,qBAAA;EACA,kBAAA;EACA,sBAAA;EACA,sBAAA;EACA,yBAAA;AAOF;;AAJA;EACE,YAAA;EACA,aAAA;EACA,yBChDM;EDiDN,qBAAA;EACA,yCAAA;EACA,wBAAA;EACA,yBAAA;EACA,gBAAA;AAOF;AALE;EACE,aAAA;EACA,cChBM;ADuBV;;AAHA;EACE,kBAAA;EACA,gBAAA;EACA,mBAAA;EACA,yBAAA;AAMF;AAJE;EACE,2BAAA;EACA,wCAAA;AAMJ;;AAFA;EACE,eAAA;EACA,kBAAA;EACA,yBAAA;EACA,qBAAA;EACA,qBAAA;EACA,kBAAA;AAKF;AAHE;EACE,cC1EM;ED2EN,0BAAA;AAKJ;AAFE;EACE,0BAAA;EACA,mBAAA;AAIJ;;AAAA;EACE,gBAAA;EACA,YAAA;EACA,eAAA;AAGF;;AAAA;EACE,iBAAA;EACA,iBAAA;EACA,YAAA;EACA,gBAAA;EACA,kBAAA;EACA,mBAAA;EACA,cC/DS;EDgET,qBAAA;EACA,aAAA;EACA,mBAAA;EACA,yBAAA;AAGF;AADE;EAEE,cCzGM;ED0GN,0BAAA;EACA,6BAAA;AAEJ;;AAEA;EACE,gBAAA;EACA,iBAAA;EACA,+BAAA;AACF;AACE;EACE,qBAAA;AACJ","sourcesContent":["@use '@carbon/layout';\n\n$ui-01: #f4f4f4;\n$ui-02: #ffffff;\n$ui-03: #e0e0e0;\n$ui-04: #8d8d8d;\n$ui-05: #161616;\n$text-02: #525252;\n$text-03: #a8a8a8;\n$ui-background: #ffffff;\n$color-gray-30: #c6c6c6;\n$color-gray-70: #525252;\n$color-gray-100: #161616;\n$color-blue-60-2: #0f62fe;\n$color-blue-10: #edf5ff;\n$color-yellow-50: #feecae;\n$carbon--red-50: #fa4d56;\n$inverse-link: #78a9ff;\n$support-02: #24a148;\n$inverse-support-03: #f1c21b;\n$warning-background: #fff8e1;\n$openmrs-background-grey: #f4f4f4;\n$danger: #da1e28;\n$interactive-01: #0f62fe;\n$field-01: #f4f4f4;\n$grey-2: #e0e0e0;\n$labeldropdown: #c6c6c6;\n\n$brand-primary-10: #d9fbfb;\n$brand-primary-20: #9ef0f0;\n$brand-primary-30: #3ddbd9;\n$brand-primary-40: #08bdba;\n$brand-primary-50: #009d9a;\n\n/* 60,70 and 80 are already declared as brand-01, 02 and 03 respectively */\n\n$brand-primary-90: #022b30;\n$brand-primary-100: #081a1c;\n\n@mixin brand-01($property) {\n  #{$property}: #005d5d;\n  #{$property}: var(--brand-01);\n}\n\n@mixin brand-02($property) {\n  #{$property}: #004144;\n  #{$property}: var(--brand-02);\n}\n\n@mixin brand-03($property) {\n  #{$property}: #007d79;\n  #{$property}: var(--brand-03);\n}\n\n:root {\n  --brand-01: #005d5d;\n  --brand-02: #004144;\n  --brand-03: #007d79;\n  --bottom-nav-height: #{layout.$spacing-10};\n  --workspace-header-height: #{layout.$spacing-09};\n  --tablet-workspace-window-height: calc(100vh - var(--omrs-navbar-height) - var(--bottom-nav-height));\n  --desktop-workspace-window-height: calc(100vh - var(--omrs-navbar-height) - var(--workspace-header-height));\n}\n\n$breakpoint-phone-min: 0px;\n$breakpoint-phone-max: 600px;\n$breakpoint-tablet-min: 601px;\n$breakpoint-tablet-max: 1023px;\n$breakpoint-small-desktop-min: 1024px;\n$breakpoint-small-desktop-max: 1439px;\n$breakpoint-large-desktop-min: 1440px;\n$breakpoint-large-desktop-max: 99999999px;\n\n/* These color variables will be removed in a future release */\n$brand-teal-01: #007d79;\n$brand-01: #005d5d;\n$brand-02: #004144;\n","@use '@carbon/colors';\r\n@use '@carbon/layout';\r\n@use '@openmrs/esm-styleguide/src/vars' as *;\r\n\r\n.widgetCard {\r\n  background-color: colors.$white;\r\n  border: 1px solid colors.$gray-20;\r\n}\r\n\r\n.divider {\r\n  width: 1px;\r\n  height: layout.$spacing-05;\r\n  color: $ui-05;\r\n  margin: 0 layout.$spacing-05;\r\n}\r\n\r\n.vitalsHeaderActionItems {\r\n  align-items: center;\r\n  display: flex;\r\n  flex: 1 1 0%;\r\n  justify-content: end;\r\n\r\n  & :global(.cds--content-switcher) {\r\n    max-width: max-content;\r\n\r\n    :global(.cds--content-switcher__label) {\r\n      height: layout.$spacing-05;\r\n    }\r\n  }\r\n}\r\n\r\n.customRow tbody {\r\n  white-space: nowrap;\r\n}\r\n\r\n.backgroundDataFetchingIndicator {\r\n  align-items: center;\r\n  display: flex;\r\n  flex: 1 1 0%;\r\n  justify-content: end;\r\n}\r\n\r\n.printButton {\r\n  margin-left: 1.25rem;\r\n}\r\n\r\nth {\r\n  white-space: pre-line;\r\n  text-align: center;\r\n  max-width: fit-content;\r\n  word-break: break-word;\r\n  overflow-wrap: break-word;\r\n}\r\n\r\n.stigmaChartContainer {\r\n  margin: 1rem;\r\n  padding: 1rem;\r\n  background-color: colors.$white;\r\n  border-radius: 0.5rem;\r\n  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);\r\n  width: calc(100% - 2rem);\r\n  transition: all 0.3s ease;\r\n  overflow: hidden;\r\n\r\n  h3 {\r\n    margin-top: 0;\r\n    color: colors.$gray-90;\r\n  }\r\n}\r\n\r\n.stigmaChartButton {\r\n  position: relative;\r\n  overflow: hidden;\r\n  border-radius: 20px;\r\n  transition: all 0.3s ease;\r\n\r\n  &:hover {\r\n    transform: translateY(-2px);\r\n    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);\r\n  }\r\n}\r\n\r\n.clickableHeader {\r\n  cursor: pointer;\r\n  position: relative;\r\n  transition: all 0.2s ease;\r\n  display: inline-block;\r\n  white-space: pre-line;\r\n  text-align: center;\r\n\r\n  &:hover {\r\n    color: colors.$blue-60;\r\n    text-decoration: underline;\r\n  }\r\n\r\n  &:focus {\r\n    outline: 2px solid colors.$blue-60;\r\n    outline-offset: 2px;\r\n  }\r\n}\r\n\r\n.clickableIcon {\r\n  margin-left: 4px;\r\n  opacity: 0.7;\r\n  font-size: 1rem;\r\n}\r\n\r\n.titleChartButton {\r\n  padding: 0 0.5rem;\r\n  min-height: unset;\r\n  height: auto;\r\n  font-weight: 600;\r\n  margin-right: 1rem;\r\n  font-size: 0.875rem;\r\n  color: colors.$gray-100;\r\n  text-decoration: none;\r\n  display: flex;\r\n  align-items: center;\r\n  transition: all 0.2s ease;\r\n\r\n  &:hover,\r\n  &:focus {\r\n    color: colors.$blue-60;\r\n    text-decoration: underline;\r\n    background-color: transparent;\r\n  }\r\n}\r\n\r\n.chartIcon {\r\n  margin-left: 8px;\r\n  font-size: 1.2rem;\r\n  transition: transform 0.3s ease;\r\n\r\n  .titleChartButton:hover & {\r\n    transform: scale(1.2);\r\n  }\r\n}\r\n","// Code generated by @carbon/colors. DO NOT EDIT.\n//\n// Copyright IBM Corp. 2018, 2023\n//\n// This source code is licensed under the Apache-2.0 license found in the\n// LICENSE file in the root directory of this source tree.\n//\n\n$black: #000000 !default;\n$white: #ffffff !default;\n\n$black-100: #000000 !default;\n$blue-10: #edf5ff !default;\n$blue-20: #d0e2ff !default;\n$blue-30: #a6c8ff !default;\n$blue-40: #78a9ff !default;\n$blue-50: #4589ff !default;\n$blue-60: #0f62fe !default;\n$blue-70: #0043ce !default;\n$blue-80: #002d9c !default;\n$blue-90: #001d6c !default;\n$blue-100: #001141 !default;\n$cool-gray-10: #f2f4f8 !default;\n$cool-gray-20: #dde1e6 !default;\n$cool-gray-30: #c1c7cd !default;\n$cool-gray-40: #a2a9b0 !default;\n$cool-gray-50: #878d96 !default;\n$cool-gray-60: #697077 !default;\n$cool-gray-70: #4d5358 !default;\n$cool-gray-80: #343a3f !default;\n$cool-gray-90: #21272a !default;\n$cool-gray-100: #121619 !default;\n$cyan-10: #e5f6ff !default;\n$cyan-20: #bae6ff !default;\n$cyan-30: #82cfff !default;\n$cyan-40: #33b1ff !default;\n$cyan-50: #1192e8 !default;\n$cyan-60: #0072c3 !default;\n$cyan-70: #00539a !default;\n$cyan-80: #003a6d !default;\n$cyan-90: #012749 !default;\n$cyan-100: #061727 !default;\n$gray-10: #f4f4f4 !default;\n$gray-20: #e0e0e0 !default;\n$gray-30: #c6c6c6 !default;\n$gray-40: #a8a8a8 !default;\n$gray-50: #8d8d8d !default;\n$gray-60: #6f6f6f !default;\n$gray-70: #525252 !default;\n$gray-80: #393939 !default;\n$gray-90: #262626 !default;\n$gray-100: #161616 !default;\n$green-10: #defbe6 !default;\n$green-20: #a7f0ba !default;\n$green-30: #6fdc8c !default;\n$green-40: #42be65 !default;\n$green-50: #24a148 !default;\n$green-60: #198038 !default;\n$green-70: #0e6027 !default;\n$green-80: #044317 !default;\n$green-90: #022d0d !default;\n$green-100: #071908 !default;\n$magenta-10: #fff0f7 !default;\n$magenta-20: #ffd6e8 !default;\n$magenta-30: #ffafd2 !default;\n$magenta-40: #ff7eb6 !default;\n$magenta-50: #ee5396 !default;\n$magenta-60: #d02670 !default;\n$magenta-70: #9f1853 !default;\n$magenta-80: #740937 !default;\n$magenta-90: #510224 !default;\n$magenta-100: #2a0a18 !default;\n$orange-10: #fff2e8 !default;\n$orange-20: #ffd9be !default;\n$orange-30: #ffb784 !default;\n$orange-40: #ff832b !default;\n$orange-50: #eb6200 !default;\n$orange-60: #ba4e00 !default;\n$orange-70: #8a3800 !default;\n$orange-80: #5e2900 !default;\n$orange-90: #3e1a00 !default;\n$orange-100: #231000 !default;\n$purple-10: #f6f2ff !default;\n$purple-20: #e8daff !default;\n$purple-30: #d4bbff !default;\n$purple-40: #be95ff !default;\n$purple-50: #a56eff !default;\n$purple-60: #8a3ffc !default;\n$purple-70: #6929c4 !default;\n$purple-80: #491d8b !default;\n$purple-90: #31135e !default;\n$purple-100: #1c0f30 !default;\n$red-10: #fff1f1 !default;\n$red-20: #ffd7d9 !default;\n$red-30: #ffb3b8 !default;\n$red-40: #ff8389 !default;\n$red-50: #fa4d56 !default;\n$red-60: #da1e28 !default;\n$red-70: #a2191f !default;\n$red-80: #750e13 !default;\n$red-90: #520408 !default;\n$red-100: #2d0709 !default;\n$teal-10: #d9fbfb !default;\n$teal-20: #9ef0f0 !default;\n$teal-30: #3ddbd9 !default;\n$teal-40: #08bdba !default;\n$teal-50: #009d9a !default;\n$teal-60: #007d79 !default;\n$teal-70: #005d5d !default;\n$teal-80: #004144 !default;\n$teal-90: #022b30 !default;\n$teal-100: #081a1c !default;\n$warm-gray-10: #f7f3f2 !default;\n$warm-gray-20: #e5e0df !default;\n$warm-gray-30: #cac5c4 !default;\n$warm-gray-40: #ada8a8 !default;\n$warm-gray-50: #8f8b8b !default;\n$warm-gray-60: #726e6e !default;\n$warm-gray-70: #565151 !default;\n$warm-gray-80: #3c3838 !default;\n$warm-gray-90: #272525 !default;\n$warm-gray-100: #171414 !default;\n$white-0: #ffffff !default;\n$yellow-10: #fcf4d6 !default;\n$yellow-20: #fddc69 !default;\n$yellow-30: #f1c21b !default;\n$yellow-40: #d2a106 !default;\n$yellow-50: #b28600 !default;\n$yellow-60: #8e6a00 !default;\n$yellow-70: #684e00 !default;\n$yellow-80: #483700 !default;\n$yellow-90: #302400 !default;\n$yellow-100: #1c1500 !default;\n\n$white-hover: #e8e8e8 !default;\n$black-hover: #212121 !default;\n$blue-10-hover: #dbebff !default;\n$blue-20-hover: #b8d3ff !default;\n$blue-30-hover: #8ab6ff !default;\n$blue-40-hover: #5c97ff !default;\n$blue-50-hover: #1f70ff !default;\n$blue-60-hover: #0050e6 !default;\n$blue-70-hover: #0053ff !default;\n$blue-80-hover: #0039c7 !default;\n$blue-90-hover: #00258a !default;\n$blue-100-hover: #001f75 !default;\n$cool-gray-10-hover: #e4e9f1 !default;\n$cool-gray-20-hover: #cdd3da !default;\n$cool-gray-30-hover: #adb5bd !default;\n$cool-gray-40-hover: #9199a1 !default;\n$cool-gray-50-hover: #757b85 !default;\n$cool-gray-60-hover: #585e64 !default;\n$cool-gray-70-hover: #5d646a !default;\n$cool-gray-80-hover: #434a51 !default;\n$cool-gray-90-hover: #2b3236 !default;\n$cool-gray-100-hover: #222a2f !default;\n$cyan-10-hover: #cceeff !default;\n$cyan-20-hover: #99daff !default;\n$cyan-30-hover: #57beff !default;\n$cyan-40-hover: #059fff !default;\n$cyan-50-hover: #0f7ec8 !default;\n$cyan-60-hover: #005fa3 !default;\n$cyan-70-hover: #0066bd !default;\n$cyan-80-hover: #00498a !default;\n$cyan-90-hover: #013360 !default;\n$cyan-100-hover: #0b2947 !default;\n$gray-10-hover: #e8e8e8 !default;\n$gray-20-hover: #d1d1d1 !default;\n$gray-30-hover: #b5b5b5 !default;\n$gray-40-hover: #999999 !default;\n$gray-50-hover: #7a7a7a !default;\n$gray-60-hover: #5e5e5e !default;\n$gray-70-hover: #636363 !default;\n$gray-80-hover: #474747 !default;\n$gray-90-hover: #333333 !default;\n$gray-100-hover: #292929 !default;\n$green-10-hover: #b6f6c8 !default;\n$green-20-hover: #74e792 !default;\n$green-30-hover: #36ce5e !default;\n$green-40-hover: #3bab5a !default;\n$green-50-hover: #208e3f !default;\n$green-60-hover: #166f31 !default;\n$green-70-hover: #11742f !default;\n$green-80-hover: #05521c !default;\n$green-90-hover: #033b11 !default;\n$green-100-hover: #0d300f !default;\n$magenta-10-hover: #ffe0ef !default;\n$magenta-20-hover: #ffbdda !default;\n$magenta-30-hover: #ff94c3 !default;\n$magenta-40-hover: #ff57a0 !default;\n$magenta-50-hover: #e3176f !default;\n$magenta-60-hover: #b0215f !default;\n$magenta-70-hover: #bf1d63 !default;\n$magenta-80-hover: #8e0b43 !default;\n$magenta-90-hover: #68032e !default;\n$magenta-100-hover: #53142f !default;\n$orange-10-hover: #ffe2cc !default;\n$orange-20-hover: #ffc69e !default;\n$orange-30-hover: #ff9d57 !default;\n$orange-40-hover: #fa6800 !default;\n$orange-50-hover: #cc5500 !default;\n$orange-60-hover: #9e4200 !default;\n$orange-70-hover: #a84400 !default;\n$orange-80-hover: #753300 !default;\n$orange-90-hover: #522200 !default;\n$orange-100-hover: #421e00 !default;\n$purple-10-hover: #ede5ff !default;\n$purple-20-hover: #dcc7ff !default;\n$purple-30-hover: #c5a3ff !default;\n$purple-40-hover: #ae7aff !default;\n$purple-50-hover: #9352ff !default;\n$purple-60-hover: #7822fb !default;\n$purple-70-hover: #7c3dd6 !default;\n$purple-80-hover: #5b24ad !default;\n$purple-90-hover: #40197b !default;\n$purple-100-hover: #341c59 !default;\n$red-10-hover: #ffe0e0 !default;\n$red-20-hover: #ffc2c5 !default;\n$red-30-hover: #ff99a0 !default;\n$red-40-hover: #ff6168 !default;\n$red-50-hover: #ee0713 !default;\n$red-60-hover: #b81922 !default;\n$red-70-hover: #c21e25 !default;\n$red-80-hover: #921118 !default;\n$red-90-hover: #66050a !default;\n$red-100-hover: #540d11 !default;\n$teal-10-hover: #acf6f6 !default;\n$teal-20-hover: #57e5e5 !default;\n$teal-30-hover: #25cac8 !default;\n$teal-40-hover: #07aba9 !default;\n$teal-50-hover: #008a87 !default;\n$teal-60-hover: #006b68 !default;\n$teal-70-hover: #007070 !default;\n$teal-80-hover: #005357 !default;\n$teal-90-hover: #033940 !default;\n$teal-100-hover: #0f3034 !default;\n$warm-gray-10-hover: #f0e8e6 !default;\n$warm-gray-20-hover: #d8d0cf !default;\n$warm-gray-30-hover: #b9b3b1 !default;\n$warm-gray-40-hover: #9c9696 !default;\n$warm-gray-50-hover: #7f7b7b !default;\n$warm-gray-60-hover: #605d5d !default;\n$warm-gray-70-hover: #696363 !default;\n$warm-gray-80-hover: #4c4848 !default;\n$warm-gray-90-hover: #343232 !default;\n$warm-gray-100-hover: #2c2626 !default;\n$yellow-10-hover: #f8e6a0 !default;\n$yellow-20-hover: #fccd27 !default;\n$yellow-30-hover: #ddb00e !default;\n$yellow-40-hover: #bc9005 !default;\n$yellow-50-hover: #9e7700 !default;\n$yellow-60-hover: #755800 !default;\n$yellow-70-hover: #806000 !default;\n$yellow-80-hover: #5c4600 !default;\n$yellow-90-hover: #3d2e00 !default;\n$yellow-100-hover: #332600 !default;\n\n/// Colors from the IBM Design Language\n/// @access public\n/// @group @carbon/colors\n$colors: (\n  black: (\n    100: #000000,\n  ),\n  blue: (\n    10: #edf5ff,\n    20: #d0e2ff,\n    30: #a6c8ff,\n    40: #78a9ff,\n    50: #4589ff,\n    60: #0f62fe,\n    70: #0043ce,\n    80: #002d9c,\n    90: #001d6c,\n    100: #001141,\n  ),\n  cool-gray: (\n    10: #f2f4f8,\n    20: #dde1e6,\n    30: #c1c7cd,\n    40: #a2a9b0,\n    50: #878d96,\n    60: #697077,\n    70: #4d5358,\n    80: #343a3f,\n    90: #21272a,\n    100: #121619,\n  ),\n  cyan: (\n    10: #e5f6ff,\n    20: #bae6ff,\n    30: #82cfff,\n    40: #33b1ff,\n    50: #1192e8,\n    60: #0072c3,\n    70: #00539a,\n    80: #003a6d,\n    90: #012749,\n    100: #061727,\n  ),\n  gray: (\n    10: #f4f4f4,\n    20: #e0e0e0,\n    30: #c6c6c6,\n    40: #a8a8a8,\n    50: #8d8d8d,\n    60: #6f6f6f,\n    70: #525252,\n    80: #393939,\n    90: #262626,\n    100: #161616,\n  ),\n  green: (\n    10: #defbe6,\n    20: #a7f0ba,\n    30: #6fdc8c,\n    40: #42be65,\n    50: #24a148,\n    60: #198038,\n    70: #0e6027,\n    80: #044317,\n    90: #022d0d,\n    100: #071908,\n  ),\n  magenta: (\n    10: #fff0f7,\n    20: #ffd6e8,\n    30: #ffafd2,\n    40: #ff7eb6,\n    50: #ee5396,\n    60: #d02670,\n    70: #9f1853,\n    80: #740937,\n    90: #510224,\n    100: #2a0a18,\n  ),\n  orange: (\n    10: #fff2e8,\n    20: #ffd9be,\n    30: #ffb784,\n    40: #ff832b,\n    50: #eb6200,\n    60: #ba4e00,\n    70: #8a3800,\n    80: #5e2900,\n    90: #3e1a00,\n    100: #231000,\n  ),\n  purple: (\n    10: #f6f2ff,\n    20: #e8daff,\n    30: #d4bbff,\n    40: #be95ff,\n    50: #a56eff,\n    60: #8a3ffc,\n    70: #6929c4,\n    80: #491d8b,\n    90: #31135e,\n    100: #1c0f30,\n  ),\n  red: (\n    10: #fff1f1,\n    20: #ffd7d9,\n    30: #ffb3b8,\n    40: #ff8389,\n    50: #fa4d56,\n    60: #da1e28,\n    70: #a2191f,\n    80: #750e13,\n    90: #520408,\n    100: #2d0709,\n  ),\n  teal: (\n    10: #d9fbfb,\n    20: #9ef0f0,\n    30: #3ddbd9,\n    40: #08bdba,\n    50: #009d9a,\n    60: #007d79,\n    70: #005d5d,\n    80: #004144,\n    90: #022b30,\n    100: #081a1c,\n  ),\n  warm-gray: (\n    10: #f7f3f2,\n    20: #e5e0df,\n    30: #cac5c4,\n    40: #ada8a8,\n    50: #8f8b8b,\n    60: #726e6e,\n    70: #565151,\n    80: #3c3838,\n    90: #272525,\n    100: #171414,\n  ),\n  white: (\n    0: #ffffff,\n  ),\n  yellow: (\n    10: #fcf4d6,\n    20: #fddc69,\n    30: #f1c21b,\n    40: #d2a106,\n    50: #b28600,\n    60: #8e6a00,\n    70: #684e00,\n    80: #483700,\n    90: #302400,\n    100: #1c1500,\n  ),\n) !default;\n","// Code generated by @carbon/layout. DO NOT EDIT.\n//\n// Copyright IBM Corp. 2018, 2023\n//\n// This source code is licensed under the Apache-2.0 license found in the\n// LICENSE file in the root directory of this source tree.\n//\n\n/// @type Number\n/// @access public\n/// @group @carbon/layout\n$spacing-01: 0.125rem !default;\n\n/// @type Number\n/// @access public\n/// @group @carbon/layout\n$spacing-02: 0.25rem !default;\n\n/// @type Number\n/// @access public\n/// @group @carbon/layout\n$spacing-03: 0.5rem !default;\n\n/// @type Number\n/// @access public\n/// @group @carbon/layout\n$spacing-04: 0.75rem !default;\n\n/// @type Number\n/// @access public\n/// @group @carbon/layout\n$spacing-05: 1rem !default;\n\n/// @type Number\n/// @access public\n/// @group @carbon/layout\n$spacing-06: 1.5rem !default;\n\n/// @type Number\n/// @access public\n/// @group @carbon/layout\n$spacing-07: 2rem !default;\n\n/// @type Number\n/// @access public\n/// @group @carbon/layout\n$spacing-08: 2.5rem !default;\n\n/// @type Number\n/// @access public\n/// @group @carbon/layout\n$spacing-09: 3rem !default;\n\n/// @type Number\n/// @access public\n/// @group @carbon/layout\n$spacing-10: 4rem !default;\n\n/// @type Number\n/// @access public\n/// @group @carbon/layout\n$spacing-11: 5rem !default;\n\n/// @type Number\n/// @access public\n/// @group @carbon/layout\n$spacing-12: 6rem !default;\n\n/// @type Number\n/// @access public\n/// @group @carbon/layout\n$spacing-13: 10rem !default;\n\n/// @type Map\n/// @access public\n/// @group @carbon/layout\n$spacing: (\n  spacing-01: $spacing-01,\n  spacing-02: $spacing-02,\n  spacing-03: $spacing-03,\n  spacing-04: $spacing-04,\n  spacing-05: $spacing-05,\n  spacing-06: $spacing-06,\n  spacing-07: $spacing-07,\n  spacing-08: $spacing-08,\n  spacing-09: $spacing-09,\n  spacing-10: $spacing-10,\n  spacing-11: $spacing-11,\n  spacing-12: $spacing-12,\n  spacing-13: $spacing-13,\n);\n"],"sourceRoot":""}]);
// Exports
___CSS_LOADER_EXPORT___.locals = {
	"widgetCard": "-esm-patient-vitals__vitals-overview__widgetCard___ida5k",
	"divider": "-esm-patient-vitals__vitals-overview__divider___du+jm",
	"vitalsHeaderActionItems": "-esm-patient-vitals__vitals-overview__vitalsHeaderActionItems___OhE0b",
	"customRow": "-esm-patient-vitals__vitals-overview__customRow___LVqEW",
	"backgroundDataFetchingIndicator": "-esm-patient-vitals__vitals-overview__backgroundDataFetchingIndicator___AJ9fR",
	"printButton": "-esm-patient-vitals__vitals-overview__printButton___LwyUE",
	"stigmaChartContainer": "-esm-patient-vitals__vitals-overview__stigmaChartContainer___S8HQU",
	"stigmaChartButton": "-esm-patient-vitals__vitals-overview__stigmaChartButton___lMr1D",
	"clickableHeader": "-esm-patient-vitals__vitals-overview__clickableHeader___5ya8e",
	"clickableIcon": "-esm-patient-vitals__vitals-overview__clickableIcon___SI2td",
	"titleChartButton": "-esm-patient-vitals__vitals-overview__titleChartButton___FqZpD",
	"chartIcon": "-esm-patient-vitals__vitals-overview__chartIcon___BsCl8"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./src/biometrics/biometrics-base.scss":
/*!*********************************************!*\
  !*** ./src/biometrics/biometrics-base.scss ***!
  \*********************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_openmrs_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../../node_modules/openmrs/node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "../../node_modules/openmrs/node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_openmrs_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_openmrs_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_openmrs_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !../../../../node_modules/openmrs/node_modules/style-loader/dist/runtime/styleDomAPI.js */ "../../node_modules/openmrs/node_modules/style-loader/dist/runtime/styleDomAPI.js");
/* harmony import */ var _node_modules_openmrs_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_openmrs_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _node_modules_openmrs_node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../../node_modules/openmrs/node_modules/style-loader/dist/runtime/insertBySelector.js */ "../../node_modules/openmrs/node_modules/style-loader/dist/runtime/insertBySelector.js");
/* harmony import */ var _node_modules_openmrs_node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_node_modules_openmrs_node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _node_modules_openmrs_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../../../node_modules/openmrs/node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js */ "../../node_modules/openmrs/node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js");
/* harmony import */ var _node_modules_openmrs_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_node_modules_openmrs_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _node_modules_openmrs_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! !../../../../node_modules/openmrs/node_modules/style-loader/dist/runtime/insertStyleElement.js */ "../../node_modules/openmrs/node_modules/style-loader/dist/runtime/insertStyleElement.js");
/* harmony import */ var _node_modules_openmrs_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_node_modules_openmrs_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _node_modules_openmrs_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! !../../../../node_modules/openmrs/node_modules/style-loader/dist/runtime/styleTagTransform.js */ "../../node_modules/openmrs/node_modules/style-loader/dist/runtime/styleTagTransform.js");
/* harmony import */ var _node_modules_openmrs_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_node_modules_openmrs_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _node_modules_openmrs_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_2_use_1_node_modules_openmrs_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_2_use_2_biometrics_base_scss__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! !!../../../../node_modules/openmrs/node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[2].use[1]!../../../../node_modules/openmrs/node_modules/sass-loader/dist/cjs.js??ruleSet[1].rules[2].use[2]!./biometrics-base.scss */ "../../node_modules/openmrs/node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[2].use[1]!../../node_modules/openmrs/node_modules/sass-loader/dist/cjs.js??ruleSet[1].rules[2].use[2]!./src/biometrics/biometrics-base.scss");

      
      
      
      
      
      
      
      
      

var options = {};

options.styleTagTransform = (_node_modules_openmrs_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default());
options.setAttributes = (_node_modules_openmrs_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default());

      options.insert = _node_modules_openmrs_node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default().bind(null, "head");
    
options.domAPI = (_node_modules_openmrs_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default());
options.insertStyleElement = (_node_modules_openmrs_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default());

var update = _node_modules_openmrs_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_openmrs_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_2_use_1_node_modules_openmrs_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_2_use_2_biometrics_base_scss__WEBPACK_IMPORTED_MODULE_6__["default"], options);


if (true) {
  if (!_node_modules_openmrs_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_2_use_1_node_modules_openmrs_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_2_use_2_biometrics_base_scss__WEBPACK_IMPORTED_MODULE_6__["default"].locals || module.hot.invalidate) {
    var isEqualLocals = function isEqualLocals(a, b, isNamedExport) {
  if (!a && b || a && !b) {
    return false;
  }
  var p;
  for (p in a) {
    if (isNamedExport && p === "default") {
      // eslint-disable-next-line no-continue
      continue;
    }
    if (a[p] !== b[p]) {
      return false;
    }
  }
  for (p in b) {
    if (isNamedExport && p === "default") {
      // eslint-disable-next-line no-continue
      continue;
    }
    if (!a[p]) {
      return false;
    }
  }
  return true;
};
    var isNamedExport = !_node_modules_openmrs_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_2_use_1_node_modules_openmrs_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_2_use_2_biometrics_base_scss__WEBPACK_IMPORTED_MODULE_6__["default"].locals;
    var oldLocals = isNamedExport ? _node_modules_openmrs_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_2_use_1_node_modules_openmrs_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_2_use_2_biometrics_base_scss__WEBPACK_IMPORTED_MODULE_6__ : _node_modules_openmrs_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_2_use_1_node_modules_openmrs_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_2_use_2_biometrics_base_scss__WEBPACK_IMPORTED_MODULE_6__["default"].locals;

    module.hot.accept(
      /*! !!../../../../node_modules/openmrs/node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[2].use[1]!../../../../node_modules/openmrs/node_modules/sass-loader/dist/cjs.js??ruleSet[1].rules[2].use[2]!./biometrics-base.scss */ "../../node_modules/openmrs/node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[2].use[1]!../../node_modules/openmrs/node_modules/sass-loader/dist/cjs.js??ruleSet[1].rules[2].use[2]!./src/biometrics/biometrics-base.scss",
      __WEBPACK_OUTDATED_DEPENDENCIES__ => { /* harmony import */ _node_modules_openmrs_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_2_use_1_node_modules_openmrs_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_2_use_2_biometrics_base_scss__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! !!../../../../node_modules/openmrs/node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[2].use[1]!../../../../node_modules/openmrs/node_modules/sass-loader/dist/cjs.js??ruleSet[1].rules[2].use[2]!./biometrics-base.scss */ "../../node_modules/openmrs/node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[2].use[1]!../../node_modules/openmrs/node_modules/sass-loader/dist/cjs.js??ruleSet[1].rules[2].use[2]!./src/biometrics/biometrics-base.scss");
(function () {
        if (!isEqualLocals(oldLocals, isNamedExport ? _node_modules_openmrs_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_2_use_1_node_modules_openmrs_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_2_use_2_biometrics_base_scss__WEBPACK_IMPORTED_MODULE_6__ : _node_modules_openmrs_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_2_use_1_node_modules_openmrs_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_2_use_2_biometrics_base_scss__WEBPACK_IMPORTED_MODULE_6__["default"].locals, isNamedExport)) {
                module.hot.invalidate();

                return;
              }

              oldLocals = isNamedExport ? _node_modules_openmrs_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_2_use_1_node_modules_openmrs_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_2_use_2_biometrics_base_scss__WEBPACK_IMPORTED_MODULE_6__ : _node_modules_openmrs_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_2_use_1_node_modules_openmrs_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_2_use_2_biometrics_base_scss__WEBPACK_IMPORTED_MODULE_6__["default"].locals;

              update(_node_modules_openmrs_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_2_use_1_node_modules_openmrs_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_2_use_2_biometrics_base_scss__WEBPACK_IMPORTED_MODULE_6__["default"]);
      })(__WEBPACK_OUTDATED_DEPENDENCIES__); }
    )
  }

  module.hot.dispose(function() {
    update();
  });
}



       /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_openmrs_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_2_use_1_node_modules_openmrs_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_2_use_2_biometrics_base_scss__WEBPACK_IMPORTED_MODULE_6__["default"] && _node_modules_openmrs_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_2_use_1_node_modules_openmrs_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_2_use_2_biometrics_base_scss__WEBPACK_IMPORTED_MODULE_6__["default"].locals ? _node_modules_openmrs_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_2_use_1_node_modules_openmrs_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_2_use_2_biometrics_base_scss__WEBPACK_IMPORTED_MODULE_6__["default"].locals : undefined);


/***/ }),

/***/ "./src/components/action-menu/vitals-biometrics-action-menu.scss":
/*!***********************************************************************!*\
  !*** ./src/components/action-menu/vitals-biometrics-action-menu.scss ***!
  \***********************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_openmrs_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../../../node_modules/openmrs/node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "../../node_modules/openmrs/node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_openmrs_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_openmrs_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_openmrs_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !../../../../../node_modules/openmrs/node_modules/style-loader/dist/runtime/styleDomAPI.js */ "../../node_modules/openmrs/node_modules/style-loader/dist/runtime/styleDomAPI.js");
/* harmony import */ var _node_modules_openmrs_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_openmrs_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _node_modules_openmrs_node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../../../node_modules/openmrs/node_modules/style-loader/dist/runtime/insertBySelector.js */ "../../node_modules/openmrs/node_modules/style-loader/dist/runtime/insertBySelector.js");
/* harmony import */ var _node_modules_openmrs_node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_node_modules_openmrs_node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _node_modules_openmrs_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../../../../node_modules/openmrs/node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js */ "../../node_modules/openmrs/node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js");
/* harmony import */ var _node_modules_openmrs_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_node_modules_openmrs_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _node_modules_openmrs_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! !../../../../../node_modules/openmrs/node_modules/style-loader/dist/runtime/insertStyleElement.js */ "../../node_modules/openmrs/node_modules/style-loader/dist/runtime/insertStyleElement.js");
/* harmony import */ var _node_modules_openmrs_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_node_modules_openmrs_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _node_modules_openmrs_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! !../../../../../node_modules/openmrs/node_modules/style-loader/dist/runtime/styleTagTransform.js */ "../../node_modules/openmrs/node_modules/style-loader/dist/runtime/styleTagTransform.js");
/* harmony import */ var _node_modules_openmrs_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_node_modules_openmrs_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _node_modules_openmrs_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_2_use_1_node_modules_openmrs_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_2_use_2_vitals_biometrics_action_menu_scss__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! !!../../../../../node_modules/openmrs/node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[2].use[1]!../../../../../node_modules/openmrs/node_modules/sass-loader/dist/cjs.js??ruleSet[1].rules[2].use[2]!./vitals-biometrics-action-menu.scss */ "../../node_modules/openmrs/node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[2].use[1]!../../node_modules/openmrs/node_modules/sass-loader/dist/cjs.js??ruleSet[1].rules[2].use[2]!./src/components/action-menu/vitals-biometrics-action-menu.scss");

      
      
      
      
      
      
      
      
      

var options = {};

options.styleTagTransform = (_node_modules_openmrs_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default());
options.setAttributes = (_node_modules_openmrs_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default());

      options.insert = _node_modules_openmrs_node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default().bind(null, "head");
    
options.domAPI = (_node_modules_openmrs_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default());
options.insertStyleElement = (_node_modules_openmrs_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default());

var update = _node_modules_openmrs_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_openmrs_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_2_use_1_node_modules_openmrs_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_2_use_2_vitals_biometrics_action_menu_scss__WEBPACK_IMPORTED_MODULE_6__["default"], options);


if (true) {
  if (!_node_modules_openmrs_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_2_use_1_node_modules_openmrs_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_2_use_2_vitals_biometrics_action_menu_scss__WEBPACK_IMPORTED_MODULE_6__["default"].locals || module.hot.invalidate) {
    var isEqualLocals = function isEqualLocals(a, b, isNamedExport) {
  if (!a && b || a && !b) {
    return false;
  }
  var p;
  for (p in a) {
    if (isNamedExport && p === "default") {
      // eslint-disable-next-line no-continue
      continue;
    }
    if (a[p] !== b[p]) {
      return false;
    }
  }
  for (p in b) {
    if (isNamedExport && p === "default") {
      // eslint-disable-next-line no-continue
      continue;
    }
    if (!a[p]) {
      return false;
    }
  }
  return true;
};
    var isNamedExport = !_node_modules_openmrs_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_2_use_1_node_modules_openmrs_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_2_use_2_vitals_biometrics_action_menu_scss__WEBPACK_IMPORTED_MODULE_6__["default"].locals;
    var oldLocals = isNamedExport ? _node_modules_openmrs_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_2_use_1_node_modules_openmrs_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_2_use_2_vitals_biometrics_action_menu_scss__WEBPACK_IMPORTED_MODULE_6__ : _node_modules_openmrs_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_2_use_1_node_modules_openmrs_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_2_use_2_vitals_biometrics_action_menu_scss__WEBPACK_IMPORTED_MODULE_6__["default"].locals;

    module.hot.accept(
      /*! !!../../../../../node_modules/openmrs/node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[2].use[1]!../../../../../node_modules/openmrs/node_modules/sass-loader/dist/cjs.js??ruleSet[1].rules[2].use[2]!./vitals-biometrics-action-menu.scss */ "../../node_modules/openmrs/node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[2].use[1]!../../node_modules/openmrs/node_modules/sass-loader/dist/cjs.js??ruleSet[1].rules[2].use[2]!./src/components/action-menu/vitals-biometrics-action-menu.scss",
      __WEBPACK_OUTDATED_DEPENDENCIES__ => { /* harmony import */ _node_modules_openmrs_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_2_use_1_node_modules_openmrs_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_2_use_2_vitals_biometrics_action_menu_scss__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! !!../../../../../node_modules/openmrs/node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[2].use[1]!../../../../../node_modules/openmrs/node_modules/sass-loader/dist/cjs.js??ruleSet[1].rules[2].use[2]!./vitals-biometrics-action-menu.scss */ "../../node_modules/openmrs/node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[2].use[1]!../../node_modules/openmrs/node_modules/sass-loader/dist/cjs.js??ruleSet[1].rules[2].use[2]!./src/components/action-menu/vitals-biometrics-action-menu.scss");
(function () {
        if (!isEqualLocals(oldLocals, isNamedExport ? _node_modules_openmrs_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_2_use_1_node_modules_openmrs_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_2_use_2_vitals_biometrics_action_menu_scss__WEBPACK_IMPORTED_MODULE_6__ : _node_modules_openmrs_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_2_use_1_node_modules_openmrs_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_2_use_2_vitals_biometrics_action_menu_scss__WEBPACK_IMPORTED_MODULE_6__["default"].locals, isNamedExport)) {
                module.hot.invalidate();

                return;
              }

              oldLocals = isNamedExport ? _node_modules_openmrs_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_2_use_1_node_modules_openmrs_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_2_use_2_vitals_biometrics_action_menu_scss__WEBPACK_IMPORTED_MODULE_6__ : _node_modules_openmrs_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_2_use_1_node_modules_openmrs_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_2_use_2_vitals_biometrics_action_menu_scss__WEBPACK_IMPORTED_MODULE_6__["default"].locals;

              update(_node_modules_openmrs_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_2_use_1_node_modules_openmrs_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_2_use_2_vitals_biometrics_action_menu_scss__WEBPACK_IMPORTED_MODULE_6__["default"]);
      })(__WEBPACK_OUTDATED_DEPENDENCIES__); }
    )
  }

  module.hot.dispose(function() {
    update();
  });
}



       /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_openmrs_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_2_use_1_node_modules_openmrs_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_2_use_2_vitals_biometrics_action_menu_scss__WEBPACK_IMPORTED_MODULE_6__["default"] && _node_modules_openmrs_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_2_use_1_node_modules_openmrs_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_2_use_2_vitals_biometrics_action_menu_scss__WEBPACK_IMPORTED_MODULE_6__["default"].locals ? _node_modules_openmrs_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_2_use_1_node_modules_openmrs_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_2_use_2_vitals_biometrics_action_menu_scss__WEBPACK_IMPORTED_MODULE_6__["default"].locals : undefined);


/***/ }),

/***/ "./src/vitals-and-biometrics-header/vitals-header-item.scss":
/*!******************************************************************!*\
  !*** ./src/vitals-and-biometrics-header/vitals-header-item.scss ***!
  \******************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_openmrs_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../../node_modules/openmrs/node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "../../node_modules/openmrs/node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_openmrs_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_openmrs_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_openmrs_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !../../../../node_modules/openmrs/node_modules/style-loader/dist/runtime/styleDomAPI.js */ "../../node_modules/openmrs/node_modules/style-loader/dist/runtime/styleDomAPI.js");
/* harmony import */ var _node_modules_openmrs_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_openmrs_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _node_modules_openmrs_node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../../node_modules/openmrs/node_modules/style-loader/dist/runtime/insertBySelector.js */ "../../node_modules/openmrs/node_modules/style-loader/dist/runtime/insertBySelector.js");
/* harmony import */ var _node_modules_openmrs_node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_node_modules_openmrs_node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _node_modules_openmrs_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../../../node_modules/openmrs/node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js */ "../../node_modules/openmrs/node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js");
/* harmony import */ var _node_modules_openmrs_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_node_modules_openmrs_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _node_modules_openmrs_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! !../../../../node_modules/openmrs/node_modules/style-loader/dist/runtime/insertStyleElement.js */ "../../node_modules/openmrs/node_modules/style-loader/dist/runtime/insertStyleElement.js");
/* harmony import */ var _node_modules_openmrs_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_node_modules_openmrs_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _node_modules_openmrs_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! !../../../../node_modules/openmrs/node_modules/style-loader/dist/runtime/styleTagTransform.js */ "../../node_modules/openmrs/node_modules/style-loader/dist/runtime/styleTagTransform.js");
/* harmony import */ var _node_modules_openmrs_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_node_modules_openmrs_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _node_modules_openmrs_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_2_use_1_node_modules_openmrs_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_2_use_2_vitals_header_item_scss__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! !!../../../../node_modules/openmrs/node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[2].use[1]!../../../../node_modules/openmrs/node_modules/sass-loader/dist/cjs.js??ruleSet[1].rules[2].use[2]!./vitals-header-item.scss */ "../../node_modules/openmrs/node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[2].use[1]!../../node_modules/openmrs/node_modules/sass-loader/dist/cjs.js??ruleSet[1].rules[2].use[2]!./src/vitals-and-biometrics-header/vitals-header-item.scss");

      
      
      
      
      
      
      
      
      

var options = {};

options.styleTagTransform = (_node_modules_openmrs_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default());
options.setAttributes = (_node_modules_openmrs_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default());

      options.insert = _node_modules_openmrs_node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default().bind(null, "head");
    
options.domAPI = (_node_modules_openmrs_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default());
options.insertStyleElement = (_node_modules_openmrs_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default());

var update = _node_modules_openmrs_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_openmrs_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_2_use_1_node_modules_openmrs_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_2_use_2_vitals_header_item_scss__WEBPACK_IMPORTED_MODULE_6__["default"], options);


if (true) {
  if (!_node_modules_openmrs_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_2_use_1_node_modules_openmrs_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_2_use_2_vitals_header_item_scss__WEBPACK_IMPORTED_MODULE_6__["default"].locals || module.hot.invalidate) {
    var isEqualLocals = function isEqualLocals(a, b, isNamedExport) {
  if (!a && b || a && !b) {
    return false;
  }
  var p;
  for (p in a) {
    if (isNamedExport && p === "default") {
      // eslint-disable-next-line no-continue
      continue;
    }
    if (a[p] !== b[p]) {
      return false;
    }
  }
  for (p in b) {
    if (isNamedExport && p === "default") {
      // eslint-disable-next-line no-continue
      continue;
    }
    if (!a[p]) {
      return false;
    }
  }
  return true;
};
    var isNamedExport = !_node_modules_openmrs_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_2_use_1_node_modules_openmrs_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_2_use_2_vitals_header_item_scss__WEBPACK_IMPORTED_MODULE_6__["default"].locals;
    var oldLocals = isNamedExport ? _node_modules_openmrs_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_2_use_1_node_modules_openmrs_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_2_use_2_vitals_header_item_scss__WEBPACK_IMPORTED_MODULE_6__ : _node_modules_openmrs_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_2_use_1_node_modules_openmrs_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_2_use_2_vitals_header_item_scss__WEBPACK_IMPORTED_MODULE_6__["default"].locals;

    module.hot.accept(
      /*! !!../../../../node_modules/openmrs/node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[2].use[1]!../../../../node_modules/openmrs/node_modules/sass-loader/dist/cjs.js??ruleSet[1].rules[2].use[2]!./vitals-header-item.scss */ "../../node_modules/openmrs/node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[2].use[1]!../../node_modules/openmrs/node_modules/sass-loader/dist/cjs.js??ruleSet[1].rules[2].use[2]!./src/vitals-and-biometrics-header/vitals-header-item.scss",
      __WEBPACK_OUTDATED_DEPENDENCIES__ => { /* harmony import */ _node_modules_openmrs_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_2_use_1_node_modules_openmrs_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_2_use_2_vitals_header_item_scss__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! !!../../../../node_modules/openmrs/node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[2].use[1]!../../../../node_modules/openmrs/node_modules/sass-loader/dist/cjs.js??ruleSet[1].rules[2].use[2]!./vitals-header-item.scss */ "../../node_modules/openmrs/node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[2].use[1]!../../node_modules/openmrs/node_modules/sass-loader/dist/cjs.js??ruleSet[1].rules[2].use[2]!./src/vitals-and-biometrics-header/vitals-header-item.scss");
(function () {
        if (!isEqualLocals(oldLocals, isNamedExport ? _node_modules_openmrs_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_2_use_1_node_modules_openmrs_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_2_use_2_vitals_header_item_scss__WEBPACK_IMPORTED_MODULE_6__ : _node_modules_openmrs_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_2_use_1_node_modules_openmrs_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_2_use_2_vitals_header_item_scss__WEBPACK_IMPORTED_MODULE_6__["default"].locals, isNamedExport)) {
                module.hot.invalidate();

                return;
              }

              oldLocals = isNamedExport ? _node_modules_openmrs_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_2_use_1_node_modules_openmrs_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_2_use_2_vitals_header_item_scss__WEBPACK_IMPORTED_MODULE_6__ : _node_modules_openmrs_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_2_use_1_node_modules_openmrs_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_2_use_2_vitals_header_item_scss__WEBPACK_IMPORTED_MODULE_6__["default"].locals;

              update(_node_modules_openmrs_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_2_use_1_node_modules_openmrs_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_2_use_2_vitals_header_item_scss__WEBPACK_IMPORTED_MODULE_6__["default"]);
      })(__WEBPACK_OUTDATED_DEPENDENCIES__); }
    )
  }

  module.hot.dispose(function() {
    update();
  });
}



       /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_openmrs_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_2_use_1_node_modules_openmrs_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_2_use_2_vitals_header_item_scss__WEBPACK_IMPORTED_MODULE_6__["default"] && _node_modules_openmrs_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_2_use_1_node_modules_openmrs_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_2_use_2_vitals_header_item_scss__WEBPACK_IMPORTED_MODULE_6__["default"].locals ? _node_modules_openmrs_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_2_use_1_node_modules_openmrs_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_2_use_2_vitals_header_item_scss__WEBPACK_IMPORTED_MODULE_6__["default"].locals : undefined);


/***/ }),

/***/ "./src/vitals-and-biometrics-header/vitals-header.scss":
/*!*************************************************************!*\
  !*** ./src/vitals-and-biometrics-header/vitals-header.scss ***!
  \*************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_openmrs_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../../node_modules/openmrs/node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "../../node_modules/openmrs/node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_openmrs_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_openmrs_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_openmrs_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !../../../../node_modules/openmrs/node_modules/style-loader/dist/runtime/styleDomAPI.js */ "../../node_modules/openmrs/node_modules/style-loader/dist/runtime/styleDomAPI.js");
/* harmony import */ var _node_modules_openmrs_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_openmrs_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _node_modules_openmrs_node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../../node_modules/openmrs/node_modules/style-loader/dist/runtime/insertBySelector.js */ "../../node_modules/openmrs/node_modules/style-loader/dist/runtime/insertBySelector.js");
/* harmony import */ var _node_modules_openmrs_node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_node_modules_openmrs_node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _node_modules_openmrs_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../../../node_modules/openmrs/node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js */ "../../node_modules/openmrs/node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js");
/* harmony import */ var _node_modules_openmrs_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_node_modules_openmrs_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _node_modules_openmrs_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! !../../../../node_modules/openmrs/node_modules/style-loader/dist/runtime/insertStyleElement.js */ "../../node_modules/openmrs/node_modules/style-loader/dist/runtime/insertStyleElement.js");
/* harmony import */ var _node_modules_openmrs_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_node_modules_openmrs_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _node_modules_openmrs_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! !../../../../node_modules/openmrs/node_modules/style-loader/dist/runtime/styleTagTransform.js */ "../../node_modules/openmrs/node_modules/style-loader/dist/runtime/styleTagTransform.js");
/* harmony import */ var _node_modules_openmrs_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_node_modules_openmrs_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _node_modules_openmrs_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_2_use_1_node_modules_openmrs_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_2_use_2_vitals_header_scss__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! !!../../../../node_modules/openmrs/node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[2].use[1]!../../../../node_modules/openmrs/node_modules/sass-loader/dist/cjs.js??ruleSet[1].rules[2].use[2]!./vitals-header.scss */ "../../node_modules/openmrs/node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[2].use[1]!../../node_modules/openmrs/node_modules/sass-loader/dist/cjs.js??ruleSet[1].rules[2].use[2]!./src/vitals-and-biometrics-header/vitals-header.scss");

      
      
      
      
      
      
      
      
      

var options = {};

options.styleTagTransform = (_node_modules_openmrs_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default());
options.setAttributes = (_node_modules_openmrs_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default());

      options.insert = _node_modules_openmrs_node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default().bind(null, "head");
    
options.domAPI = (_node_modules_openmrs_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default());
options.insertStyleElement = (_node_modules_openmrs_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default());

var update = _node_modules_openmrs_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_openmrs_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_2_use_1_node_modules_openmrs_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_2_use_2_vitals_header_scss__WEBPACK_IMPORTED_MODULE_6__["default"], options);


if (true) {
  if (!_node_modules_openmrs_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_2_use_1_node_modules_openmrs_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_2_use_2_vitals_header_scss__WEBPACK_IMPORTED_MODULE_6__["default"].locals || module.hot.invalidate) {
    var isEqualLocals = function isEqualLocals(a, b, isNamedExport) {
  if (!a && b || a && !b) {
    return false;
  }
  var p;
  for (p in a) {
    if (isNamedExport && p === "default") {
      // eslint-disable-next-line no-continue
      continue;
    }
    if (a[p] !== b[p]) {
      return false;
    }
  }
  for (p in b) {
    if (isNamedExport && p === "default") {
      // eslint-disable-next-line no-continue
      continue;
    }
    if (!a[p]) {
      return false;
    }
  }
  return true;
};
    var isNamedExport = !_node_modules_openmrs_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_2_use_1_node_modules_openmrs_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_2_use_2_vitals_header_scss__WEBPACK_IMPORTED_MODULE_6__["default"].locals;
    var oldLocals = isNamedExport ? _node_modules_openmrs_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_2_use_1_node_modules_openmrs_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_2_use_2_vitals_header_scss__WEBPACK_IMPORTED_MODULE_6__ : _node_modules_openmrs_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_2_use_1_node_modules_openmrs_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_2_use_2_vitals_header_scss__WEBPACK_IMPORTED_MODULE_6__["default"].locals;

    module.hot.accept(
      /*! !!../../../../node_modules/openmrs/node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[2].use[1]!../../../../node_modules/openmrs/node_modules/sass-loader/dist/cjs.js??ruleSet[1].rules[2].use[2]!./vitals-header.scss */ "../../node_modules/openmrs/node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[2].use[1]!../../node_modules/openmrs/node_modules/sass-loader/dist/cjs.js??ruleSet[1].rules[2].use[2]!./src/vitals-and-biometrics-header/vitals-header.scss",
      __WEBPACK_OUTDATED_DEPENDENCIES__ => { /* harmony import */ _node_modules_openmrs_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_2_use_1_node_modules_openmrs_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_2_use_2_vitals_header_scss__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! !!../../../../node_modules/openmrs/node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[2].use[1]!../../../../node_modules/openmrs/node_modules/sass-loader/dist/cjs.js??ruleSet[1].rules[2].use[2]!./vitals-header.scss */ "../../node_modules/openmrs/node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[2].use[1]!../../node_modules/openmrs/node_modules/sass-loader/dist/cjs.js??ruleSet[1].rules[2].use[2]!./src/vitals-and-biometrics-header/vitals-header.scss");
(function () {
        if (!isEqualLocals(oldLocals, isNamedExport ? _node_modules_openmrs_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_2_use_1_node_modules_openmrs_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_2_use_2_vitals_header_scss__WEBPACK_IMPORTED_MODULE_6__ : _node_modules_openmrs_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_2_use_1_node_modules_openmrs_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_2_use_2_vitals_header_scss__WEBPACK_IMPORTED_MODULE_6__["default"].locals, isNamedExport)) {
                module.hot.invalidate();

                return;
              }

              oldLocals = isNamedExport ? _node_modules_openmrs_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_2_use_1_node_modules_openmrs_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_2_use_2_vitals_header_scss__WEBPACK_IMPORTED_MODULE_6__ : _node_modules_openmrs_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_2_use_1_node_modules_openmrs_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_2_use_2_vitals_header_scss__WEBPACK_IMPORTED_MODULE_6__["default"].locals;

              update(_node_modules_openmrs_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_2_use_1_node_modules_openmrs_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_2_use_2_vitals_header_scss__WEBPACK_IMPORTED_MODULE_6__["default"]);
      })(__WEBPACK_OUTDATED_DEPENDENCIES__); }
    )
  }

  module.hot.dispose(function() {
    update();
  });
}



       /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_openmrs_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_2_use_1_node_modules_openmrs_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_2_use_2_vitals_header_scss__WEBPACK_IMPORTED_MODULE_6__["default"] && _node_modules_openmrs_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_2_use_1_node_modules_openmrs_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_2_use_2_vitals_header_scss__WEBPACK_IMPORTED_MODULE_6__["default"].locals ? _node_modules_openmrs_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_2_use_1_node_modules_openmrs_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_2_use_2_vitals_header_scss__WEBPACK_IMPORTED_MODULE_6__["default"].locals : undefined);


/***/ }),

/***/ "./src/vitals/paginated-vitals.scss":
/*!******************************************!*\
  !*** ./src/vitals/paginated-vitals.scss ***!
  \******************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_openmrs_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../../node_modules/openmrs/node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "../../node_modules/openmrs/node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_openmrs_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_openmrs_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_openmrs_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !../../../../node_modules/openmrs/node_modules/style-loader/dist/runtime/styleDomAPI.js */ "../../node_modules/openmrs/node_modules/style-loader/dist/runtime/styleDomAPI.js");
/* harmony import */ var _node_modules_openmrs_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_openmrs_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _node_modules_openmrs_node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../../node_modules/openmrs/node_modules/style-loader/dist/runtime/insertBySelector.js */ "../../node_modules/openmrs/node_modules/style-loader/dist/runtime/insertBySelector.js");
/* harmony import */ var _node_modules_openmrs_node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_node_modules_openmrs_node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _node_modules_openmrs_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../../../node_modules/openmrs/node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js */ "../../node_modules/openmrs/node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js");
/* harmony import */ var _node_modules_openmrs_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_node_modules_openmrs_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _node_modules_openmrs_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! !../../../../node_modules/openmrs/node_modules/style-loader/dist/runtime/insertStyleElement.js */ "../../node_modules/openmrs/node_modules/style-loader/dist/runtime/insertStyleElement.js");
/* harmony import */ var _node_modules_openmrs_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_node_modules_openmrs_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _node_modules_openmrs_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! !../../../../node_modules/openmrs/node_modules/style-loader/dist/runtime/styleTagTransform.js */ "../../node_modules/openmrs/node_modules/style-loader/dist/runtime/styleTagTransform.js");
/* harmony import */ var _node_modules_openmrs_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_node_modules_openmrs_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _node_modules_openmrs_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_2_use_1_node_modules_openmrs_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_2_use_2_paginated_vitals_scss__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! !!../../../../node_modules/openmrs/node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[2].use[1]!../../../../node_modules/openmrs/node_modules/sass-loader/dist/cjs.js??ruleSet[1].rules[2].use[2]!./paginated-vitals.scss */ "../../node_modules/openmrs/node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[2].use[1]!../../node_modules/openmrs/node_modules/sass-loader/dist/cjs.js??ruleSet[1].rules[2].use[2]!./src/vitals/paginated-vitals.scss");

      
      
      
      
      
      
      
      
      

var options = {};

options.styleTagTransform = (_node_modules_openmrs_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default());
options.setAttributes = (_node_modules_openmrs_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default());

      options.insert = _node_modules_openmrs_node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default().bind(null, "head");
    
options.domAPI = (_node_modules_openmrs_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default());
options.insertStyleElement = (_node_modules_openmrs_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default());

var update = _node_modules_openmrs_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_openmrs_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_2_use_1_node_modules_openmrs_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_2_use_2_paginated_vitals_scss__WEBPACK_IMPORTED_MODULE_6__["default"], options);


if (true) {
  if (!_node_modules_openmrs_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_2_use_1_node_modules_openmrs_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_2_use_2_paginated_vitals_scss__WEBPACK_IMPORTED_MODULE_6__["default"].locals || module.hot.invalidate) {
    var isEqualLocals = function isEqualLocals(a, b, isNamedExport) {
  if (!a && b || a && !b) {
    return false;
  }
  var p;
  for (p in a) {
    if (isNamedExport && p === "default") {
      // eslint-disable-next-line no-continue
      continue;
    }
    if (a[p] !== b[p]) {
      return false;
    }
  }
  for (p in b) {
    if (isNamedExport && p === "default") {
      // eslint-disable-next-line no-continue
      continue;
    }
    if (!a[p]) {
      return false;
    }
  }
  return true;
};
    var isNamedExport = !_node_modules_openmrs_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_2_use_1_node_modules_openmrs_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_2_use_2_paginated_vitals_scss__WEBPACK_IMPORTED_MODULE_6__["default"].locals;
    var oldLocals = isNamedExport ? _node_modules_openmrs_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_2_use_1_node_modules_openmrs_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_2_use_2_paginated_vitals_scss__WEBPACK_IMPORTED_MODULE_6__ : _node_modules_openmrs_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_2_use_1_node_modules_openmrs_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_2_use_2_paginated_vitals_scss__WEBPACK_IMPORTED_MODULE_6__["default"].locals;

    module.hot.accept(
      /*! !!../../../../node_modules/openmrs/node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[2].use[1]!../../../../node_modules/openmrs/node_modules/sass-loader/dist/cjs.js??ruleSet[1].rules[2].use[2]!./paginated-vitals.scss */ "../../node_modules/openmrs/node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[2].use[1]!../../node_modules/openmrs/node_modules/sass-loader/dist/cjs.js??ruleSet[1].rules[2].use[2]!./src/vitals/paginated-vitals.scss",
      __WEBPACK_OUTDATED_DEPENDENCIES__ => { /* harmony import */ _node_modules_openmrs_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_2_use_1_node_modules_openmrs_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_2_use_2_paginated_vitals_scss__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! !!../../../../node_modules/openmrs/node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[2].use[1]!../../../../node_modules/openmrs/node_modules/sass-loader/dist/cjs.js??ruleSet[1].rules[2].use[2]!./paginated-vitals.scss */ "../../node_modules/openmrs/node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[2].use[1]!../../node_modules/openmrs/node_modules/sass-loader/dist/cjs.js??ruleSet[1].rules[2].use[2]!./src/vitals/paginated-vitals.scss");
(function () {
        if (!isEqualLocals(oldLocals, isNamedExport ? _node_modules_openmrs_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_2_use_1_node_modules_openmrs_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_2_use_2_paginated_vitals_scss__WEBPACK_IMPORTED_MODULE_6__ : _node_modules_openmrs_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_2_use_1_node_modules_openmrs_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_2_use_2_paginated_vitals_scss__WEBPACK_IMPORTED_MODULE_6__["default"].locals, isNamedExport)) {
                module.hot.invalidate();

                return;
              }

              oldLocals = isNamedExport ? _node_modules_openmrs_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_2_use_1_node_modules_openmrs_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_2_use_2_paginated_vitals_scss__WEBPACK_IMPORTED_MODULE_6__ : _node_modules_openmrs_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_2_use_1_node_modules_openmrs_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_2_use_2_paginated_vitals_scss__WEBPACK_IMPORTED_MODULE_6__["default"].locals;

              update(_node_modules_openmrs_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_2_use_1_node_modules_openmrs_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_2_use_2_paginated_vitals_scss__WEBPACK_IMPORTED_MODULE_6__["default"]);
      })(__WEBPACK_OUTDATED_DEPENDENCIES__); }
    )
  }

  module.hot.dispose(function() {
    update();
  });
}



       /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_openmrs_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_2_use_1_node_modules_openmrs_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_2_use_2_paginated_vitals_scss__WEBPACK_IMPORTED_MODULE_6__["default"] && _node_modules_openmrs_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_2_use_1_node_modules_openmrs_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_2_use_2_paginated_vitals_scss__WEBPACK_IMPORTED_MODULE_6__["default"].locals ? _node_modules_openmrs_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_2_use_1_node_modules_openmrs_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_2_use_2_paginated_vitals_scss__WEBPACK_IMPORTED_MODULE_6__["default"].locals : undefined);


/***/ }),

/***/ "./src/vitals/print/print.scss":
/*!*************************************!*\
  !*** ./src/vitals/print/print.scss ***!
  \*************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_openmrs_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../../../node_modules/openmrs/node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "../../node_modules/openmrs/node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_openmrs_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_openmrs_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_openmrs_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !../../../../../node_modules/openmrs/node_modules/style-loader/dist/runtime/styleDomAPI.js */ "../../node_modules/openmrs/node_modules/style-loader/dist/runtime/styleDomAPI.js");
/* harmony import */ var _node_modules_openmrs_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_openmrs_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _node_modules_openmrs_node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../../../node_modules/openmrs/node_modules/style-loader/dist/runtime/insertBySelector.js */ "../../node_modules/openmrs/node_modules/style-loader/dist/runtime/insertBySelector.js");
/* harmony import */ var _node_modules_openmrs_node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_node_modules_openmrs_node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _node_modules_openmrs_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../../../../node_modules/openmrs/node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js */ "../../node_modules/openmrs/node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js");
/* harmony import */ var _node_modules_openmrs_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_node_modules_openmrs_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _node_modules_openmrs_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! !../../../../../node_modules/openmrs/node_modules/style-loader/dist/runtime/insertStyleElement.js */ "../../node_modules/openmrs/node_modules/style-loader/dist/runtime/insertStyleElement.js");
/* harmony import */ var _node_modules_openmrs_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_node_modules_openmrs_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _node_modules_openmrs_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! !../../../../../node_modules/openmrs/node_modules/style-loader/dist/runtime/styleTagTransform.js */ "../../node_modules/openmrs/node_modules/style-loader/dist/runtime/styleTagTransform.js");
/* harmony import */ var _node_modules_openmrs_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_node_modules_openmrs_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _node_modules_openmrs_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_2_use_1_node_modules_openmrs_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_2_use_2_print_scss__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! !!../../../../../node_modules/openmrs/node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[2].use[1]!../../../../../node_modules/openmrs/node_modules/sass-loader/dist/cjs.js??ruleSet[1].rules[2].use[2]!./print.scss */ "../../node_modules/openmrs/node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[2].use[1]!../../node_modules/openmrs/node_modules/sass-loader/dist/cjs.js??ruleSet[1].rules[2].use[2]!./src/vitals/print/print.scss");

      
      
      
      
      
      
      
      
      

var options = {};

options.styleTagTransform = (_node_modules_openmrs_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default());
options.setAttributes = (_node_modules_openmrs_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default());

      options.insert = _node_modules_openmrs_node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default().bind(null, "head");
    
options.domAPI = (_node_modules_openmrs_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default());
options.insertStyleElement = (_node_modules_openmrs_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default());

var update = _node_modules_openmrs_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_openmrs_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_2_use_1_node_modules_openmrs_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_2_use_2_print_scss__WEBPACK_IMPORTED_MODULE_6__["default"], options);


if (true) {
  if (!_node_modules_openmrs_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_2_use_1_node_modules_openmrs_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_2_use_2_print_scss__WEBPACK_IMPORTED_MODULE_6__["default"].locals || module.hot.invalidate) {
    var isEqualLocals = function isEqualLocals(a, b, isNamedExport) {
  if (!a && b || a && !b) {
    return false;
  }
  var p;
  for (p in a) {
    if (isNamedExport && p === "default") {
      // eslint-disable-next-line no-continue
      continue;
    }
    if (a[p] !== b[p]) {
      return false;
    }
  }
  for (p in b) {
    if (isNamedExport && p === "default") {
      // eslint-disable-next-line no-continue
      continue;
    }
    if (!a[p]) {
      return false;
    }
  }
  return true;
};
    var isNamedExport = !_node_modules_openmrs_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_2_use_1_node_modules_openmrs_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_2_use_2_print_scss__WEBPACK_IMPORTED_MODULE_6__["default"].locals;
    var oldLocals = isNamedExport ? _node_modules_openmrs_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_2_use_1_node_modules_openmrs_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_2_use_2_print_scss__WEBPACK_IMPORTED_MODULE_6__ : _node_modules_openmrs_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_2_use_1_node_modules_openmrs_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_2_use_2_print_scss__WEBPACK_IMPORTED_MODULE_6__["default"].locals;

    module.hot.accept(
      /*! !!../../../../../node_modules/openmrs/node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[2].use[1]!../../../../../node_modules/openmrs/node_modules/sass-loader/dist/cjs.js??ruleSet[1].rules[2].use[2]!./print.scss */ "../../node_modules/openmrs/node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[2].use[1]!../../node_modules/openmrs/node_modules/sass-loader/dist/cjs.js??ruleSet[1].rules[2].use[2]!./src/vitals/print/print.scss",
      __WEBPACK_OUTDATED_DEPENDENCIES__ => { /* harmony import */ _node_modules_openmrs_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_2_use_1_node_modules_openmrs_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_2_use_2_print_scss__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! !!../../../../../node_modules/openmrs/node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[2].use[1]!../../../../../node_modules/openmrs/node_modules/sass-loader/dist/cjs.js??ruleSet[1].rules[2].use[2]!./print.scss */ "../../node_modules/openmrs/node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[2].use[1]!../../node_modules/openmrs/node_modules/sass-loader/dist/cjs.js??ruleSet[1].rules[2].use[2]!./src/vitals/print/print.scss");
(function () {
        if (!isEqualLocals(oldLocals, isNamedExport ? _node_modules_openmrs_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_2_use_1_node_modules_openmrs_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_2_use_2_print_scss__WEBPACK_IMPORTED_MODULE_6__ : _node_modules_openmrs_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_2_use_1_node_modules_openmrs_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_2_use_2_print_scss__WEBPACK_IMPORTED_MODULE_6__["default"].locals, isNamedExport)) {
                module.hot.invalidate();

                return;
              }

              oldLocals = isNamedExport ? _node_modules_openmrs_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_2_use_1_node_modules_openmrs_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_2_use_2_print_scss__WEBPACK_IMPORTED_MODULE_6__ : _node_modules_openmrs_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_2_use_1_node_modules_openmrs_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_2_use_2_print_scss__WEBPACK_IMPORTED_MODULE_6__["default"].locals;

              update(_node_modules_openmrs_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_2_use_1_node_modules_openmrs_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_2_use_2_print_scss__WEBPACK_IMPORTED_MODULE_6__["default"]);
      })(__WEBPACK_OUTDATED_DEPENDENCIES__); }
    )
  }

  module.hot.dispose(function() {
    update();
  });
}



       /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_openmrs_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_2_use_1_node_modules_openmrs_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_2_use_2_print_scss__WEBPACK_IMPORTED_MODULE_6__["default"] && _node_modules_openmrs_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_2_use_1_node_modules_openmrs_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_2_use_2_print_scss__WEBPACK_IMPORTED_MODULE_6__["default"].locals ? _node_modules_openmrs_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_2_use_1_node_modules_openmrs_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_2_use_2_print_scss__WEBPACK_IMPORTED_MODULE_6__["default"].locals : undefined);


/***/ }),

/***/ "./src/vitals/vitals-chart.scss":
/*!**************************************!*\
  !*** ./src/vitals/vitals-chart.scss ***!
  \**************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_openmrs_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../../node_modules/openmrs/node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "../../node_modules/openmrs/node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_openmrs_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_openmrs_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_openmrs_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !../../../../node_modules/openmrs/node_modules/style-loader/dist/runtime/styleDomAPI.js */ "../../node_modules/openmrs/node_modules/style-loader/dist/runtime/styleDomAPI.js");
/* harmony import */ var _node_modules_openmrs_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_openmrs_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _node_modules_openmrs_node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../../node_modules/openmrs/node_modules/style-loader/dist/runtime/insertBySelector.js */ "../../node_modules/openmrs/node_modules/style-loader/dist/runtime/insertBySelector.js");
/* harmony import */ var _node_modules_openmrs_node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_node_modules_openmrs_node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _node_modules_openmrs_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../../../node_modules/openmrs/node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js */ "../../node_modules/openmrs/node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js");
/* harmony import */ var _node_modules_openmrs_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_node_modules_openmrs_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _node_modules_openmrs_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! !../../../../node_modules/openmrs/node_modules/style-loader/dist/runtime/insertStyleElement.js */ "../../node_modules/openmrs/node_modules/style-loader/dist/runtime/insertStyleElement.js");
/* harmony import */ var _node_modules_openmrs_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_node_modules_openmrs_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _node_modules_openmrs_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! !../../../../node_modules/openmrs/node_modules/style-loader/dist/runtime/styleTagTransform.js */ "../../node_modules/openmrs/node_modules/style-loader/dist/runtime/styleTagTransform.js");
/* harmony import */ var _node_modules_openmrs_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_node_modules_openmrs_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _node_modules_openmrs_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_2_use_1_node_modules_openmrs_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_2_use_2_vitals_chart_scss__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! !!../../../../node_modules/openmrs/node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[2].use[1]!../../../../node_modules/openmrs/node_modules/sass-loader/dist/cjs.js??ruleSet[1].rules[2].use[2]!./vitals-chart.scss */ "../../node_modules/openmrs/node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[2].use[1]!../../node_modules/openmrs/node_modules/sass-loader/dist/cjs.js??ruleSet[1].rules[2].use[2]!./src/vitals/vitals-chart.scss");

      
      
      
      
      
      
      
      
      

var options = {};

options.styleTagTransform = (_node_modules_openmrs_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default());
options.setAttributes = (_node_modules_openmrs_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default());

      options.insert = _node_modules_openmrs_node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default().bind(null, "head");
    
options.domAPI = (_node_modules_openmrs_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default());
options.insertStyleElement = (_node_modules_openmrs_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default());

var update = _node_modules_openmrs_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_openmrs_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_2_use_1_node_modules_openmrs_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_2_use_2_vitals_chart_scss__WEBPACK_IMPORTED_MODULE_6__["default"], options);


if (true) {
  if (!_node_modules_openmrs_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_2_use_1_node_modules_openmrs_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_2_use_2_vitals_chart_scss__WEBPACK_IMPORTED_MODULE_6__["default"].locals || module.hot.invalidate) {
    var isEqualLocals = function isEqualLocals(a, b, isNamedExport) {
  if (!a && b || a && !b) {
    return false;
  }
  var p;
  for (p in a) {
    if (isNamedExport && p === "default") {
      // eslint-disable-next-line no-continue
      continue;
    }
    if (a[p] !== b[p]) {
      return false;
    }
  }
  for (p in b) {
    if (isNamedExport && p === "default") {
      // eslint-disable-next-line no-continue
      continue;
    }
    if (!a[p]) {
      return false;
    }
  }
  return true;
};
    var isNamedExport = !_node_modules_openmrs_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_2_use_1_node_modules_openmrs_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_2_use_2_vitals_chart_scss__WEBPACK_IMPORTED_MODULE_6__["default"].locals;
    var oldLocals = isNamedExport ? _node_modules_openmrs_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_2_use_1_node_modules_openmrs_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_2_use_2_vitals_chart_scss__WEBPACK_IMPORTED_MODULE_6__ : _node_modules_openmrs_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_2_use_1_node_modules_openmrs_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_2_use_2_vitals_chart_scss__WEBPACK_IMPORTED_MODULE_6__["default"].locals;

    module.hot.accept(
      /*! !!../../../../node_modules/openmrs/node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[2].use[1]!../../../../node_modules/openmrs/node_modules/sass-loader/dist/cjs.js??ruleSet[1].rules[2].use[2]!./vitals-chart.scss */ "../../node_modules/openmrs/node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[2].use[1]!../../node_modules/openmrs/node_modules/sass-loader/dist/cjs.js??ruleSet[1].rules[2].use[2]!./src/vitals/vitals-chart.scss",
      __WEBPACK_OUTDATED_DEPENDENCIES__ => { /* harmony import */ _node_modules_openmrs_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_2_use_1_node_modules_openmrs_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_2_use_2_vitals_chart_scss__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! !!../../../../node_modules/openmrs/node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[2].use[1]!../../../../node_modules/openmrs/node_modules/sass-loader/dist/cjs.js??ruleSet[1].rules[2].use[2]!./vitals-chart.scss */ "../../node_modules/openmrs/node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[2].use[1]!../../node_modules/openmrs/node_modules/sass-loader/dist/cjs.js??ruleSet[1].rules[2].use[2]!./src/vitals/vitals-chart.scss");
(function () {
        if (!isEqualLocals(oldLocals, isNamedExport ? _node_modules_openmrs_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_2_use_1_node_modules_openmrs_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_2_use_2_vitals_chart_scss__WEBPACK_IMPORTED_MODULE_6__ : _node_modules_openmrs_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_2_use_1_node_modules_openmrs_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_2_use_2_vitals_chart_scss__WEBPACK_IMPORTED_MODULE_6__["default"].locals, isNamedExport)) {
                module.hot.invalidate();

                return;
              }

              oldLocals = isNamedExport ? _node_modules_openmrs_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_2_use_1_node_modules_openmrs_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_2_use_2_vitals_chart_scss__WEBPACK_IMPORTED_MODULE_6__ : _node_modules_openmrs_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_2_use_1_node_modules_openmrs_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_2_use_2_vitals_chart_scss__WEBPACK_IMPORTED_MODULE_6__["default"].locals;

              update(_node_modules_openmrs_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_2_use_1_node_modules_openmrs_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_2_use_2_vitals_chart_scss__WEBPACK_IMPORTED_MODULE_6__["default"]);
      })(__WEBPACK_OUTDATED_DEPENDENCIES__); }
    )
  }

  module.hot.dispose(function() {
    update();
  });
}



       /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_openmrs_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_2_use_1_node_modules_openmrs_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_2_use_2_vitals_chart_scss__WEBPACK_IMPORTED_MODULE_6__["default"] && _node_modules_openmrs_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_2_use_1_node_modules_openmrs_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_2_use_2_vitals_chart_scss__WEBPACK_IMPORTED_MODULE_6__["default"].locals ? _node_modules_openmrs_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_2_use_1_node_modules_openmrs_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_2_use_2_vitals_chart_scss__WEBPACK_IMPORTED_MODULE_6__["default"].locals : undefined);


/***/ }),

/***/ "./src/vitals/vitals-overview.scss":
/*!*****************************************!*\
  !*** ./src/vitals/vitals-overview.scss ***!
  \*****************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_openmrs_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../../node_modules/openmrs/node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "../../node_modules/openmrs/node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_openmrs_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_openmrs_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_openmrs_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !../../../../node_modules/openmrs/node_modules/style-loader/dist/runtime/styleDomAPI.js */ "../../node_modules/openmrs/node_modules/style-loader/dist/runtime/styleDomAPI.js");
/* harmony import */ var _node_modules_openmrs_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_openmrs_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _node_modules_openmrs_node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../../node_modules/openmrs/node_modules/style-loader/dist/runtime/insertBySelector.js */ "../../node_modules/openmrs/node_modules/style-loader/dist/runtime/insertBySelector.js");
/* harmony import */ var _node_modules_openmrs_node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_node_modules_openmrs_node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _node_modules_openmrs_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../../../node_modules/openmrs/node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js */ "../../node_modules/openmrs/node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js");
/* harmony import */ var _node_modules_openmrs_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_node_modules_openmrs_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _node_modules_openmrs_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! !../../../../node_modules/openmrs/node_modules/style-loader/dist/runtime/insertStyleElement.js */ "../../node_modules/openmrs/node_modules/style-loader/dist/runtime/insertStyleElement.js");
/* harmony import */ var _node_modules_openmrs_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_node_modules_openmrs_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _node_modules_openmrs_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! !../../../../node_modules/openmrs/node_modules/style-loader/dist/runtime/styleTagTransform.js */ "../../node_modules/openmrs/node_modules/style-loader/dist/runtime/styleTagTransform.js");
/* harmony import */ var _node_modules_openmrs_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_node_modules_openmrs_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _node_modules_openmrs_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_2_use_1_node_modules_openmrs_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_2_use_2_vitals_overview_scss__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! !!../../../../node_modules/openmrs/node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[2].use[1]!../../../../node_modules/openmrs/node_modules/sass-loader/dist/cjs.js??ruleSet[1].rules[2].use[2]!./vitals-overview.scss */ "../../node_modules/openmrs/node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[2].use[1]!../../node_modules/openmrs/node_modules/sass-loader/dist/cjs.js??ruleSet[1].rules[2].use[2]!./src/vitals/vitals-overview.scss");

      
      
      
      
      
      
      
      
      

var options = {};

options.styleTagTransform = (_node_modules_openmrs_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default());
options.setAttributes = (_node_modules_openmrs_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default());

      options.insert = _node_modules_openmrs_node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default().bind(null, "head");
    
options.domAPI = (_node_modules_openmrs_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default());
options.insertStyleElement = (_node_modules_openmrs_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default());

var update = _node_modules_openmrs_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_openmrs_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_2_use_1_node_modules_openmrs_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_2_use_2_vitals_overview_scss__WEBPACK_IMPORTED_MODULE_6__["default"], options);


if (true) {
  if (!_node_modules_openmrs_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_2_use_1_node_modules_openmrs_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_2_use_2_vitals_overview_scss__WEBPACK_IMPORTED_MODULE_6__["default"].locals || module.hot.invalidate) {
    var isEqualLocals = function isEqualLocals(a, b, isNamedExport) {
  if (!a && b || a && !b) {
    return false;
  }
  var p;
  for (p in a) {
    if (isNamedExport && p === "default") {
      // eslint-disable-next-line no-continue
      continue;
    }
    if (a[p] !== b[p]) {
      return false;
    }
  }
  for (p in b) {
    if (isNamedExport && p === "default") {
      // eslint-disable-next-line no-continue
      continue;
    }
    if (!a[p]) {
      return false;
    }
  }
  return true;
};
    var isNamedExport = !_node_modules_openmrs_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_2_use_1_node_modules_openmrs_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_2_use_2_vitals_overview_scss__WEBPACK_IMPORTED_MODULE_6__["default"].locals;
    var oldLocals = isNamedExport ? _node_modules_openmrs_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_2_use_1_node_modules_openmrs_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_2_use_2_vitals_overview_scss__WEBPACK_IMPORTED_MODULE_6__ : _node_modules_openmrs_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_2_use_1_node_modules_openmrs_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_2_use_2_vitals_overview_scss__WEBPACK_IMPORTED_MODULE_6__["default"].locals;

    module.hot.accept(
      /*! !!../../../../node_modules/openmrs/node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[2].use[1]!../../../../node_modules/openmrs/node_modules/sass-loader/dist/cjs.js??ruleSet[1].rules[2].use[2]!./vitals-overview.scss */ "../../node_modules/openmrs/node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[2].use[1]!../../node_modules/openmrs/node_modules/sass-loader/dist/cjs.js??ruleSet[1].rules[2].use[2]!./src/vitals/vitals-overview.scss",
      __WEBPACK_OUTDATED_DEPENDENCIES__ => { /* harmony import */ _node_modules_openmrs_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_2_use_1_node_modules_openmrs_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_2_use_2_vitals_overview_scss__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! !!../../../../node_modules/openmrs/node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[2].use[1]!../../../../node_modules/openmrs/node_modules/sass-loader/dist/cjs.js??ruleSet[1].rules[2].use[2]!./vitals-overview.scss */ "../../node_modules/openmrs/node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[2].use[1]!../../node_modules/openmrs/node_modules/sass-loader/dist/cjs.js??ruleSet[1].rules[2].use[2]!./src/vitals/vitals-overview.scss");
(function () {
        if (!isEqualLocals(oldLocals, isNamedExport ? _node_modules_openmrs_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_2_use_1_node_modules_openmrs_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_2_use_2_vitals_overview_scss__WEBPACK_IMPORTED_MODULE_6__ : _node_modules_openmrs_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_2_use_1_node_modules_openmrs_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_2_use_2_vitals_overview_scss__WEBPACK_IMPORTED_MODULE_6__["default"].locals, isNamedExport)) {
                module.hot.invalidate();

                return;
              }

              oldLocals = isNamedExport ? _node_modules_openmrs_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_2_use_1_node_modules_openmrs_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_2_use_2_vitals_overview_scss__WEBPACK_IMPORTED_MODULE_6__ : _node_modules_openmrs_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_2_use_1_node_modules_openmrs_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_2_use_2_vitals_overview_scss__WEBPACK_IMPORTED_MODULE_6__["default"].locals;

              update(_node_modules_openmrs_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_2_use_1_node_modules_openmrs_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_2_use_2_vitals_overview_scss__WEBPACK_IMPORTED_MODULE_6__["default"]);
      })(__WEBPACK_OUTDATED_DEPENDENCIES__); }
    )
  }

  module.hot.dispose(function() {
    update();
  });
}



       /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_openmrs_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_2_use_1_node_modules_openmrs_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_2_use_2_vitals_overview_scss__WEBPACK_IMPORTED_MODULE_6__["default"] && _node_modules_openmrs_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_2_use_1_node_modules_openmrs_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_2_use_2_vitals_overview_scss__WEBPACK_IMPORTED_MODULE_6__["default"].locals ? _node_modules_openmrs_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_2_use_1_node_modules_openmrs_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_2_use_2_vitals_overview_scss__WEBPACK_IMPORTED_MODULE_6__["default"].locals : undefined);


/***/ }),

/***/ "./src/biometrics/biometrics-base.component.tsx":
/*!******************************************************!*\
  !*** ./src/biometrics/biometrics-base.component.tsx ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-i18next */ "webpack/sharing/consume/default/react-i18next/react-i18next");
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_i18next__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _openmrs_esm_patient_common_lib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @openmrs/esm-patient-common-lib */ "webpack/sharing/consume/default/@openmrs/esm-patient-common-lib/@openmrs/esm-patient-common-lib");
/* harmony import */ var _openmrs_esm_patient_common_lib__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_openmrs_esm_patient_common_lib__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @openmrs/esm-framework */ "webpack/sharing/consume/default/@openmrs/esm-framework/@openmrs/esm-framework");
/* harmony import */ var _openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _common_covid_stigma_data_resource__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../common/covid-stigma-data.resource */ "./src/common/covid-stigma-data.resource.tsx");
/* harmony import */ var _biometrics_base_scss__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./biometrics-base.scss */ "./src/biometrics/biometrics-base.scss");






var BiometricsBase = function(param) {
    var patientUuid = param.patientUuid;
    var t = (0,react_i18next__WEBPACK_IMPORTED_MODULE_1__.useTranslation)().t;
    var user = (0,_openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_3__.useSession)().user;
    // Determine user roles
    var userRoles = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(function() {
        var _user_roles;
        return (user === null || user === void 0 ? void 0 : (_user_roles = user.roles) === null || _user_roles === void 0 ? void 0 : _user_roles.map(function(r) {
            var _r_display;
            return (_r_display = r.display) === null || _r_display === void 0 ? void 0 : _r_display.toLowerCase();
        })) || [];
    }, [
        user
    ]);
    // If user has self-registration role, hide the widget
    if (userRoles.includes('self registration')) return null;
    var headerTitle = t('activities', 'गतिविधिहरू');
    var _useCovidStigmaData = (0,_common_covid_stigma_data_resource__WEBPACK_IMPORTED_MODULE_4__.useCovidStigmaData)(patientUuid), covidData = _useCovidStigmaData.data, isLoading = _useCovidStigmaData.isLoading;
    var activities = (0,_common_covid_stigma_data_resource__WEBPACK_IMPORTED_MODULE_4__.getActivitiesBasedOnStigma)(covidData);
    return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", {
        className: _biometrics_base_scss__WEBPACK_IMPORTED_MODULE_5__["default"].widgetCard
    }, /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_openmrs_esm_patient_common_lib__WEBPACK_IMPORTED_MODULE_2__.CardHeader, {
        title: headerTitle,
        children: ''
    }), /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", {
        className: _biometrics_base_scss__WEBPACK_IMPORTED_MODULE_5__["default"].body
    }, isLoading ? /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement("p", null, t('loading', 'Loading...')) : !covidData || covidData.length === 0 ? /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", {
        style: {
            minHeight: '50px'
        }
    }) : /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", null, activities)));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (BiometricsBase);


/***/ }),

/***/ "./src/biometrics/biometrics-main.component.tsx":
/*!******************************************************!*\
  !*** ./src/biometrics/biometrics-main.component.tsx ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-i18next */ "webpack/sharing/consume/default/react-i18next/react-i18next");
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_i18next__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _biometrics_base_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./biometrics-base.component */ "./src/biometrics/biometrics-base.component.tsx");



var BiometricsMain = function(param) {
    var patientUuid = param.patientUuid;
    var pageSize = 10;
    var t = (0,react_i18next__WEBPACK_IMPORTED_MODULE_1__.useTranslation)().t;
    var pageUrl = "${openmrsSpaBase}/patient/".concat(patientUuid, "/chart");
    var urlLabel = t('goToSummary', 'Go to Summary');
    return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_biometrics_base_component__WEBPACK_IMPORTED_MODULE_2__["default"], {
        patientUuid: patientUuid,
        pageSize: pageSize,
        urlLabel: urlLabel,
        pageUrl: pageUrl
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (BiometricsMain);


/***/ }),

/***/ "./src/biometrics/biometrics-overview.component.tsx":
/*!**********************************************************!*\
  !*** ./src/biometrics/biometrics-overview.component.tsx ***!
  \**********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-i18next */ "webpack/sharing/consume/default/react-i18next/react-i18next");
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_i18next__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _biometrics_base_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./biometrics-base.component */ "./src/biometrics/biometrics-base.component.tsx");



var BiometricsOverview = function(param) {
    var patientUuid = param.patientUuid, basePath = param.basePath;
    var t = (0,react_i18next__WEBPACK_IMPORTED_MODULE_1__.useTranslation)().t;
    var pageSize = 5;
    var pageUrl = "${openmrsSpaBase}/patient/".concat(patientUuid, "/chart/Vitals & Biometrics");
    var urlLabel = t('seeAll', 'See all');
    return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_biometrics_base_component__WEBPACK_IMPORTED_MODULE_2__["default"], {
        patientUuid: patientUuid,
        pageSize: pageSize,
        urlLabel: urlLabel,
        pageUrl: pageUrl
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (BiometricsOverview);


/***/ }),

/***/ "./src/common/conf_dashboard.tsx":
/*!***************************************!*\
  !*** ./src/common/conf_dashboard.tsx ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   checkCutoff: () => (/* binding */ checkCutoff),
/* harmony export */   "default": () => (/* binding */ AllPatientsDashboard),
/* harmony export */   isAboveCutoff: () => (/* binding */ isAboveCutoff),
/* harmony export */   isBelowCutoff: () => (/* binding */ isBelowCutoff),
/* harmony export */   useAllPatients: () => (/* binding */ useAllPatients)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var swr__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! swr */ "../../node_modules/swr/dist/index/index.mjs");
/* harmony import */ var _openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @openmrs/esm-framework */ "webpack/sharing/consume/default/@openmrs/esm-framework/@openmrs/esm-framework");
/* harmony import */ var _openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_chartjs_2__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react-chartjs-2 */ "../../node_modules/react-chartjs-2/dist/index.js");
/* harmony import */ var chart_js_auto__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! chart.js/auto */ "../../node_modules/chart.js/auto/auto.js");
function _array_like_to_array(arr, len) {
    if (len == null || len > arr.length) len = arr.length;
    for(var i = 0, arr2 = new Array(len); i < len; i++)arr2[i] = arr[i];
    return arr2;
}
function _array_with_holes(arr) {
    if (Array.isArray(arr)) return arr;
}
function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) {
    try {
        var info = gen[key](arg);
        var value = info.value;
    } catch (error) {
        reject(error);
        return;
    }
    if (info.done) {
        resolve(value);
    } else {
        Promise.resolve(value).then(_next, _throw);
    }
}
function _async_to_generator(fn) {
    return function() {
        var self = this, args = arguments;
        return new Promise(function(resolve, reject) {
            var gen = fn.apply(self, args);
            function _next(value) {
                asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value);
            }
            function _throw(err) {
                asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err);
            }
            _next(undefined);
        });
    };
}
function _iterable_to_array_limit(arr, i) {
    var _i = arr == null ? null : typeof Symbol !== "undefined" && arr[Symbol.iterator] || arr["@@iterator"];
    if (_i == null) return;
    var _arr = [];
    var _n = true;
    var _d = false;
    var _s, _e;
    try {
        for(_i = _i.call(arr); !(_n = (_s = _i.next()).done); _n = true){
            _arr.push(_s.value);
            if (i && _arr.length === i) break;
        }
    } catch (err) {
        _d = true;
        _e = err;
    } finally{
        try {
            if (!_n && _i["return"] != null) _i["return"]();
        } finally{
            if (_d) throw _e;
        }
    }
    return _arr;
}
function _non_iterable_rest() {
    throw new TypeError("Invalid attempt to destructure non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _sliced_to_array(arr, i) {
    return _array_with_holes(arr) || _iterable_to_array_limit(arr, i) || _unsupported_iterable_to_array(arr, i) || _non_iterable_rest();
}
function _unsupported_iterable_to_array(o, minLen) {
    if (!o) return;
    if (typeof o === "string") return _array_like_to_array(o, minLen);
    var n = Object.prototype.toString.call(o).slice(8, -1);
    if (n === "Object" && o.constructor) n = o.constructor.name;
    if (n === "Map" || n === "Set") return Array.from(n);
    if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _array_like_to_array(o, minLen);
}
function _ts_generator(thisArg, body) {
    var f, y, t, _ = {
        label: 0,
        sent: function() {
            if (t[0] & 1) throw t[1];
            return t[1];
        },
        trys: [],
        ops: []
    }, g = Object.create((typeof Iterator === "function" ? Iterator : Object).prototype);
    return g.next = verb(0), g["throw"] = verb(1), g["return"] = verb(2), typeof Symbol === "function" && (g[Symbol.iterator] = function() {
        return this;
    }), g;
    function verb(n) {
        return function(v) {
            return step([
                n,
                v
            ]);
        };
    }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while(g && (g = 0, op[0] && (_ = 0)), _)try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [
                op[0] & 2,
                t.value
            ];
            switch(op[0]){
                case 0:
                case 1:
                    t = op;
                    break;
                case 4:
                    _.label++;
                    return {
                        value: op[1],
                        done: false
                    };
                case 5:
                    _.label++;
                    y = op[1];
                    op = [
                        0
                    ];
                    continue;
                case 7:
                    op = _.ops.pop();
                    _.trys.pop();
                    continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
                        _ = 0;
                        continue;
                    }
                    if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
                        _.label = op[1];
                        break;
                    }
                    if (op[0] === 6 && _.label < t[1]) {
                        _.label = t[1];
                        t = op;
                        break;
                    }
                    if (t && _.label < t[2]) {
                        _.label = t[2];
                        _.ops.push(op);
                        break;
                    }
                    if (t[2]) _.ops.pop();
                    _.trys.pop();
                    continue;
            }
            op = body.call(thisArg, _);
        } catch (e) {
            op = [
                6,
                e
            ];
            y = 0;
        } finally{
            f = t = 0;
        }
        if (op[0] & 5) throw op[1];
        return {
            value: op[0] ? op[1] : void 0,
            done: true
        };
    }
}




 // ensures chart.js works
// import { StigmaAnnualTrendChart } from './stigma-annual-trend';
// import { StigmaOverviewChart } from './StigmaOverviewChart'; // adjust path if needed
// ---------------- Fetch All Patients (no pagination) ----------------
function fetchAllPatients() {
    return _async_to_generator(function() {
        var allPatients, offset, total, url, data;
        return _ts_generator(this, function(_state) {
            switch(_state.label){
                case 0:
                    allPatients = [];
                    offset = 0;
                    total = 0;
                    _state.label = 1;
                case 1:
                    if (false) {}
                    url = "".concat(_openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_1__.fhirBaseUrl, "/Patient?_count=100&_getpagesoffset=").concat(offset);
                    return [
                        4,
                        (0,_openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_1__.openmrsFetch)(url)
                    ];
                case 2:
                    data = _state.sent().data;
                    if (!(data === null || data === void 0 ? void 0 : data.entry) || data.entry.length === 0) return [
                        3,
                        3
                    ];
                    allPatients = allPatients.concat(data.entry.map(function(e) {
                        return e.resource;
                    }));
                    total = (data === null || data === void 0 ? void 0 : data.total) || allPatients.length;
                    offset += 100;
                    if (allPatients.length >= total) return [
                        3,
                        3
                    ];
                    return [
                        3,
                        1
                    ];
                case 3:
                    return [
                        2,
                        {
                            patients: allPatients,
                            total: total
                        }
                    ];
            }
        });
    })();
}
function useAllPatients() {
    return (0,swr__WEBPACK_IMPORTED_MODULE_3__["default"])('allPatients', fetchAllPatients);
}
function checkCutoff(value, cutoff) {
    var returnBoolean = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : false;
    if (value == null) return returnBoolean ? false : 'below';
    if (value < cutoff) return returnBoolean ? false : 'below';
    if (value > cutoff) return returnBoolean ? true : 'above';
    return returnBoolean ? true : 'equal';
}
// ---------------- Fetch Counselling/Stigma Data for a patient ----------------
function fetchPatientStigmaData(patientId) {
    return _async_to_generator(function() {
        var url, data, error;
        return _ts_generator(this, function(_state) {
            switch(_state.label){
                case 0:
                    _state.trys.push([
                        0,
                        2,
                        ,
                        3
                    ]);
                    url = "".concat(_openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_1__.fhirBaseUrl, "/Observation?subject=").concat(patientId, "&_count=100");
                    return [
                        4,
                        (0,_openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_1__.openmrsFetch)(url)
                    ];
                case 1:
                    data = _state.sent().data;
                    if (!(data === null || data === void 0 ? void 0 : data.entry)) return [
                        2,
                        []
                    ];
                    return [
                        2,
                        data.entry.map(function(e) {
                            return e.resource;
                        })
                    ];
                case 2:
                    error = _state.sent();
                    console.error("Error fetching stigma data for patient ".concat(patientId, ":"), error);
                    return [
                        2,
                        []
                    ];
                case 3:
                    return [
                        2
                    ];
            }
        });
    })();
}
// ---------------- Aggregate Data By Year and Month ----------------
function aggregateYearMonthPatientCount(allPatientsData, selectedYear) {
    // For each month, collect a Set of patient IDs
    var monthPatientSets = Array(12).fill(null).map(function() {
        return new Set();
    });
    allPatientsData.forEach(function(patientData, patientIdx) {
        patientData.forEach(function(obs) {
            var date = new Date(obs.effectiveDateTime || obs.date);
            if (!date) return;
            // Adjust for Nepali Time (UTC+5:45)
            var offsetInMs = 5 * 60 * 60 * 1000 + 45 * 60 * 1000;
            var nepaliDate = new Date(date.getTime() + offsetInMs);
            var year = nepaliDate.getFullYear().toString();
            var month = nepaliDate.getMonth(); // 0=Jan, 11=Dec
            if (year === selectedYear) {
                // Use patientIdx as unique patient identifier (since each patientData is for one patient)
                monthPatientSets[month].add(String(patientIdx));
            }
        });
    });
    // Convert sets to counts
    return monthPatientSets.map(function(set) {
        return set.size;
    });
}
// ---------------- Chart Component ----------------
function MonthlyBarChart(param) {
    var allPatientsData = param.allPatientsData, selectedYear = param.selectedYear, onYearChange = param.onYearChange, availableYears = param.availableYears;
    var monthCounts = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(function() {
        return aggregateYearMonthPatientCount(allPatientsData, selectedYear);
    }, [
        allPatientsData,
        selectedYear
    ]);
    var months = [
        'Jan',
        'Feb',
        'Mar',
        'Apr',
        'May',
        'Jun',
        'Jul',
        'Aug',
        'Sep',
        'Oct',
        'Nov',
        'Dec'
    ];
    var data = {
        labels: months,
        datasets: [
            {
                label: "Patient Count in ".concat(selectedYear),
                data: monthCounts,
                backgroundColor: '#1f2e5bff'
            }
        ]
    };
    return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", null, /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", {
        style: {
            marginBottom: '1rem'
        }
    }, /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement("label", {
        htmlFor: "year-select"
    }, "Select Year: "), /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement("select", {
        id: "year-select",
        value: selectedYear,
        onChange: function(e) {
            return onYearChange(e.target.value);
        }
    }, availableYears.map(function(y) {
        return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement("option", {
            key: y,
            value: y
        }, y);
    }))), /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement(react_chartjs_2__WEBPACK_IMPORTED_MODULE_4__.Chart, {
        type: "bar",
        data: data
    }));
}
function isAboveCutoff(value, cutoff) {
    if (value == null) return false;
    return value > cutoff;
}
function isBelowCutoff(value, cutoff) {
    if (value == null) return true;
    return value < cutoff;
}
// ---------------- Main Dashboard ----------------
function AllPatientsDashboard() {
    var _useAllPatients = useAllPatients(), data = _useAllPatients.data, isLoading = _useAllPatients.isLoading, error = _useAllPatients.error;
    var patients = (data === null || data === void 0 ? void 0 : data.patients) || [];
    var _useState = _sliced_to_array((0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]), 2), allPatientsData = _useState[0], setAllPatientsData = _useState[1];
    var _useState1 = _sliced_to_array((0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(''), 2), selectedYear = _useState1[0], setSelectedYear = _useState1[1];
    var _useState2 = _sliced_to_array((0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]), 2), availableYears = _useState2[0], setAvailableYears = _useState2[1];
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(function() {
        if (!(patients === null || patients === void 0 ? void 0 : patients.length)) return;
        Promise.all(patients.map(function(p) {
            return fetchPatientStigmaData(p.id);
        })).then(function(results) {
            setAllPatientsData(results);
            // Find all years present in the data
            var yearsSet = new Set();
            results.forEach(function(patientData) {
                patientData.forEach(function(obs) {
                    var date = new Date(obs.effectiveDateTime || obs.date);
                    if (!date) return;
                    // Adjust for Nepali Time
                    var offsetInMs = 5 * 60 * 60 * 1000 + 45 * 60 * 1000;
                    var nepaliDate = new Date(date.getTime() + offsetInMs);
                    yearsSet.add(nepaliDate.getFullYear().toString());
                });
            });
            var yearsArr = Array.from(yearsSet).sort();
            setAvailableYears(yearsArr);
            // Default to latest year
            if (yearsArr.length > 0) setSelectedYear(yearsArr[yearsArr.length - 1]);
        });
    }, [
        patients
    ]);
    // Test function to analyze stigma data
    function testStigmaAnalysis(patientData) {
        var totalPatients = 0;
        var matchedPatients = 0;
        var unmatchedPatients = 0;
        var patientMatches = {};
        patientData.forEach(function(observations, patientIndex) {
            var patientId = String(patientIndex);
            // Process observations to match CovidStigmaData format
            var stigmaData = observations.filter(function(obs) {
                var // Filter only stigma-related observations
                _obs_code_coding, _obs_code;
                return (_obs_code = obs.code) === null || _obs_code === void 0 ? void 0 : (_obs_code_coding = _obs_code.coding) === null || _obs_code_coding === void 0 ? void 0 : _obs_code_coding.some(function(coding) {
                    var _coding_display, _coding_code;
                    return ((_coding_display = coding.display) === null || _coding_display === void 0 ? void 0 : _coding_display.toLowerCase().includes('stigma')) || ((_coding_code = coding.code) === null || _coding_code === void 0 ? void 0 : _coding_code.toLowerCase().includes('stigma'));
                });
            }).map(function(obs) {
                var _obs_encounter, _obs_code_coding_, _obs_code_coding, _obs_code, _obs_valueQuantity, _obs_component, _obs_component_find_valueQuantity, _obs_component_find, _obs_component1;
                return {
                    id: obs.id,
                    date: obs.effectiveDateTime || obs.date,
                    encounterUuid: (_obs_encounter = obs.encounter) === null || _obs_encounter === void 0 ? void 0 : _obs_encounter.reference,
                    stigmaType: ((_obs_code = obs.code) === null || _obs_code === void 0 ? void 0 : (_obs_code_coding = _obs_code.coding) === null || _obs_code_coding === void 0 ? void 0 : (_obs_code_coding_ = _obs_code_coding[0]) === null || _obs_code_coding_ === void 0 ? void 0 : _obs_code_coding_.display) || '',
                    stigmaScore: ((_obs_valueQuantity = obs.valueQuantity) === null || _obs_valueQuantity === void 0 ? void 0 : _obs_valueQuantity.value) || 0,
                    dimensionType: '',
                    dimensionScore: ((_obs_component = obs.component) === null || _obs_component === void 0 ? void 0 : _obs_component.map(function(c) {
                        var _c_valueQuantity;
                        return "".concat(c.code.text, ":").concat(((_c_valueQuantity = c.valueQuantity) === null || _c_valueQuantity === void 0 ? void 0 : _c_valueQuantity.value) || 0);
                    }).join(', ')) || '',
                    intersectionalScore: ((_obs_component1 = obs.component) === null || _obs_component1 === void 0 ? void 0 : (_obs_component_find = _obs_component1.find(function(c) {
                        var _c_code_text;
                        return (_c_code_text = c.code.text) === null || _c_code_text === void 0 ? void 0 : _c_code_text.toLowerCase().includes('intersectional');
                    })) === null || _obs_component_find === void 0 ? void 0 : (_obs_component_find_valueQuantity = _obs_component_find.valueQuantity) === null || _obs_component_find_valueQuantity === void 0 ? void 0 : _obs_component_find_valueQuantity.value) || 0
                };
            });
            // Only count patients who have stigma data
            if (stigmaData.length > 0) {
                // console.log(`\n📊 Analyzing Patient ${patientId}:`);
                // Use a Set to track unique score types for this patient
                var uniqueScoreTypes = new Set();
                // Count all scores over their respective thresholds, ensuring each type is only counted once per patient
                var highScores = stigmaData.reduce(function(scores, entry) {
                    var _entry_stigmaType;
                    var type = ((_entry_stigmaType = entry.stigmaType) === null || _entry_stigmaType === void 0 ? void 0 : _entry_stigmaType.toLowerCase()) || '';
                    var score = typeof entry.stigmaScore === 'number' ? entry.stigmaScore : typeof entry.stigmaScore === 'string' ? parseFloat(entry.stigmaScore) : 0;
                    // Skip if score is not a valid number
                    if (isNaN(score)) return scores;
                    // Intersectional scores
                    if (type.includes('intersectional')) {
                        if (type.includes('anticipated') && score >= 80 && !uniqueScoreTypes.has('Anticipated Intersectional')) {
                            uniqueScoreTypes.add('Anticipated Intersectional');
                            scores.push({
                                type: 'Anticipated Intersectional',
                                score: score,
                                threshold: 80
                            });
                        }
                        if (type.includes('enacted') && score >= 86 && !uniqueScoreTypes.has('Enacted Intersectional')) {
                            uniqueScoreTypes.add('Enacted Intersectional');
                            scores.push({
                                type: 'Enacted Intersectional',
                                score: score,
                                threshold: 86
                            });
                        }
                        if (type.includes('internalized') && score >= 66 && !uniqueScoreTypes.has('Internalized Intersectional')) {
                            uniqueScoreTypes.add('Internalized Intersectional');
                            scores.push({
                                type: 'Internalized Intersectional',
                                score: score,
                                threshold: 66
                            });
                        }
                    }
                    // Domain scores
                    if (type.includes('mental health')) {
                        if (type.includes('enacted') && score >= 43 && !uniqueScoreTypes.has('Mental Health Enacted')) {
                            uniqueScoreTypes.add('Mental Health Enacted');
                            scores.push({
                                type: 'Mental Health Enacted',
                                score: score,
                                threshold: 43
                            });
                        }
                        if (type.includes('anticipated') && score >= 40 && !uniqueScoreTypes.has('Mental Health Anticipated')) {
                            uniqueScoreTypes.add('Mental Health Anticipated');
                            scores.push({
                                type: 'Mental Health Anticipated',
                                score: score,
                                threshold: 40
                            });
                        }
                        if (type.includes('internalized') && score >= 33 && !uniqueScoreTypes.has('Mental Health Internalized')) {
                            uniqueScoreTypes.add('Mental Health Internalized');
                            scores.push({
                                type: 'Mental Health Internalized',
                                score: score,
                                threshold: 33
                            });
                        }
                    }
                    // Total scores
                    if (type.includes('total score')) {
                        if (type.includes('enacted') && score >= 43 && !uniqueScoreTypes.has('Total Enacted')) {
                            uniqueScoreTypes.add('Total Enacted');
                            scores.push({
                                type: 'Total Enacted',
                                score: score,
                                threshold: 43
                            });
                        }
                        if (type.includes('anticipated') && score >= 40) {
                            scores.push({
                                type: 'Total Anticipated',
                                score: score,
                                threshold: 40
                            });
                        }
                        if (type.includes('internalized') && score >= 33) {
                            scores.push({
                                type: 'Total Internalized',
                                score: score,
                                threshold: 33
                            });
                        }
                    }
                    return scores;
                }, []);
                totalPatients++;
                var hasHighScore = highScores.length > 0;
                patientMatches[patientId] = {
                    matched: hasHighScore,
                    highestScores: highScores
                };
                if (hasHighScore) {
                    //   console.log('⚠️ HIGH STIGMA DETECTED:');
                    highScores.forEach(function(s) {
                    // console.log(`  → ${s.type}: ${s.score} (threshold: ${s.threshold})`);
                    });
                    matchedPatients++;
                } else {
                    //   console.log('✓ All scores below thresholds');
                    unmatchedPatients++;
                }
            // console.log('Running Totals:', {
            //   total: totalPatients,
            //   high: matchedPatients,
            //   low: unmatchedPatients,
            // });
            }
        });
        return {
            totalPatients: totalPatients,
            matchedPatients: matchedPatients,
            unmatchedPatients: unmatchedPatients,
            patientMatches: patientMatches
        };
    }
    var stigmaDataByPatient = {};
    allPatientsData.forEach(function(patientObservations, index) {
        stigmaDataByPatient[String(index)] = patientObservations;
    });
    // Test the analysis and log results
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(function() {
        if (allPatientsData.length > 0) {
            var analysisResult = testStigmaAnalysis(allPatientsData);
        //   console.log('Stigma Analysis Test Results:', {
        //     totalPatients: analysisResult.totalPatients,
        //     matchedPatients: analysisResult.matchedPatients,
        //     unmatchedPatients: analysisResult.unmatchedPatients,
        //     matchDetails: analysisResult.patientMatches,
        //   });
        }
    }, [
        allPatientsData
    ]);
    var stigmaCutoffSummary = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(function() {
        // Run the test analysis when data is available
        if (allPatientsData.length > 0) {
            var analysisResult = testStigmaAnalysis(allPatientsData);
            //   console.log('Stigma Analysis Test Results:', analysisResult);
            return analysisResult;
        }
        return null;
    }, [
        allPatientsData
    ]);
    return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", {
        style: {
            padding: '1rem',
            border: '2px solid #fafbfdff',
            margin: '1rem',
            backgroundColor: '#f0f8ff'
        }
    }, isLoading && /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement("p", null, "Loading patient data..."), error && /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement("p", {
        style: {
            color: 'red'
        }
    }, "Error loading patients: ", String(error)), !isLoading && !(patients === null || patients === void 0 ? void 0 : patients.length) && /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement("p", null, "No patients found"), allPatientsData.length > 0 && /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", {
        style: {
            backgroundColor: '#fff',
            padding: '1rem',
            marginBottom: '1rem',
            borderRadius: '8px',
            boxShadow: '0 2px 4px rgba(0,0,0,0.1)'
        }
    }, /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement("h3", {
        style: {
            fontSize: '1.5rem',
            fontWeight: '600',
            color: '#333',
            textRendering: 'optimizeLegibility',
            marginBottom: '1.5rem'
        }
    }, "लान्छना विश्लेषण नतिजाहरू"), stigmaCutoffSummary ? /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null, /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", {
        style: {
            maxWidth: '500px',
            margin: '20px auto',
            WebkitFontSmoothing: 'antialiased',
            MozOsxFontSmoothing: 'grayscale'
        }
    }, /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement(react_chartjs_2__WEBPACK_IMPORTED_MODULE_4__.Chart, {
        type: "pie",
        data: {
            labels: [
                'उच्च लान्छना स्कोर',
                'न्यून लान्छना स्कोर'
            ],
            datasets: [
                {
                    data: [
                        stigmaCutoffSummary.matchedPatients,
                        stigmaCutoffSummary.unmatchedPatients
                    ],
                    backgroundColor: [
                        '#FFA500',
                        '#87CEEB'
                    ],
                    borderColor: [
                        '#fff',
                        '#fff'
                    ],
                    borderWidth: 2
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: true,
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: {
                        font: {
                            size: 14,
                            weight: 500
                        },
                        padding: 20
                    }
                },
                tooltip: {
                    titleFont: {
                        size: 14,
                        weight: 600
                    },
                    bodyFont: {
                        size: 13
                    },
                    callbacks: {
                        label: function label(context) {
                            var total = stigmaCutoffSummary.totalPatients;
                            var value = context.raw;
                            var percentage = (value / total * 100).toFixed(1);
                            return "".concat(context.label, ": ").concat(percentage, "% (").concat(value, " बिरामीहरू)");
                        }
                    }
                }
            }
        }
    }))) : /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement("p", null, "तथ्यांक विश्लेषण गर्दै...")), patients.length > 0 && selectedYear && /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement(MonthlyBarChart, {
        allPatientsData: allPatientsData,
        selectedYear: selectedYear,
        onYearChange: setSelectedYear,
        availableYears: availableYears
    }));
}


/***/ }),

/***/ "./src/common/covid-stigma-data.resource.tsx":
/*!***************************************************!*\
  !*** ./src/common/covid-stigma-data.resource.tsx ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   computeStigmaMatch_LatestOnly: () => (/* binding */ computeStigmaMatch_LatestOnly),
/* harmony export */   getActivitiesBasedOnStigma: () => (/* binding */ getActivitiesBasedOnStigma),
/* harmony export */   mapStigmaDataToVitalsFormat: () => (/* binding */ mapStigmaDataToVitalsFormat),
/* harmony export */   preprocessStigmaTrendsAll: () => (/* binding */ preprocessStigmaTrendsAll),
/* harmony export */   useCovidStigmaData: () => (/* binding */ useCovidStigmaData)
/* harmony export */ });
/* harmony import */ var _openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @openmrs/esm-framework */ "webpack/sharing/consume/default/@openmrs/esm-framework/@openmrs/esm-framework");
/* harmony import */ var _openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var swr__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! swr */ "../../node_modules/swr/dist/index/index.mjs");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _common_img_QR1_HIV_awareness_NAPN_png__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../common/img/QR1_HIV awareness_NAPN.png */ "./src/common/img/QR1_HIV awareness_NAPN.png");
/* harmony import */ var _common_img_QR2_TPO_Managing_fear_png__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../common/img/QR2_TPO_Managing fear.png */ "./src/common/img/QR2_TPO_Managing fear.png");
/* harmony import */ var _common_img_QR3_BDS_Ideal_World_png__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../common/img/QR3_BDS_Ideal World.png */ "./src/common/img/QR3_BDS_Ideal World.png");
/* harmony import */ var _common_img_QR4_Treatment_adherence_video_NCASC_png__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../common/img/QR4_Treatment adherence video(उपचार पालना)_NCASC.png */ "./src/common/img/QR4_Treatment adherence video(उपचार पालना)_NCASC.png");
function _array_like_to_array(arr, len) {
    if (len == null || len > arr.length) len = arr.length;
    for(var i = 0, arr2 = new Array(len); i < len; i++)arr2[i] = arr[i];
    return arr2;
}
function _array_with_holes(arr) {
    if (Array.isArray(arr)) return arr;
}
function _array_without_holes(arr) {
    if (Array.isArray(arr)) return _array_like_to_array(arr);
}
function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) {
    try {
        var info = gen[key](arg);
        var value = info.value;
    } catch (error) {
        reject(error);
        return;
    }
    if (info.done) {
        resolve(value);
    } else {
        Promise.resolve(value).then(_next, _throw);
    }
}
function _async_to_generator(fn) {
    return function() {
        var self = this, args = arguments;
        return new Promise(function(resolve, reject) {
            var gen = fn.apply(self, args);
            function _next(value) {
                asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value);
            }
            function _throw(err) {
                asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err);
            }
            _next(undefined);
        });
    };
}
function _define_property(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
function _iterable_to_array(iter) {
    if (typeof Symbol !== "undefined" && iter[Symbol.iterator] != null || iter["@@iterator"] != null) return Array.from(iter);
}
function _iterable_to_array_limit(arr, i) {
    var _i = arr == null ? null : typeof Symbol !== "undefined" && arr[Symbol.iterator] || arr["@@iterator"];
    if (_i == null) return;
    var _arr = [];
    var _n = true;
    var _d = false;
    var _s, _e;
    try {
        for(_i = _i.call(arr); !(_n = (_s = _i.next()).done); _n = true){
            _arr.push(_s.value);
            if (i && _arr.length === i) break;
        }
    } catch (err) {
        _d = true;
        _e = err;
    } finally{
        try {
            if (!_n && _i["return"] != null) _i["return"]();
        } finally{
            if (_d) throw _e;
        }
    }
    return _arr;
}
function _non_iterable_rest() {
    throw new TypeError("Invalid attempt to destructure non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _non_iterable_spread() {
    throw new TypeError("Invalid attempt to spread non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _object_spread(target) {
    for(var i = 1; i < arguments.length; i++){
        var source = arguments[i] != null ? arguments[i] : {};
        var ownKeys = Object.keys(source);
        if (typeof Object.getOwnPropertySymbols === "function") {
            ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function(sym) {
                return Object.getOwnPropertyDescriptor(source, sym).enumerable;
            }));
        }
        ownKeys.forEach(function(key) {
            _define_property(target, key, source[key]);
        });
    }
    return target;
}
function ownKeys(object, enumerableOnly) {
    var keys = Object.keys(object);
    if (Object.getOwnPropertySymbols) {
        var symbols = Object.getOwnPropertySymbols(object);
        if (enumerableOnly) {
            symbols = symbols.filter(function(sym) {
                return Object.getOwnPropertyDescriptor(object, sym).enumerable;
            });
        }
        keys.push.apply(keys, symbols);
    }
    return keys;
}
function _object_spread_props(target, source) {
    source = source != null ? source : {};
    if (Object.getOwnPropertyDescriptors) {
        Object.defineProperties(target, Object.getOwnPropertyDescriptors(source));
    } else {
        ownKeys(Object(source)).forEach(function(key) {
            Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key));
        });
    }
    return target;
}
function _sliced_to_array(arr, i) {
    return _array_with_holes(arr) || _iterable_to_array_limit(arr, i) || _unsupported_iterable_to_array(arr, i) || _non_iterable_rest();
}
function _to_consumable_array(arr) {
    return _array_without_holes(arr) || _iterable_to_array(arr) || _unsupported_iterable_to_array(arr) || _non_iterable_spread();
}
function _unsupported_iterable_to_array(o, minLen) {
    if (!o) return;
    if (typeof o === "string") return _array_like_to_array(o, minLen);
    var n = Object.prototype.toString.call(o).slice(8, -1);
    if (n === "Object" && o.constructor) n = o.constructor.name;
    if (n === "Map" || n === "Set") return Array.from(n);
    if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _array_like_to_array(o, minLen);
}
function _ts_generator(thisArg, body) {
    var f, y, t, _ = {
        label: 0,
        sent: function() {
            if (t[0] & 1) throw t[1];
            return t[1];
        },
        trys: [],
        ops: []
    }, g = Object.create((typeof Iterator === "function" ? Iterator : Object).prototype);
    return g.next = verb(0), g["throw"] = verb(1), g["return"] = verb(2), typeof Symbol === "function" && (g[Symbol.iterator] = function() {
        return this;
    }), g;
    function verb(n) {
        return function(v) {
            return step([
                n,
                v
            ]);
        };
    }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while(g && (g = 0, op[0] && (_ = 0)), _)try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [
                op[0] & 2,
                t.value
            ];
            switch(op[0]){
                case 0:
                case 1:
                    t = op;
                    break;
                case 4:
                    _.label++;
                    return {
                        value: op[1],
                        done: false
                    };
                case 5:
                    _.label++;
                    y = op[1];
                    op = [
                        0
                    ];
                    continue;
                case 7:
                    op = _.ops.pop();
                    _.trys.pop();
                    continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
                        _ = 0;
                        continue;
                    }
                    if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
                        _.label = op[1];
                        break;
                    }
                    if (op[0] === 6 && _.label < t[1]) {
                        _.label = t[1];
                        t = op;
                        break;
                    }
                    if (t && _.label < t[2]) {
                        _.label = t[2];
                        _.ops.push(op);
                        break;
                    }
                    if (t[2]) _.ops.pop();
                    _.trys.pop();
                    continue;
            }
            op = body.call(thisArg, _);
        } catch (e) {
            op = [
                6,
                e
            ];
            y = 0;
        } finally{
            f = t = 0;
        }
        if (op[0] & 5) throw op[1];
        return {
            value: op[0] ? op[1] : void 0,
            done: true
        };
    }
}



// import hivGuidelinesImg from '../common/img/National HIV testing and treatment guidelines.png';
// import unaids from '../common/img/UNAIDS terminology guideline.png';




var ImageModal = function(param) {
    var imageUrl = param.imageUrl, altText = param.altText, isOpen = param.isOpen, onClose = param.onClose;
    if (!isOpen) return null;
    return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().createElement("div", {
        style: {
            position: 'fixed',
            top: 0,
            left: 0,
            width: '100%',
            height: '100%',
            backgroundColor: 'rgba(0, 0, 0, 0.7)',
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'center',
            zIndex: 1000
        },
        onClick: onClose
    }, /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().createElement("div", {
        style: {
            backgroundColor: 'white',
            padding: '20px',
            borderRadius: '8px',
            maxWidth: '90%',
            maxHeight: '90%',
            overflow: 'auto',
            position: 'relative'
        },
        onClick: function(e) {
            return e.stopPropagation();
        }
    }, /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().createElement("button", {
        style: {
            position: 'absolute',
            top: '10px',
            right: '10px',
            background: 'none',
            border: 'none',
            fontSize: '20px',
            cursor: 'pointer',
            color: '#333'
        },
        onClick: onClose
    }, "✕"), /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().createElement("img", {
        src: imageUrl,
        alt: altText,
        style: {
            maxWidth: '100%',
            maxHeight: 'calc(90vh - 60px)',
            objectFit: 'contain',
            display: 'block',
            margin: '0 auto'
        }
    }), /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().createElement("p", {
        style: {
            textAlign: 'center',
            marginTop: '10px'
        }
    }, altText)));
};
var QRCodeWithPopup = function(param) {
    var image = param.image, alt = param.alt;
    var _useState = _sliced_to_array((0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false), 2), isModalOpen = _useState[0], setIsModalOpen = _useState[1];
    return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().createElement((react__WEBPACK_IMPORTED_MODULE_1___default().Fragment), null, /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().createElement("img", {
        src: image,
        alt: alt,
        style: {
            maxWidth: '100px',
            borderRadius: '6px',
            cursor: 'pointer'
        },
        onClick: function() {
            return setIsModalOpen(true);
        }
    }), /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().createElement(ImageModal, {
        imageUrl: image,
        altText: alt,
        isOpen: isModalOpen,
        onClose: function() {
            return setIsModalOpen(false);
        }
    }));
};
/* ---------------- Hook ---------------- */ function useCovidStigmaData(patientUuid) {
    var swrKey = patientUuid ? "".concat(_openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_0__.restBaseUrl, "/encounter?patient=").concat(patientUuid, "&v=full&limit=100") : null;
    var _useSWR = (0,swr__WEBPACK_IMPORTED_MODULE_6__["default"])(swrKey, function(url) {
        return _async_to_generator(function() {
            var _response_data, response, encounters, stigmaData, num, getObsVal, _iteratorNormalCompletion, _didIteratorError, _iteratorError, _iterator, _step, enc, rawAS, rawAS_inter, rawES, rawES_inter, rawIS, rawIS_inter, hivAS, mhAS, sgmAS, emAS, hivES, mhES, sgmES, emES, hivIS, mhIS, sgmIS, emIS, asScore, esScore, isScore;
            return _ts_generator(this, function(_state) {
                switch(_state.label){
                    case 0:
                        return [
                            4,
                            (0,_openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_0__.openmrsFetch)(url)
                        ];
                    case 1:
                        response = _state.sent();
                        encounters = ((_response_data = response.data) === null || _response_data === void 0 ? void 0 : _response_data.results) || [];
                        if (!(encounters === null || encounters === void 0 ? void 0 : encounters.length)) return [
                            2,
                            []
                        ];
                        stigmaData = [];
                        // Parse a value into a number. If the value is a string like "31/36" or "112/120",
                        // extract the first numeric token (e.g. 31 or 112) rather than concatenating digits.
                        num = function(v) {
                            if (v === null || v === undefined || v === '') return 0;
                            if (typeof v === 'number') return v;
                            var s = String(v).trim();
                            var match = s.match(/-?\d+(?:\.\d+)?/);
                            if (!match) return 0;
                            var n = parseFloat(match[0]);
                            return Number.isFinite(n) ? n : 0;
                        };
                        getObsVal = function(enc, conceptUuid) {
                            var _enc_obs, _obs_value;
                            var obs = (_enc_obs = enc.obs) === null || _enc_obs === void 0 ? void 0 : _enc_obs.find(function(o) {
                                var _o_concept;
                                return ((_o_concept = o.concept) === null || _o_concept === void 0 ? void 0 : _o_concept.uuid) === conceptUuid;
                            });
                            if (!obs) return null;
                            var _obs_value_display, _ref;
                            return (_ref = (_obs_value_display = (_obs_value = obs.value) === null || _obs_value === void 0 ? void 0 : _obs_value.display) !== null && _obs_value_display !== void 0 ? _obs_value_display : obs.value) !== null && _ref !== void 0 ? _ref : null;
                        };
                        _iteratorNormalCompletion = true, _didIteratorError = false, _iteratorError = undefined;
                        try {
                            for(_iterator = encounters[Symbol.iterator](); !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true){
                                enc = _step.value;
                                rawAS = getObsVal(enc, 'b5be0487-ef8e-4c39-ad86-39dd341cf0a7');
                                rawAS_inter = getObsVal(enc, '260b7159-9cc9-442d-b641-133b5dbbce06');
                                rawES = getObsVal(enc, '367a6a1f-b951-4eac-8068-a5f0801d6aff');
                                rawES_inter = getObsVal(enc, 'fb3a85e9-5154-46f7-8c00-54cce586332c');
                                rawIS = getObsVal(enc, '3f318839-599e-47d7-96f5-4c81ca64dfc3');
                                rawIS_inter = getObsVal(enc, '54addbef-17f5-4678-988a-9d6a68ad38f7');
                                // Domains
                                hivAS = num(getObsVal(enc, '90e0da1c-1bb4-48db-869e-d0ed4cd11c24'));
                                mhAS = num(getObsVal(enc, '8f94f4c3-58f2-414a-9286-68c5ede9c46e'));
                                sgmAS = num(getObsVal(enc, 'eb0a135d-3b90-470c-a684-d6dc3464712d'));
                                emAS = num(getObsVal(enc, 'd1ccc9dc-92fa-4118-af50-6394295131f8'));
                                hivES = num(getObsVal(enc, '6a0fbece-ed88-4da2-9cb2-6db7848dbdfd'));
                                mhES = num(getObsVal(enc, '7ed8a592-dac5-4c7b-b9c0-3ac6126689b8'));
                                sgmES = num(getObsVal(enc, '5c10bc7a-332c-4586-94f2-fbb90b8a264d'));
                                emES = num(getObsVal(enc, '298384cf-8f27-4ec0-93ca-4657eb66c8a1'));
                                hivIS = num(getObsVal(enc, 'ea081a06-b663-40f0-b74c-ede85468ed89'));
                                mhIS = num(getObsVal(enc, 'ef14a69f-b4fa-4fcd-8699-6b827bb67525'));
                                sgmIS = num(getObsVal(enc, '79c9043f-3cb6-41b2-b189-6018cb9b2bde'));
                                emIS = num(getObsVal(enc, '373eca5f-bc30-4b5e-a799-c50931731209')); // keep as provided
                                asScore = num(rawAS);
                                esScore = num(rawES);
                                isScore = num(rawIS);
                                if (rawAS != null) {
                                    stigmaData.push({
                                        id: "".concat(enc.uuid, "-एन्टिसिपेटेड"),
                                        date: enc.encounterDatetime,
                                        stigmaType: 'अपेक्षित लान्छना',
                                        stigmaScore: "".concat(rawAS, "/36"),
                                        as_score: asScore,
                                        dimensionType: [
                                            hivAS,
                                            mhAS,
                                            sgmAS,
                                            emAS
                                        ].some(function(s) {
                                            return s > 0;
                                        }) ? 'Domains' : '',
                                        dimensionScore: "एचआईभी :".concat(hivAS, "/120, मानसिक स्वास्थ्य:").concat(mhAS, "/120, लैङ्गिक तथा यौनिक अल्पसङ्ख्यक:").concat(sgmAS, "/120, जातीय अल्पसङ्ख्यक/दलित:").concat(emAS, "/120"),
                                        hiv_domain_as: hivAS,
                                        mh_domain_as: mhAS,
                                        sgm_domain_as: sgmAS,
                                        em_domain_as: emAS,
                                        intersectionalScore: rawAS_inter !== null && rawAS_inter !== void 0 ? rawAS_inter : 0,
                                        intersectional_stigma_as: num(rawAS_inter),
                                        encounterUuid: enc.uuid
                                    });
                                }
                                if (rawES != null) {
                                    stigmaData.push({
                                        id: "".concat(enc.uuid, "-enacted"),
                                        date: enc.encounterDatetime,
                                        stigmaType: 'व्यावहारिक लान्छना',
                                        stigmaScore: "".concat(rawES, "/13"),
                                        es_score: esScore,
                                        dimensionType: [
                                            hivES,
                                            mhES,
                                            sgmES,
                                            emES
                                        ].some(function(s) {
                                            return s > 0;
                                        }) ? 'Domains' : '',
                                        dimensionScore: "एचआईभी:".concat(hivES, "/130, मानसिक स्वास्थ्य:").concat(mhES, "/130, लैङ्गिक तथा यौनिक अल्पसङ्ख्यक:").concat(sgmES, "/130, जातीय अल्पसङ्ख्यक/दलित:").concat(emES, "/130"),
                                        hiv_domain_es: hivES,
                                        mh_domain_es: mhES,
                                        sgm_domain_es: sgmES,
                                        em_domain_es: emES,
                                        intersectionalScore: rawES_inter !== null && rawES_inter !== void 0 ? rawES_inter : 0,
                                        intersectional_stigma_es: num(rawES_inter),
                                        encounterUuid: enc.uuid
                                    });
                                }
                                if (rawIS != null) {
                                    stigmaData.push({
                                        id: "".concat(enc.uuid, "-internalized"),
                                        date: enc.encounterDatetime,
                                        stigmaType: 'आत्मलान्छना',
                                        stigmaScore: "".concat(rawIS, "/30"),
                                        is_score: isScore,
                                        dimensionType: [
                                            hivIS,
                                            mhIS,
                                            sgmIS,
                                            emIS
                                        ].some(function(s) {
                                            return s > 0;
                                        }) ? 'Domains' : '',
                                        dimensionScore: "एचआईभी:".concat(hivIS, "/100, मानसिक स्वास्थ्य:").concat(mhIS, "/100, लैङ्गिक तथा यौनिक अल्पसङ्ख्यक:").concat(sgmIS, "/100, जातीय अल्पसङ्ख्यक/दलित:").concat(emIS, "/100"),
                                        hiv_domain_is: hivIS,
                                        mh_domain_is: mhIS,
                                        sgm_domain_is: sgmIS,
                                        em_domain_is: emIS,
                                        intersectionalScore: rawIS_inter !== null && rawIS_inter !== void 0 ? rawIS_inter : 0,
                                        intersectional_stigma_is: num(rawIS_inter),
                                        encounterUuid: enc.uuid
                                    });
                                }
                            }
                        } catch (err) {
                            _didIteratorError = true;
                            _iteratorError = err;
                        } finally{
                            try {
                                if (!_iteratorNormalCompletion && _iterator.return != null) {
                                    _iterator.return();
                                }
                            } finally{
                                if (_didIteratorError) {
                                    throw _iteratorError;
                                }
                            }
                        }
                        return [
                            2,
                            stigmaData
                        ];
                }
            });
        })();
    }), data = _useSWR.data, error = _useSWR.error, isLoading = _useSWR.isLoading, mutate = _useSWR.mutate;
    return {
        data: data || [],
        error: error,
        isLoading: isLoading,
        mutate: mutate
    };
}
// helper: show dimension scores with correct color thresholds
// Color based on clinical cutoff, display shows total possible score (denominator)
function renderColoredValue(label, value, displayDenominator, clinicalCutoff) {
    // Show "Low" when below cutoff, otherwise show value/denominator in red
    return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().createElement("div", {
        key: label,
        style: {
            display: 'block',
            marginBottom: '8px',
            whiteSpace: 'nowrap'
        }
    }, /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().createElement("span", {
        style: {
            fontWeight: 'bold'
        }
    }, label, ":", ' ', value == null ? null : value < clinicalCutoff ? /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().createElement("span", {
        style: {
            color: '#5993ebff',
            fontWeight: 'bold'
        }
    }, "Low") : /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().createElement("span", {
        style: {
            color: 'red'
        }
    }, value, "/", displayDenominator)));
}
// helper for rendering just the score value with color
// Show "Low" when below clinical cutoff, otherwise show score in red
function renderScoreOnly(scoreText, rawValue, displayDenominator, clinicalCutoff) {
    if (rawValue == null) return null;
    if (rawValue < clinicalCutoff) {
        return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().createElement("span", {
            style: {
                color: '#5993ebff',
                fontWeight: 'bold'
            }
        }, "Low");
    }
    return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().createElement("span", {
        style: {
            color: 'red',
            fontWeight: 'bold'
        }
    }, scoreText);
}
// helper for rendering intersectional score - shows the value with conditional color
// Uses display denominator for UI (240/260/200) but compares against clinical cutoff for color
function renderIntersectionalScore(value, clinicalCutoff, displayDenominator) {
    if (value == null) return null;
    var color = value >= clinicalCutoff ? 'red' : '#5993ebff';
    return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().createElement("span", {
        style: {
            color: color,
            fontWeight: 'bold'
        }
    }, value, "/", displayDenominator);
}
function mapStigmaDataToVitalsFormat(stigmaData, type) {
    var seen = new Set();
    return stigmaData.filter(function(d) {
        var key = "".concat(d.encounterUuid, "-").concat(d.stigmaType);
        if (d.stigmaType === type && !seen.has(key)) {
            seen.add(key);
            return true;
        }
        return false;
    }).map(function(d) {
        // Get the right stigma score cutoff based on type
        var stigmaScoreCutoff = d.stigmaType === 'अपेक्षित लान्छना' ? 12 // as_score >= 12
         : d.stigmaType === 'व्यावहारिक लान्छना' ? 4 // es_score >= 4
         : 10; // is_score >= 10 (for आत्मलान्छना)
        // cutoff values for dimensions (clinical thresholds for color)
        var dimensionClinicalCutoff = d.stigmaType === 'अपेक्षित लान्छना' ? 40 : d.stigmaType === 'व्यावहारिक लान्छना' ? 43 : 33;
        // display denominators for dimensions (shown in UI)
        var dimensionDisplayDenominator = d.stigmaType === 'अपेक्षित लान्छना' ? 120 : d.stigmaType === 'व्यावहारिक लान्छना' ? 130 : 100;
        // Clinical cutoff values for intersectional stigma (for matching logic only)
        var intersectionalCutoff = d.stigmaType === 'अपेक्षित लान्छना' ? 80 : d.stigmaType === 'व्यावहारिक लान्छना' ? 86 : 66;
        // Display denominators for intersectional stigma (shown in UI)
        var intersectionalDisplayDenominator = d.stigmaType === 'अपेक्षित लान्छना' ? 240 : d.stigmaType === 'व्यावहारिक लान्छना' ? 260 : 200;
        var _d_hiv_domain_as, _ref, _d_mh_domain_as, _ref1, _d_sgm_domain_as, _ref2, _d_em_domain_as, _ref3;
        // build JSX fragment with colored domains
        var dimensionScoreRender = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().createElement("div", {
            style: {
                display: 'flex',
                flexDirection: 'column',
                marginBottom: '-4px'
            }
        }, renderColoredValue('एचआईभी', (_ref = (_d_hiv_domain_as = d.hiv_domain_as) !== null && _d_hiv_domain_as !== void 0 ? _d_hiv_domain_as : d.hiv_domain_es) !== null && _ref !== void 0 ? _ref : d.hiv_domain_is, dimensionDisplayDenominator, dimensionClinicalCutoff), renderColoredValue('मानसिक स्वास्थ्य', (_ref1 = (_d_mh_domain_as = d.mh_domain_as) !== null && _d_mh_domain_as !== void 0 ? _d_mh_domain_as : d.mh_domain_es) !== null && _ref1 !== void 0 ? _ref1 : d.mh_domain_is, dimensionDisplayDenominator, dimensionClinicalCutoff), renderColoredValue('लैङ्गिक तथा यौनिक अल्पसङ्ख्यक', (_ref2 = (_d_sgm_domain_as = d.sgm_domain_as) !== null && _d_sgm_domain_as !== void 0 ? _d_sgm_domain_as : d.sgm_domain_es) !== null && _ref2 !== void 0 ? _ref2 : d.sgm_domain_is, dimensionDisplayDenominator, dimensionClinicalCutoff), renderColoredValue('जातीय अल्पसङ्ख्यक/दलित', (_ref3 = (_d_em_domain_as = d.em_domain_as) !== null && _d_em_domain_as !== void 0 ? _d_em_domain_as : d.em_domain_es) !== null && _ref3 !== void 0 ? _ref3 : d.em_domain_is, dimensionDisplayDenominator, dimensionClinicalCutoff));
        // build JSX for stigma score - showing colored score based on stigma type
        var stigmaScoreValue = d.stigmaType === 'अपेक्षित लान्छना' ? d.as_score : d.stigmaType === 'व्यावहारिक लान्छना' ? d.es_score : d.is_score;
        // determine display denominator per stigma type (these are the totals shown in UI)
        var displayDenominator = d.stigmaType === 'अपेक्षित लान्छना' ? 36 : d.stigmaType === 'व्यावहारिक लान्छना' ? 13 : 30;
        var stigmaScoreRender = renderScoreOnly(String(d.stigmaScore), stigmaScoreValue, displayDenominator, stigmaScoreCutoff);
        var _d_intersectional_stigma_as, _ref4;
        // build JSX for intersectional score - always showing the number with conditional color
        var intersectionalRender = renderIntersectionalScore((_ref4 = (_d_intersectional_stigma_as = d.intersectional_stigma_as) !== null && _d_intersectional_stigma_as !== void 0 ? _d_intersectional_stigma_as : d.intersectional_stigma_es) !== null && _ref4 !== void 0 ? _ref4 : d.intersectional_stigma_is, intersectionalCutoff, intersectionalDisplayDenominator);
        return {
            id: d.id,
            date: d.date,
            temperatureRender: d.stigmaType || '',
            bloodPressureRender: stigmaScoreRender,
            pulseRender: d.dimensionType || '',
            respiratoryRateRender: dimensionScoreRender,
            spo2Render: intersectionalRender,
            dateRender: d.date ? new Date(d.date).toLocaleDateString() : '',
            temperatureRenderInterpretation: undefined,
            bloodPressureRenderInterpretation: undefined,
            pulseRenderInterpretation: undefined,
            respiratoryRateRenderInterpretation: undefined,
            spo2RenderInterpretation: undefined
        };
    });
}
/* ---------------- Activities logic (LATEST ENCOUNTER ONLY) ---------------- */ function getActivitiesBasedOnStigma(stigmaData) {
    var _computeStigmaMatch_LatestOnly = computeStigmaMatch_LatestOnly(stigmaData), matched = _computeStigmaMatch_LatestOnly.matched, latestEncounterUuid = _computeStigmaMatch_LatestOnly.latestEncounterUuid;
    // Force remount when latest encounter changes or match flips
    var renderKey = "act:".concat(latestEncounterUuid !== null && latestEncounterUuid !== void 0 ? latestEncounterUuid : 'none', ":").concat(matched ? '1' : '0');
    // const showHivGuidelines = shouldShowHivGuidelines(stigmaData);
    var cardStyle = {
        backgroundColor: '#e9f5ff',
        border: '1px solid #2f80ed',
        borderRadius: 8,
        padding: '1rem',
        marginBottom: '1rem',
        boxShadow: '0 1px 4px rgba(0,0,0,0.08)',
        maxWidth: '100%',
        wordWrap: 'break-word'
    };
    var headingStyle = {
        fontSize: '1.15rem',
        fontWeight: 700,
        textAlign: 'center',
        color: '#0b3d91',
        marginBottom: '.5rem'
    };
    var listStyle = {
        paddingLeft: '1.1rem',
        lineHeight: 1.6,
        marginBottom: '.4rem'
    };
    return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().createElement("div", {
        key: renderKey,
        style: {
            width: '100%',
            boxSizing: 'border-box'
        }
    }, matched ? /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().createElement((react__WEBPACK_IMPORTED_MODULE_1___default().Fragment), null, /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().createElement("div", {
        style: cardStyle
    }, /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().createElement("h4", {
        style: _object_spread_props(_object_spread({}, headingStyle), {
            fontWeight: 'bold'
        })
    }, "एचआईभी संक्रमित व्यक्तिहरूको आत्मसक्षमता र आत्मसम्मान बढाउने परामर्श", ' '), /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().createElement("span", {
        style: {
            fontStyle: 'italic'
        }
    }, "एचआईभी संक्रमित व्यक्तिहरूलाई आत्मसक्षमता र आत्मसम्मान बढाउनको लागि तल दिईएका बुदाँहरु प्रयोग गरि परामर्श दिनुहोस्।"), ' ', /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().createElement("br", null), /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().createElement("br", null), /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().createElement("ul", {
        style: {
            color: '#333',
            fontWeight: '500',
            lineHeight: '1.6',
            paddingLeft: '20px'
        }
    }, /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().createElement("li", null, "o कुराकानी गर्दा खुल्ला प्रश्नहरु सोध्नुहोस्, ध्यान दिएर सुन्नुहोस् र उनीहरूले भनेको कुरालाई मनन गर्दै जवाफ दिनुहोस्।"), /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().createElement("li", null, "o एचआईभी संक्रमित व्यक्तिहरूको आत्मविश्वास र आत्मसम्मान बढाउन सहयोग गर्नुहोस्।"), /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().createElement("li", null, "o एचआईभी संक्रमित व्यक्तिहरूको एआरटि, उपचारको नियमित पालना, र मानसिक स्वास्थ्य सम्बन्धी अनुभव र सोचबारे छलफल गर्नुहोस्।"), /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().createElement("li", null, "o एचआईभी संक्रमित व्यक्तिहरूले हाल प्रयोग गरिरहेका वा थाहा पाएका सामना गर्ने तरिकाहरूको बारेमा कुरा गर्नुहोस्।"), /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().createElement("li", null, "o संक्षेपमा कुरा राखेर थप सामना गर्ने तरिकाहरू बारे बताउनुहोस्।")), /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().createElement("br", null)), /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().createElement("br", null), /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().createElement("br", null), /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().createElement("div", {
        style: cardStyle
    }, /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().createElement("p", {
        style: {
            fontWeight: 'bold',
            color: '#222',
            paddingLeft: '20px'
        }
    }, "श्रोतहरु:"), /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().createElement("span", {
        style: {
            fontStyle: 'italic',
            paddingLeft: '20px'
        }
    }, "थप जानकारीको लागि तल दिईएका श्रोतहरु सेयर गर्नुहोस्।"), /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().createElement("br", null), /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().createElement("br", null), /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().createElement("ul", {
        style: {
            color: '#333',
            fontWeight: '500',
            lineHeight: '1.6',
            listStyle: 'none',
            paddingLeft: '20px'
        }
    }, /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().createElement("li", {
        style: {
            marginBottom: '2rem'
        }
    }, /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().createElement("span", {
        style: {
            display: 'block',
            marginBottom: '0.5rem'
        }
    }, "१. एचआइभी सम्बन्धि जनचेतना"), /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().createElement(QRCodeWithPopup, {
        image: _common_img_QR1_HIV_awareness_NAPN_png__WEBPACK_IMPORTED_MODULE_2__,
        alt: "HIV Awareness"
    })), /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().createElement("li", {
        style: {
            marginBottom: '2rem'
        }
    }, /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().createElement("span", {
        style: {
            display: 'block',
            marginBottom: '0.5rem'
        }
    }, "२. मानसिक स्वास्थ्य (डरको व्यवस्थापन)"), /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().createElement(QRCodeWithPopup, {
        image: _common_img_QR2_TPO_Managing_fear_png__WEBPACK_IMPORTED_MODULE_3__,
        alt: "TPO"
    })), /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().createElement("li", {
        style: {
            marginBottom: '2rem'
        }
    }, /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().createElement("span", {
        style: {
            display: 'block',
            marginBottom: '0.5rem'
        }
    }, "३. लैङ्गिक तथा यौनिक अल्पसङ्ख्यकको लागि जानकारी"), /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().createElement(QRCodeWithPopup, {
        image: _common_img_QR3_BDS_Ideal_World_png__WEBPACK_IMPORTED_MODULE_4__,
        alt: "BDS"
    })), /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().createElement("li", {
        style: {
            marginBottom: '2rem'
        }
    }, /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().createElement("span", {
        style: {
            display: 'block',
            marginBottom: '0.5rem'
        }
    }, "४. उपचार पालना सम्बन्धि जनचेतना"), /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().createElement(QRCodeWithPopup, {
        image: _common_img_QR4_Treatment_adherence_video_NCASC_png__WEBPACK_IMPORTED_MODULE_5__,
        alt: "Treatment Adherence"
    })))), /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().createElement("br", null), /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().createElement("br", null), /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().createElement("div", {
        style: cardStyle
    }, /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().createElement("h4", {
        style: _object_spread_props(_object_spread({}, headingStyle), {
            fontWeight: 'bold'
        })
    }, "सपोर्ट ग्रुपको सूची"), /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().createElement("span", {
        style: {
            fontStyle: 'italic',
            paddingLeft: '20px'
        }
    }, "यदि सहभागी सपोर्ट ग्रुपमा सामेल सहमत भएमा तल दिईएको जानकारी सेयर गर्नुहोस्।"), /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().createElement("br", null), /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().createElement("br", null), /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().createElement("table", {
        style: {
            width: '100%',
            borderCollapse: 'collapse',
            lineHeight: '1.6'
        }
    }, /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().createElement("tbody", null, /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().createElement("tr", null, /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().createElement("td", null, "५. ड्रप-इन सेन्टर"), /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().createElement("td", null, "स्वतन्त्र पथ, बुटवल, रूपन्देही"), /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().createElement("td", null, "msmgnepal@gmail.com, ०७१-५२४८६२")), /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().createElement("tr", null, /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().createElement("td", null, "६. ड्रप-इन सेन्टर"), /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().createElement("td", null, "मुर्ली बगैचा, वीरगञ्ज, पर्सा"), /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().createElement("td", null, "parsachemsexdic@gmail.com, ०५१-५२८६०६")), /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().createElement("tr", null, /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().createElement("td", null, "७. ड्रप-इन सेन्टर"), /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().createElement("td", null, "नील सरस्वतीथान, खुरसानिटार, काठमाडौं"), /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().createElement("td", null, "cruiseaids@gmail.com, ०१-४४२४०५२")), /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().createElement("tr", null, /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().createElement("td", null, "८. एनएपि+एन"), /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().createElement("td", null, "बालुवाटार, काठमाडौं"), /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().createElement("td", null, "info@napn.org.np, ०१-४५२७४५९")), /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().createElement("tr", null, /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().createElement("td", null, "९. एनएफडब्लुएलएचए"), /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().createElement("td", null, "नयाँ बानेश्वर, काठमाडौं"), /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().createElement("td", null, "nfwlha007@gmail.com, ०१-४५९९३७५")))), /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().createElement("br", null), /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().createElement("p", {
        style: {
            color: 'blue',
            fontWeight: 'bold',
            textAlign: 'center'
        }
    }, "कृपया सहभागीको कुरा सक्रिय रुपमा सुन्नुहोला।"))) : /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().createElement("div", {
        style: cardStyle
    }, /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().createElement("h4", {
        style: _object_spread_props(_object_spread({}, headingStyle), {
            fontWeight: 'bold'
        })
    }, "सामान्य परामर्श "), /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().createElement("span", {
        style: {
            fontStyle: 'italic'
        }
    }, "कृपया सहभागीलाई सामान्य परामर्श प्रदान गर्नुहोस्।"), " ", /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().createElement("br", null), /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().createElement("ul", {
        style: {
            color: '#333',
            fontWeight: '500',
            lineHeight: '1.6',
            paddingLeft: '20px'
        }
    }, /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().createElement("li", null, ' ', "o एचआईभी संक्रमित व्यक्तिहरूसँग एआरटी, उपचारको पालना, र मानसिक स्वास्थ्यसम्बन्धी अनुभव र सोचबारे खुला प्रश्नहरू प्रयोग गरेर कुराकानी गर्नुहोस्।"), /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().createElement("li", null, "o उनीहरूले भोगेका भावना र चुनौतीहरूलाई महत्व दिनुहोस्।"))));
}
/* ---------------- Helpers ---------------- */ function safeParse(val) {
    if (val === undefined || val === null || String(val).trim() === '') return 0;
    if (typeof val === 'number') return val;
    var cleaned = String(val).trim().replace(/[^\d.\-]/g, '');
    var n = parseFloat(cleaned);
    return Number.isFinite(n) ? n : 0;
}
function parseDimensionString(dimScore) {
    var result = {
        hiv: 0,
        mh: 0,
        sgm: 0,
        em: 0
    };
    if (dimScore === undefined || dimScore === null) return result;
    var str = Array.isArray(dimScore) ? dimScore.join(',') : String(dimScore);
    str.split(',').forEach(function(part) {
        var _part_split = _sliced_to_array(part.split(':'), 2), kRaw = _part_split[0], vRaw = _part_split[1];
        if (!kRaw) return;
        var key = kRaw.trim().toLowerCase();
        var token = String(vRaw !== null && vRaw !== void 0 ? vRaw : '0').trim().match(/-?\d+(?:\.\d+)?/);
        var n = token ? parseFloat(token[0]) : 0;
        if (key.startsWith('hiv')) result.hiv = n;
        else if (key.startsWith('mh')) result.mh = n;
        else if (key.startsWith('sgm')) result.sgm = n;
        else if (key.startsWith('em')) result.em = n;
    });
    return result;
}
/**
 * Only evaluate the **latest encounter**:
 * - find the max encounterDatetime
 * - collect all stigma rows with that same encounterUuid
 * - check thresholds on those rows only
 */ function computeStigmaMatch_LatestOnly(stigmaData) {
    if (!stigmaData || stigmaData.length === 0) return {
        matched: false
    };
    // Find latest by date
    var latest = stigmaData.reduce(function(acc, cur) {
        var accT = Date.parse(acc.date || '') || 0;
        var curT = Date.parse(cur.date || '') || 0;
        return curT > accT ? cur : acc;
    });
    var latestEncounterUuid = latest.encounterUuid;
    var current = stigmaData.filter(function(d) {
        return d.encounterUuid === latestEncounterUuid;
    });
    var _iteratorNormalCompletion = true, _didIteratorError = false, _iteratorError = undefined;
    try {
        for(var _iterator = current[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true){
            var entry = _step.value;
            var score = entry.stigmaType === 'अपेक्षित लान्छना' && typeof entry.as_score === 'number' ? entry.as_score : entry.stigmaType === 'व्यावहारिक लान्छना' && typeof entry.es_score === 'number' ? entry.es_score : entry.stigmaType === 'आत्मलान्छना' && typeof entry.is_score === 'number' ? entry.is_score : safeParse(entry.stigmaScore);
            var dims = parseDimensionString(entry.dimensionScore);
            var _entry_hiv_domain_as, _ref, _ref1;
            var hiv = (_ref1 = (_ref = (_entry_hiv_domain_as = entry.hiv_domain_as) !== null && _entry_hiv_domain_as !== void 0 ? _entry_hiv_domain_as : entry.hiv_domain_es) !== null && _ref !== void 0 ? _ref : entry.hiv_domain_is) !== null && _ref1 !== void 0 ? _ref1 : dims.hiv;
            var _entry_mh_domain_as, _ref2, _ref3;
            var mh = (_ref3 = (_ref2 = (_entry_mh_domain_as = entry.mh_domain_as) !== null && _entry_mh_domain_as !== void 0 ? _entry_mh_domain_as : entry.mh_domain_es) !== null && _ref2 !== void 0 ? _ref2 : entry.mh_domain_is) !== null && _ref3 !== void 0 ? _ref3 : dims.mh;
            var _entry_sgm_domain_as, _ref4, _ref5;
            var sgm = (_ref5 = (_ref4 = (_entry_sgm_domain_as = entry.sgm_domain_as) !== null && _entry_sgm_domain_as !== void 0 ? _entry_sgm_domain_as : entry.sgm_domain_es) !== null && _ref4 !== void 0 ? _ref4 : entry.sgm_domain_is) !== null && _ref5 !== void 0 ? _ref5 : dims.sgm;
            var _entry_em_domain_as, _ref6, _ref7;
            var em = (_ref7 = (_ref6 = (_entry_em_domain_as = entry.em_domain_as) !== null && _entry_em_domain_as !== void 0 ? _entry_em_domain_as : entry.em_domain_es) !== null && _ref6 !== void 0 ? _ref6 : entry.em_domain_is) !== null && _ref7 !== void 0 ? _ref7 : dims.em;
            var _entry_intersectional_stigma_as, _ref8, _ref9;
            var inter = (_ref9 = (_ref8 = (_entry_intersectional_stigma_as = entry.intersectional_stigma_as) !== null && _entry_intersectional_stigma_as !== void 0 ? _entry_intersectional_stigma_as : entry.intersectional_stigma_es) !== null && _ref8 !== void 0 ? _ref8 : entry.intersectional_stigma_is) !== null && _ref9 !== void 0 ? _ref9 : safeParse(entry.intersectionalScore);
            // thresholds
            if (entry.stigmaType === 'अपेक्षित लान्छना' && score >= 12 && (hiv >= 40 || mh >= 40 || sgm >= 40 || em >= 40 || inter >= 80)) {
                return {
                    matched: true,
                    latestEncounterUuid: latestEncounterUuid
                };
            }
            if (entry.stigmaType === 'व्यावहारिक लान्छना' && score >= 4 && (hiv >= 43 || mh >= 43 || sgm >= 43 || em >= 43 || inter >= 86)) {
                return {
                    matched: true,
                    latestEncounterUuid: latestEncounterUuid
                };
            }
            if (entry.stigmaType === 'आत्मलान्छना' && score >= 10 && (hiv >= 33 || mh >= 33 || sgm >= 33 || em >= 33 || inter >= 66)) {
                return {
                    matched: true,
                    latestEncounterUuid: latestEncounterUuid
                };
            }
        }
    } catch (err) {
        _didIteratorError = true;
        _iteratorError = err;
    } finally{
        try {
            if (!_iteratorNormalCompletion && _iterator.return != null) {
                _iterator.return();
            }
        } finally{
            if (_didIteratorError) {
                throw _iteratorError;
            }
        }
    }
    return {
        matched: false,
        latestEncounterUuid: latestEncounterUuid
    };
}
function preprocessStigmaTrendsAll(data) {
    if (!data || data.length === 0) {
        return {
            labels: [],
            anticipated: [],
            enacted: [],
            internalized: []
        };
    }
    // 🔸 Sort by date
    var sorted = _to_consumable_array(data).sort(function(a, b) {
        return new Date(a.date).getTime() - new Date(b.date).getTime();
    });
    var labels = [];
    var anticipated = [];
    var enacted = [];
    var internalized = [];
    sorted.forEach(function(item) {
        labels.push(formatDate(item.date)); // nice label like 14 Sep 2025
        var _item_as_score;
        anticipated.push((_item_as_score = item.as_score) !== null && _item_as_score !== void 0 ? _item_as_score : null);
        var _item_es_score;
        enacted.push((_item_es_score = item.es_score) !== null && _item_es_score !== void 0 ? _item_es_score : null);
        var _item_is_score;
        internalized.push((_item_is_score = item.is_score) !== null && _item_is_score !== void 0 ? _item_is_score : null);
    });
    return {
        labels: labels,
        anticipated: anticipated,
        enacted: enacted,
        internalized: internalized
    };
}
function formatDate(dateStr) {
    var d = new Date(dateStr);
    return d.toLocaleDateString('default', {
        day: '2-digit',
        month: 'short',
        year: 'numeric'
    });
} // export function calculateStigmaTypeTrends(stigmaData: CovidStigmaData[] | undefined, periodInMonths: number = 12) {
 //   console.log('calculateStigmaTypeTrends called with:', {
 //     dataLength: stigmaData?.length,
 //     periodInMonths,
 //     sampleData: stigmaData?.slice(0, 3)
 //   });
 //   if (!stigmaData || stigmaData.length === 0) {
 //     console.log('No stigma data provided, returning empty chart data');
 //     return {
 //       months: [],
 //       trends: {},
 //       chartData: {
 //         labels: [],
 //         datasets: [],
 //       },
 //     };
 //   }
 //   // Step 1: Generate month labels for the specified period
 //   const now = new Date();
 //   const months: string[] = [];
 //   for (let i = periodInMonths - 1; i >= 0; i--) {
 //     const d = new Date(now);
 //     d.setMonth(d.getMonth() - i);
 //     const monthYear = `${d.toLocaleString('default', { month: 'short' })} ${d.getFullYear()}`;
 //     months.push(monthYear);
 //   }
 //   // Step 2: Initialize data structure for trends
 //   const trends = {
 //     anticipated: {} as Record<string, { count: number; sum: number; avg: number | null }>,
 //     enacted: {} as Record<string, { count: number; sum: number; avg: number | null }>,
 //     internalized: {} as Record<string, { count: number; sum: number; avg: number | null }>,
 //   };
 //   // Initialize each month with zero values
 //   months.forEach((month) => {
 //     trends.anticipated[month] = { count: 0, sum: 0, avg: null };
 //     trends.enacted[month] = { count: 0, sum: 0, avg: null };
 //     trends.internalized[month] = { count: 0, sum: 0, avg: null };
 //   });
 //   // Step 3: Process each data point
 //   let processedCount = 0;
 //   let skippedNoDate = 0;
 //   let skippedOutOfRange = 0;
 //   let dataWithScores = 0;
 //   stigmaData.forEach((data) => {
 //     if (!data.date) {
 //       skippedNoDate++;
 //       return;
 //     }
 //     const date = new Date(data.date);
 //     const monthsAgo = (now.getFullYear() - date.getFullYear()) * 12 + now.getMonth() - date.getMonth();
 //     // Skip data outside our time period
 //     if (monthsAgo < 0 || monthsAgo >= periodInMonths) {
 //       skippedOutOfRange++;
 //       return;
 //     }
 //     processedCount++;
 //     if (data.as_score !== undefined || data.es_score !== undefined || data.is_score !== undefined) {
 //       dataWithScores++;
 //     }
 //     const monthYear = `${date.toLocaleString('default', { month: 'short' })} ${date.getFullYear()}`;
 //     // Update anticipated stigma data
 //     if (data.as_score !== undefined) {
 //       trends.anticipated[monthYear].count++;
 //       trends.anticipated[monthYear].sum += data.as_score;
 //       trends.anticipated[monthYear].avg = trends.anticipated[monthYear].sum / trends.anticipated[monthYear].count;
 //     }
 //     // Update enacted stigma data
 //     if (data.es_score !== undefined) {
 //       trends.enacted[monthYear].count++;
 //       trends.enacted[monthYear].sum += data.es_score;
 //       trends.enacted[monthYear].avg = trends.enacted[monthYear].sum / trends.enacted[monthYear].count;
 //     }
 //     // Update internalized stigma data
 //     if (data.is_score !== undefined) {
 //       trends.internalized[monthYear].count++;
 //       trends.internalized[monthYear].sum += data.is_score;
 //       trends.internalized[monthYear].avg = trends.internalized[monthYear].sum / trends.internalized[monthYear].count;
 //     }
 //   });
 //   // Step 4: Prepare chart-ready data format
 //   const chartData = {
 //     labels: months,
 //     datasets: [
 //       {
 //         label: 'Anticipated Stigma (अपेक्षित लान्छना)',
 //         data: months.map((month) => trends.anticipated[month].avg || null),
 //         borderColor: '#1f77b4', // blue
 //         backgroundColor: 'rgba(31, 119, 180, 0.2)',
 //       },
 //       {
 //         label: 'Enacted Stigma (व्यावहारिक लान्छना)',
 //         data: months.map((month) => trends.enacted[month].avg || null),
 //         borderColor: '#ff7f0e', // orange
 //         backgroundColor: 'rgba(255, 127, 14, 0.2)',
 //       },
 //       {
 //         label: 'Internalized Stigma (आत्मलान्छना)',
 //         data: months.map((month) => trends.internalized[month].avg || null),
 //         borderColor: '#2ca02c', // green
 //         backgroundColor: 'rgba(44, 160, 44, 0.2)',
 //       },
 //     ],
 //   };
 //   console.log('Stigma data processing summary:', {
 //     totalProcessed: processedCount,
 //     skippedNoDate,
 //     skippedOutOfRange,
 //     dataWithScores,
 //     monthsGenerated: months.length,
 //     anticipatedDataPoints: months.filter(month => trends.anticipated[month].avg !== null).length,
 //     enactedDataPoints: months.filter(month => trends.enacted[month].avg !== null).length,
 //     internalizedDataPoints: months.filter(month => trends.internalized[month].avg !== null).length,
 //     chartLabels: chartData.labels.length,
 //     anticipatedValues: chartData.datasets[0].data.filter(val => val !== null).length,
 //     enactedValues: chartData.datasets[1].data.filter(val => val !== null).length,
 //     internalizedValues: chartData.datasets[2].data.filter(val => val !== null).length
 //   });
 //   return {
 //     months,
 //     trends,
 //     chartData,
 //   };
 // }


/***/ }),

/***/ "./src/common/data-utils.ts":
/*!**********************************!*\
  !*** ./src/common/data-utils.ts ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   adjustForNepaliTimezone: () => (/* binding */ adjustForNepaliTimezone),
/* harmony export */   calculateObservationStats: () => (/* binding */ calculateObservationStats),
/* harmony export */   extractNumericValue: () => (/* binding */ extractNumericValue),
/* harmony export */   filterObservationsByDateRange: () => (/* binding */ filterObservationsByDateRange),
/* harmony export */   getMostRecentObservation: () => (/* binding */ getMostRecentObservation),
/* harmony export */   groupObservationsByConcept: () => (/* binding */ groupObservationsByConcept),
/* harmony export */   parseOpenMRSDate: () => (/* binding */ parseOpenMRSDate)
/* harmony export */ });
/**
 * Utilities for processing patient data for analytics
 */ // Convert OpenMRS date format to local date object
function _array_like_to_array(arr, len) {
    if (len == null || len > arr.length) len = arr.length;
    for(var i = 0, arr2 = new Array(len); i < len; i++)arr2[i] = arr[i];
    return arr2;
}
function _array_without_holes(arr) {
    if (Array.isArray(arr)) return _array_like_to_array(arr);
}
function _iterable_to_array(iter) {
    if (typeof Symbol !== "undefined" && iter[Symbol.iterator] != null || iter["@@iterator"] != null) return Array.from(iter);
}
function _non_iterable_spread() {
    throw new TypeError("Invalid attempt to spread non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _to_consumable_array(arr) {
    return _array_without_holes(arr) || _iterable_to_array(arr) || _unsupported_iterable_to_array(arr) || _non_iterable_spread();
}
function _unsupported_iterable_to_array(o, minLen) {
    if (!o) return;
    if (typeof o === "string") return _array_like_to_array(o, minLen);
    var n = Object.prototype.toString.call(o).slice(8, -1);
    if (n === "Object" && o.constructor) n = o.constructor.name;
    if (n === "Map" || n === "Set") return Array.from(n);
    if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _array_like_to_array(o, minLen);
}
function parseOpenMRSDate(dateString) {
    if (!dateString) return null;
    try {
        var date = new Date(dateString);
        // Check if date is valid
        if (isNaN(date.getTime())) return null;
        return date;
    } catch (e) {
        console.error('Error parsing date', e);
        return null;
    }
}
// Adjust date for Nepali Time (UTC+5:45)
function adjustForNepaliTimezone(date) {
    if (!date) return date;
    var offsetInMs = 5 * 60 * 60 * 1000 + 45 * 60 * 1000;
    return new Date(date.getTime() + offsetInMs);
}
// Extract numeric value from OpenMRS observation display string
function extractNumericValue(displayString) {
    if (!displayString) return null;
    var valueMatch = displayString.match(/\d+(\.\d+)?/);
    if (valueMatch) {
        return parseFloat(valueMatch[0]);
    }
    return null;
}
// Group patients observations by concept (display label)
function groupObservationsByConcept(patientObservations) {
    var groupedObservations = {};
    patientObservations.forEach(function(obs) {
        if (!obs.display) return;
        // Extract the concept name from the display string
        // Format is typically "Concept Name: Value"
        var conceptMatch = obs.display.match(/^([^:]+):/);
        if (conceptMatch) {
            var conceptName = conceptMatch[1].trim();
            if (!groupedObservations[conceptName]) {
                groupedObservations[conceptName] = [];
            }
            groupedObservations[conceptName].push(obs);
        }
    });
    return groupedObservations;
}
// Get the most recent observation for a concept
function getMostRecentObservation(observations, conceptLabel) {
    if (!observations || observations.length === 0) return null;
    var mostRecent = null;
    var mostRecentDate = null;
    observations.forEach(function(obs) {
        var _obs_display;
        if ((_obs_display = obs.display) === null || _obs_display === void 0 ? void 0 : _obs_display.includes(conceptLabel)) {
            var date = parseOpenMRSDate(obs.effectiveDateTime || obs.date);
            if (!mostRecentDate || date && date > mostRecentDate) {
                mostRecentDate = date;
                mostRecent = obs;
            }
        }
    });
    return mostRecent;
}
// Calculate statistics for numeric observations
function calculateObservationStats(observations, conceptLabel) {
    var _Math, _Math1;
    if (!observations || observations.length === 0) {
        return {
            min: null,
            max: null,
            avg: null,
            count: 0
        };
    }
    var values = [];
    observations.forEach(function(obs) {
        var _obs_display;
        if ((_obs_display = obs.display) === null || _obs_display === void 0 ? void 0 : _obs_display.includes(conceptLabel)) {
            var value = extractNumericValue(obs.display);
            if (value !== null) {
                values.push(value);
            }
        }
    });
    if (values.length === 0) {
        return {
            min: null,
            max: null,
            avg: null,
            count: 0
        };
    }
    var min = (_Math = Math).min.apply(_Math, _to_consumable_array(values));
    var max = (_Math1 = Math).max.apply(_Math1, _to_consumable_array(values));
    var sum = values.reduce(function(a, b) {
        return a + b;
    }, 0);
    var avg = sum / values.length;
    return {
        min: min,
        max: max,
        avg: avg,
        count: values.length
    };
}
// Filter observations by date range
function filterObservationsByDateRange(observations, startDate, endDate) {
    return observations.filter(function(obs) {
        var obsDate = parseOpenMRSDate(obs.effectiveDateTime || obs.date);
        if (!obsDate) return false;
        return obsDate >= startDate && obsDate <= endDate;
    });
}


/***/ }),

/***/ "./src/common/data.resource.ts":
/*!*************************************!*\
  !*** ./src/common/data.resource.ts ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   createOrUpdateVitalsAndBiometrics: () => (/* binding */ createOrUpdateVitalsAndBiometrics),
/* harmony export */   deleteEncounter: () => (/* binding */ deleteEncounter),
/* harmony export */   invalidateCachedVitalsAndBiometrics: () => (/* binding */ invalidateCachedVitalsAndBiometrics),
/* harmony export */   useConceptUnits: () => (/* binding */ useConceptUnits),
/* harmony export */   useEncounterVitalsAndBiometrics: () => (/* binding */ useEncounterVitalsAndBiometrics),
/* harmony export */   useVitalsAndBiometrics: () => (/* binding */ useVitalsAndBiometrics),
/* harmony export */   useVitalsConceptMetadata: () => (/* binding */ useVitalsConceptMetadata),
/* harmony export */   useVitalsOrBiometricsConcepts: () => (/* binding */ useVitalsOrBiometricsConcepts),
/* harmony export */   withUnit: () => (/* binding */ withUnit)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @openmrs/esm-framework */ "webpack/sharing/consume/default/@openmrs/esm-framework/@openmrs/esm-framework");
/* harmony import */ var _openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var swr_immutable__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! swr/immutable */ "webpack/sharing/consume/default/swr/immutable/swr/immutable");
/* harmony import */ var swr_immutable__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(swr_immutable__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var swr_infinite__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! swr/infinite */ "webpack/sharing/consume/default/swr/infinite/swr/infinite");
/* harmony import */ var swr_infinite__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(swr_infinite__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _helpers__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./helpers */ "./src/common/helpers.ts");
function _array_like_to_array(arr, len) {
    if (len == null || len > arr.length) len = arr.length;
    for(var i = 0, arr2 = new Array(len); i < len; i++)arr2[i] = arr[i];
    return arr2;
}
function _array_with_holes(arr) {
    if (Array.isArray(arr)) return arr;
}
function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) {
    try {
        var info = gen[key](arg);
        var value = info.value;
    } catch (error) {
        reject(error);
        return;
    }
    if (info.done) {
        resolve(value);
    } else {
        Promise.resolve(value).then(_next, _throw);
    }
}
function _async_to_generator(fn) {
    return function() {
        var self = this, args = arguments;
        return new Promise(function(resolve, reject) {
            var gen = fn.apply(self, args);
            function _next(value) {
                asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value);
            }
            function _throw(err) {
                asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err);
            }
            _next(undefined);
        });
    };
}
function _define_property(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
function _iterable_to_array_limit(arr, i) {
    var _i = arr == null ? null : typeof Symbol !== "undefined" && arr[Symbol.iterator] || arr["@@iterator"];
    if (_i == null) return;
    var _arr = [];
    var _n = true;
    var _d = false;
    var _s, _e;
    try {
        for(_i = _i.call(arr); !(_n = (_s = _i.next()).done); _n = true){
            _arr.push(_s.value);
            if (i && _arr.length === i) break;
        }
    } catch (err) {
        _d = true;
        _e = err;
    } finally{
        try {
            if (!_n && _i["return"] != null) _i["return"]();
        } finally{
            if (_d) throw _e;
        }
    }
    return _arr;
}
function _non_iterable_rest() {
    throw new TypeError("Invalid attempt to destructure non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _object_spread(target) {
    for(var i = 1; i < arguments.length; i++){
        var source = arguments[i] != null ? arguments[i] : {};
        var ownKeys = Object.keys(source);
        if (typeof Object.getOwnPropertySymbols === "function") {
            ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function(sym) {
                return Object.getOwnPropertyDescriptor(source, sym).enumerable;
            }));
        }
        ownKeys.forEach(function(key) {
            _define_property(target, key, source[key]);
        });
    }
    return target;
}
function ownKeys(object, enumerableOnly) {
    var keys = Object.keys(object);
    if (Object.getOwnPropertySymbols) {
        var symbols = Object.getOwnPropertySymbols(object);
        if (enumerableOnly) {
            symbols = symbols.filter(function(sym) {
                return Object.getOwnPropertyDescriptor(object, sym).enumerable;
            });
        }
        keys.push.apply(keys, symbols);
    }
    return keys;
}
function _object_spread_props(target, source) {
    source = source != null ? source : {};
    if (Object.getOwnPropertyDescriptors) {
        Object.defineProperties(target, Object.getOwnPropertyDescriptors(source));
    } else {
        ownKeys(Object(source)).forEach(function(key) {
            Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key));
        });
    }
    return target;
}
function _sliced_to_array(arr, i) {
    return _array_with_holes(arr) || _iterable_to_array_limit(arr, i) || _unsupported_iterable_to_array(arr, i) || _non_iterable_rest();
}
function _unsupported_iterable_to_array(o, minLen) {
    if (!o) return;
    if (typeof o === "string") return _array_like_to_array(o, minLen);
    var n = Object.prototype.toString.call(o).slice(8, -1);
    if (n === "Object" && o.constructor) n = o.constructor.name;
    if (n === "Map" || n === "Set") return Array.from(n);
    if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _array_like_to_array(o, minLen);
}
function _ts_generator(thisArg, body) {
    var f, y, t, _ = {
        label: 0,
        sent: function() {
            if (t[0] & 1) throw t[1];
            return t[1];
        },
        trys: [],
        ops: []
    }, g = Object.create((typeof Iterator === "function" ? Iterator : Object).prototype);
    return g.next = verb(0), g["throw"] = verb(1), g["return"] = verb(2), typeof Symbol === "function" && (g[Symbol.iterator] = function() {
        return this;
    }), g;
    function verb(n) {
        return function(v) {
            return step([
                n,
                v
            ]);
        };
    }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while(g && (g = 0, op[0] && (_ = 0)), _)try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [
                op[0] & 2,
                t.value
            ];
            switch(op[0]){
                case 0:
                case 1:
                    t = op;
                    break;
                case 4:
                    _.label++;
                    return {
                        value: op[1],
                        done: false
                    };
                case 5:
                    _.label++;
                    y = op[1];
                    op = [
                        0
                    ];
                    continue;
                case 7:
                    op = _.ops.pop();
                    _.trys.pop();
                    continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
                        _ = 0;
                        continue;
                    }
                    if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
                        _.label = op[1];
                        break;
                    }
                    if (op[0] === 6 && _.label < t[1]) {
                        _.label = t[1];
                        t = op;
                        break;
                    }
                    if (t && _.label < t[2]) {
                        _.label = t[2];
                        _.ops.push(op);
                        break;
                    }
                    if (t[2]) _.ops.pop();
                    _.trys.pop();
                    continue;
            }
            op = body.call(thisArg, _);
        } catch (e) {
            op = [
                6,
                e
            ];
            y = 0;
        } finally{
            f = t = 0;
        }
        if (op[0] & 5) throw op[1];
        return {
            value: op[0] ? op[1] : void 0,
            done: true
        };
    }
}





var pageSize = 100;
/** We use this as the first value to the SWR key to be able to invalidate all relevant cached entries */ var swrKeyNeedle = Symbol('vitalsAndBiometrics');
var encounterRepresentation = 'custom:(uuid,encounterDatetime,encounterType:(uuid,display),obs:(uuid,concept:(uuid,display),value,interpretation))';
function getInterpretationKey(header) {
    // Reason for `Render` string is to match the column header in the table
    return "".concat(header, "RenderInterpretation");
}
function useVitalsConceptMetadata(patientUuid) {
    var _data_data;
    var _useConfig = (0,_openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_1__.useConfig)(), _useConfig_concepts = _useConfig.concepts, diastolicBloodPressureUuid = _useConfig_concepts.diastolicBloodPressureUuid, oxygenSaturationUuid = _useConfig_concepts.oxygenSaturationUuid, pulseUuid = _useConfig_concepts.pulseUuid, respiratoryRateUuid = _useConfig_concepts.respiratoryRateUuid, systolicBloodPressureUuid = _useConfig_concepts.systolicBloodPressureUuid, temperatureUuid = _useConfig_concepts.temperatureUuid;
    var apiUrl = "".concat(_openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_1__.restBaseUrl, "/conceptreferencerange/?patient=").concat(patientUuid, "&concept=").concat(systolicBloodPressureUuid, ",").concat(diastolicBloodPressureUuid, ",").concat(pulseUuid, ",").concat(temperatureUuid, ",").concat(oxygenSaturationUuid, ",").concat(respiratoryRateUuid, "&v=full");
    var _useSWRImmutable = swr_immutable__WEBPACK_IMPORTED_MODULE_2___default()(patientUuid ? apiUrl : null, _openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_1__.openmrsFetch), data = _useSWRImmutable.data, error = _useSWRImmutable.error, isLoading = _useSWRImmutable.isLoading;
    var conceptMetadata = data === null || data === void 0 ? void 0 : (_data_data = data.data) === null || _data_data === void 0 ? void 0 : _data_data.results;
    var conceptUnits = (conceptMetadata === null || conceptMetadata === void 0 ? void 0 : conceptMetadata.length) ? new Map(conceptMetadata.map(function(concept) {
        return [
            concept.uuid,
            concept.units
        ];
    })) : new Map([]);
    var conceptRanges = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(function() {
        return (conceptMetadata === null || conceptMetadata === void 0 ? void 0 : conceptMetadata.length) ? conceptMetadata.map(function(concept) {
            var _concept_hiNormal, _concept_hiAbsolute, _concept_hiCritical, _concept_lowNormal, _concept_lowAbsolute, _concept_lowCritical, _concept_units;
            return {
                uuid: concept.concept,
                display: concept.display,
                hiNormal: (_concept_hiNormal = concept.hiNormal) !== null && _concept_hiNormal !== void 0 ? _concept_hiNormal : null,
                hiAbsolute: (_concept_hiAbsolute = concept.hiAbsolute) !== null && _concept_hiAbsolute !== void 0 ? _concept_hiAbsolute : null,
                hiCritical: (_concept_hiCritical = concept.hiCritical) !== null && _concept_hiCritical !== void 0 ? _concept_hiCritical : null,
                lowNormal: (_concept_lowNormal = concept.lowNormal) !== null && _concept_lowNormal !== void 0 ? _concept_lowNormal : null,
                lowAbsolute: (_concept_lowAbsolute = concept.lowAbsolute) !== null && _concept_lowAbsolute !== void 0 ? _concept_lowAbsolute : null,
                lowCritical: (_concept_lowCritical = concept.lowCritical) !== null && _concept_lowCritical !== void 0 ? _concept_lowCritical : null,
                units: (_concept_units = concept.units) !== null && _concept_units !== void 0 ? _concept_units : null
            };
        }) : [];
    }, [
        conceptMetadata
    ]);
    var conceptRangeMap = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(function() {
        return new Map(conceptRanges.map(function(range) {
            return [
                range.uuid,
                range
            ];
        }));
    }, [
        conceptRanges
    ]);
    return {
        data: conceptUnits,
        error: error,
        isLoading: isLoading,
        conceptMetadata: conceptMetadata,
        conceptRanges: conceptRanges,
        conceptRangeMap: conceptRangeMap
    };
}
function useConceptUnits() {
    var _data_data;
    var concepts = (0,_openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_1__.useConfig)().concepts;
    var vitalSignsConceptSetUuid = concepts.vitalSignsConceptSetUuid;
    var customRepresentation = 'custom:(setMembers:(uuid,display,units))';
    var apiUrl = "".concat(_openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_1__.restBaseUrl, "/concept/").concat(vitalSignsConceptSetUuid, "?v=").concat(customRepresentation);
    var _useSWRImmutable = swr_immutable__WEBPACK_IMPORTED_MODULE_2___default()(apiUrl, _openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_1__.openmrsFetch), data = _useSWRImmutable.data, error = _useSWRImmutable.error, isLoading = _useSWRImmutable.isLoading;
    var conceptMetadata = data === null || data === void 0 ? void 0 : (_data_data = data.data) === null || _data_data === void 0 ? void 0 : _data_data.setMembers;
    var conceptUnits = (conceptMetadata === null || conceptMetadata === void 0 ? void 0 : conceptMetadata.length) ? new Map(conceptMetadata.map(function(concept) {
        return [
            concept.uuid,
            concept.units
        ];
    })) : new Map([]);
    return {
        conceptUnits: conceptUnits,
        error: error,
        isLoading: isLoading
    };
}
var withUnit = function(label, unit) {
    return "".concat(label, " ").concat(unit ? "(".concat(unit, ")") : '');
};
// We need to track a bound mutator for basically every hook, because there does not appear to be
// a way to invalidate an SWRInfinite key that works other than using the bound mutator
// Each mutator is stored in the vitalsHooksMutates map and removed (via a useEffect hook) when the
// hook is unmounted.
var vitalsHooksCounter = 0;
var vitalsHooksMutates = new Map();
/**
 * Hook to get concepts for vitals, biometrics or both
 */ function useVitalsOrBiometricsConcepts(mode) {
    var concepts = (0,_openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_1__.useConfig)().concepts;
    var conceptUuids = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(function() {
        var biometricsKeys = [
            'heightUuid',
            'midUpperArmCircumferenceUuid',
            'weightUuid'
        ];
        if (!concepts) {
            return [];
        }
        return Object.entries(concepts).filter(function(param) {
            var _param = _sliced_to_array(param, 2), key = _param[0], conceptUuid = _param[1];
            if (!conceptUuid) {
                console.warn("Missing UUID for concept ".concat(key));
                return false;
            }
            if (mode === 'both') {
                return true;
            }
            return mode === 'vitals' ? !biometricsKeys.includes(key) : biometricsKeys.includes(key);
        }).map(function(param) {
            var _param = _sliced_to_array(param, 2), _ = _param[0], conceptUuid = _param[1];
            return conceptUuid;
        });
    }, [
        concepts,
        mode
    ]);
    return conceptUuids;
}
/**
 * Hook to get the vitals and / or biometrics for a patient
 *
 * @param patientUuid The uuid of the patient to get the vitals for
 * @param mode Either 'vitals', to load only vitals, 'biometrics', to load only biometrics or 'both' to load both
 * @returns An SWR-like structure that includes the cleaned-up vitals
 */ function useVitalsAndBiometrics(patientUuid) {
    var mode = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : 'vitals';
    var _data__data_link, _data__data, _data__data1, _data_;
    var conceptUuids = useVitalsOrBiometricsConcepts(mode);
    var concepts = (0,_openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_1__.useConfig)().concepts;
    var conceptRanges = useVitalsConceptMetadata(patientUuid).conceptRanges;
    var getPage = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(function(page, prevPageData) {
        return {
            swrKeyNeedle: swrKeyNeedle,
            mode: mode,
            patientUuid: patientUuid,
            conceptUuids: conceptUuids.join(','),
            page: page,
            prevPageData: prevPageData
        };
    }, [
        mode,
        conceptUuids,
        patientUuid
    ]);
    var _useSWRInfinite = swr_infinite__WEBPACK_IMPORTED_MODULE_3___default()(getPage, handleFetch), data = _useSWRInfinite.data, isLoading = _useSWRInfinite.isLoading, isValidating = _useSWRInfinite.isValidating, setSize = _useSWRInfinite.setSize, error = _useSWRInfinite.error, size = _useSWRInfinite.size, mutate = _useSWRInfinite.mutate;
    // see the comments above for why this is here
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(function() {
        var index = ++vitalsHooksCounter;
        vitalsHooksMutates.set(index, mutate);
        return function() {
            vitalsHooksMutates.delete(index);
        };
    }, [
        mutate
    ]);
    var getVitalsMapKey = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(function(conceptUuid) {
        switch(conceptUuid){
            case concepts.systolicBloodPressureUuid:
                return 'systolic';
            case concepts.diastolicBloodPressureUuid:
                return 'diastolic';
            case concepts.pulseUuid:
                return 'pulse';
            case concepts.temperatureUuid:
                return 'temperature';
            case concepts.oxygenSaturationUuid:
                return 'spo2';
            case concepts.respiratoryRateUuid:
                return 'respiratoryRate';
            case concepts.heightUuid:
                return 'height';
            case concepts.weightUuid:
                return 'weight';
            case concepts.midUpperArmCircumferenceUuid:
                return 'muac';
            default:
                return ''; // or throw an error for unknown conceptUuid
        }
    }, [
        concepts.heightUuid,
        concepts.midUpperArmCircumferenceUuid,
        concepts.systolicBloodPressureUuid,
        concepts.oxygenSaturationUuid,
        concepts.diastolicBloodPressureUuid,
        concepts.pulseUuid,
        concepts.respiratoryRateUuid,
        concepts.temperatureUuid,
        concepts.weightUuid
    ]);
    var formattedObs = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(function() {
        var _data__data_entry_map_filter_map, _data__data_entry, _data__data, _data_;
        var vitalsHashTable = data === null || data === void 0 ? void 0 : (_data_ = data[0]) === null || _data_ === void 0 ? void 0 : (_data__data = _data_.data) === null || _data__data === void 0 ? void 0 : (_data__data_entry = _data__data.entry) === null || _data__data_entry === void 0 ? void 0 : (_data__data_entry_map_filter_map = _data__data_entry.map(function(entry) {
            return entry.resource;
        }).filter(Boolean).map(mapVitalsAndBiometrics)) === null || _data__data_entry_map_filter_map === void 0 ? void 0 : _data__data_entry_map_filter_map.reduce(function(vitalsHashTable, vitalSign) {
            var encounterId = vitalSign.encounterId;
            if (vitalsHashTable.has(encounterId) && vitalsHashTable.get(encounterId)) {
                var _obj;
                vitalsHashTable.set(encounterId, _object_spread_props(_object_spread({}, vitalsHashTable.get(encounterId)), (_obj = {}, _define_property(_obj, getVitalsMapKey(vitalSign.code), vitalSign.value), _define_property(_obj, getInterpretationKey(getVitalsMapKey(vitalSign.code)), vitalSign.interpretation), _obj)));
            } else {
                var _obj1;
                vitalSign.value && vitalsHashTable.set(encounterId, (_obj1 = {
                    date: typeof vitalSign.recordedDate === 'string' ? vitalSign.recordedDate : vitalSign.recordedDate.toDateString()
                }, _define_property(_obj1, getVitalsMapKey(vitalSign.code), vitalSign.value), _define_property(_obj1, getInterpretationKey(getVitalsMapKey(vitalSign.code)), vitalSign.interpretation), _obj1));
            }
            return vitalsHashTable;
        }, new Map());
        return Array.from(vitalsHashTable !== null && vitalsHashTable !== void 0 ? vitalsHashTable : []).map(function(param) {
            var _param = _sliced_to_array(param, 2), encounterId = _param[0], vitalSigns = _param[1];
            var result = _object_spread({
                id: encounterId,
                date: vitalSigns.date
            }, vitalSigns);
            if (mode === 'both' || mode === 'biometrics') {
                result.bmi = (0,_helpers__WEBPACK_IMPORTED_MODULE_4__.calculateBodyMassIndex)(Number(vitalSigns.weight), Number(vitalSigns.height));
            }
            if (mode === 'both' || mode === 'vitals') {
                result.bloodPressureRenderInterpretation = (0,_helpers__WEBPACK_IMPORTED_MODULE_4__.interpretBloodPressure)(vitalSigns.systolic, vitalSigns.diastolic, concepts, conceptRanges);
                result.pulseRenderInterpretation = (0,_helpers__WEBPACK_IMPORTED_MODULE_4__.assessValue)(vitalSigns.pulse, (0,_helpers__WEBPACK_IMPORTED_MODULE_4__.getReferenceRangesForConcept)(concepts.pulseUuid, conceptRanges));
                result.temperatureRenderInterpretation = (0,_helpers__WEBPACK_IMPORTED_MODULE_4__.assessValue)(vitalSigns.temperature, (0,_helpers__WEBPACK_IMPORTED_MODULE_4__.getReferenceRangesForConcept)(concepts.temperatureUuid, conceptRanges));
                result.spo2RenderInterpretation = (0,_helpers__WEBPACK_IMPORTED_MODULE_4__.assessValue)(vitalSigns.spo2, (0,_helpers__WEBPACK_IMPORTED_MODULE_4__.getReferenceRangesForConcept)(concepts.oxygenSaturationUuid, conceptRanges));
                result.respiratoryRateRenderInterpretation = (0,_helpers__WEBPACK_IMPORTED_MODULE_4__.assessValue)(vitalSigns.respiratoryRate, (0,_helpers__WEBPACK_IMPORTED_MODULE_4__.getReferenceRangesForConcept)(concepts.respiratoryRateUuid, conceptRanges));
            }
            return result;
        });
    }, [
        conceptRanges,
        concepts,
        data,
        getVitalsMapKey,
        mode
    ]);
    var _data__data_total;
    return {
        data: data ? formattedObs : undefined,
        isLoading: isLoading,
        error: error,
        hasMore: (data === null || data === void 0 ? void 0 : data.length) ? !!((_data__data = data[data.length - 1].data) === null || _data__data === void 0 ? void 0 : (_data__data_link = _data__data.link) === null || _data__data_link === void 0 ? void 0 : _data__data_link.some(function(link) {
            return link.relation === 'next';
        })) : false,
        isValidating: isValidating,
        loadingNewData: isValidating,
        setPage: setSize,
        currentPage: size,
        totalResults: (_data__data_total = data === null || data === void 0 ? void 0 : (_data_ = data[0]) === null || _data_ === void 0 ? void 0 : (_data__data1 = _data_.data) === null || _data__data1 === void 0 ? void 0 : _data__data1.total) !== null && _data__data_total !== void 0 ? _data__data_total : undefined,
        mutate: mutate
    };
}
/**
 * Hook to get the vitals and biometrics for a patient associated with a specific encounter
 */ function useEncounterVitalsAndBiometrics(encounterUuid) {
    var concepts = (0,_openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_1__.useConfig)().concepts;
    var fieldNameSuffix = 'Uuid';
    var url = encounterUuid ? "".concat(_openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_1__.restBaseUrl, "/encounter/").concat(encounterUuid, "?v=").concat(encounterRepresentation) : null;
    var _useSWRImmutable = swr_immutable__WEBPACK_IMPORTED_MODULE_2___default()(url, _openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_1__.openmrsFetch), data = _useSWRImmutable.data, isLoading = _useSWRImmutable.isLoading, error = _useSWRImmutable.error, mutate = _useSWRImmutable.mutate;
    var vitalsAndBiometrics = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(function() {
        if (!isLoading && data && concepts) {
            return data.data.obs.reduce(function(vitalsAndBiometrics, obs) {
                var _Object_entries_find;
                var fieldName = (_Object_entries_find = Object.entries(concepts).find(function(param) {
                    var _param = _sliced_to_array(param, 2), value = _param[1];
                    return value === obs.concept.uuid;
                })) === null || _Object_entries_find === void 0 ? void 0 : _Object_entries_find[0];
                if (fieldName) {
                    fieldName = fieldName.endsWith(fieldNameSuffix) ? fieldName.replace(fieldNameSuffix, '') : fieldName;
                    vitalsAndBiometrics.set(fieldName, {
                        value: obs.value,
                        obs: obs
                    });
                }
                return vitalsAndBiometrics;
            }, new Map());
        }
        return null;
    }, [
        isLoading,
        data,
        concepts
    ]);
    var getRefinedInitialValues = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(function() {
        var initialValues = {};
        if (vitalsAndBiometrics) {
            vitalsAndBiometrics.forEach(function(value, key) {
                initialValues[key] = value.value;
            });
        }
        return initialValues;
    }, [
        vitalsAndBiometrics
    ]);
    return {
        isLoading: isLoading,
        vitalsAndBiometrics: vitalsAndBiometrics,
        encounter: data === null || data === void 0 ? void 0 : data.data,
        error: error,
        mutate: mutate,
        getRefinedInitialValues: getRefinedInitialValues
    };
}
/**
 * Fetcher for the useVitalsAndBiometricsHook
 * @internal
 */ function handleFetch(param) {
    var patientUuid = param.patientUuid, conceptUuids = param.conceptUuids, page = param.page, prevPageData = param.prevPageData;
    var _prevPageData_data;
    if (prevPageData && !(prevPageData === null || prevPageData === void 0 ? void 0 : (_prevPageData_data = prevPageData.data) === null || _prevPageData_data === void 0 ? void 0 : _prevPageData_data.link.some(function(link) {
        return link.relation === 'next';
    }))) {
        return null;
    }
    var url = "".concat(_openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_1__.fhirBaseUrl, "/Observation?subject:Patient=").concat(patientUuid, "&");
    var urlSearchParams = new URLSearchParams();
    urlSearchParams.append('code', conceptUuids);
    urlSearchParams.append('_summary', 'data');
    urlSearchParams.append('_sort', '-date');
    urlSearchParams.append('_count', pageSize.toString());
    if (page) {
        urlSearchParams.append('_getpagesoffset', (page * pageSize).toString());
    }
    return (0,_openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_1__.openmrsFetch)(url + urlSearchParams.toString());
}
/**
 * Mapper that converts a FHIR Observation resource into a MappedVitals object.
 * @internal
 */ function mapVitalsAndBiometrics(resource) {
    var _resource_code_coding_, _resource_code_coding, _resource_code, _resource_code1, _resource_valueQuantity, _resource_referenceRange, _resource_code_coding_1, _resource_code_coding1, _resource_code2, _resource_valueQuantity1, _resource_valueQuantity2;
    var _resource_valueQuantity_unit;
    var referenceRanges = {
        uuid: resource === null || resource === void 0 ? void 0 : (_resource_code = resource.code) === null || _resource_code === void 0 ? void 0 : (_resource_code_coding = _resource_code.coding) === null || _resource_code_coding === void 0 ? void 0 : (_resource_code_coding_ = _resource_code_coding[0]) === null || _resource_code_coding_ === void 0 ? void 0 : _resource_code_coding_.code,
        display: resource === null || resource === void 0 ? void 0 : (_resource_code1 = resource.code) === null || _resource_code1 === void 0 ? void 0 : _resource_code1.text,
        hiNormal: null,
        hiAbsolute: null,
        hiCritical: null,
        lowNormal: null,
        lowAbsolute: null,
        lowCritical: null,
        units: (_resource_valueQuantity_unit = (_resource_valueQuantity = resource.valueQuantity) === null || _resource_valueQuantity === void 0 ? void 0 : _resource_valueQuantity.unit) !== null && _resource_valueQuantity_unit !== void 0 ? _resource_valueQuantity_unit : null
    };
    resource === null || resource === void 0 ? void 0 : (_resource_referenceRange = resource.referenceRange) === null || _resource_referenceRange === void 0 ? void 0 : _resource_referenceRange.forEach(function(range) {
        var _range_type_coding_, _range_type_coding, _range_type, _range_type_coding_1, _range_type_coding1, _range_type1;
        var rangeType = (_range_type = range.type) === null || _range_type === void 0 ? void 0 : (_range_type_coding = _range_type.coding) === null || _range_type_coding === void 0 ? void 0 : (_range_type_coding_ = _range_type_coding[0]) === null || _range_type_coding_ === void 0 ? void 0 : _range_type_coding_.code;
        var rangeSystem = (_range_type1 = range.type) === null || _range_type1 === void 0 ? void 0 : (_range_type_coding1 = _range_type1.coding) === null || _range_type_coding1 === void 0 ? void 0 : (_range_type_coding_1 = _range_type_coding1[0]) === null || _range_type_coding_1 === void 0 ? void 0 : _range_type_coding_1.system;
        if (rangeSystem === 'http://terminology.hl7.org/CodeSystem/referencerange-meaning') {
            if (rangeType === 'normal') {
                var _range_high, _range_low;
                var _range_high_value;
                referenceRanges.hiNormal = (_range_high_value = (_range_high = range.high) === null || _range_high === void 0 ? void 0 : _range_high.value) !== null && _range_high_value !== void 0 ? _range_high_value : null;
                var _range_low_value;
                referenceRanges.lowNormal = (_range_low_value = (_range_low = range.low) === null || _range_low === void 0 ? void 0 : _range_low.value) !== null && _range_low_value !== void 0 ? _range_low_value : null;
            } else if (rangeType === 'treatment') {
                var _range_high1, _range_low1;
                var _range_high_value1;
                referenceRanges.hiCritical = (_range_high_value1 = (_range_high1 = range.high) === null || _range_high1 === void 0 ? void 0 : _range_high1.value) !== null && _range_high_value1 !== void 0 ? _range_high_value1 : null;
                var _range_low_value1;
                referenceRanges.lowCritical = (_range_low_value1 = (_range_low1 = range.low) === null || _range_low1 === void 0 ? void 0 : _range_low1.value) !== null && _range_low_value1 !== void 0 ? _range_low_value1 : null;
            }
        } else if (rangeSystem === 'http://fhir.openmrs.org/ext/obs/reference-range' && rangeType === 'absolute') {
            var _range_high2, _range_low2;
            var _range_high_value2;
            referenceRanges.hiAbsolute = (_range_high_value2 = (_range_high2 = range.high) === null || _range_high2 === void 0 ? void 0 : _range_high2.value) !== null && _range_high_value2 !== void 0 ? _range_high_value2 : null;
            var _range_low_value2;
            referenceRanges.lowAbsolute = (_range_low_value2 = (_range_low2 = range.low) === null || _range_low2 === void 0 ? void 0 : _range_low2.value) !== null && _range_low_value2 !== void 0 ? _range_low_value2 : null;
        }
    });
    return {
        code: resource === null || resource === void 0 ? void 0 : (_resource_code2 = resource.code) === null || _resource_code2 === void 0 ? void 0 : (_resource_code_coding1 = _resource_code2.coding) === null || _resource_code_coding1 === void 0 ? void 0 : (_resource_code_coding_1 = _resource_code_coding1[0]) === null || _resource_code_coding_1 === void 0 ? void 0 : _resource_code_coding_1.code,
        encounterId: extractEncounterUuid(resource.encounter),
        interpretation: (0,_helpers__WEBPACK_IMPORTED_MODULE_4__.assessValue)(resource === null || resource === void 0 ? void 0 : (_resource_valueQuantity1 = resource.valueQuantity) === null || _resource_valueQuantity1 === void 0 ? void 0 : _resource_valueQuantity1.value, referenceRanges),
        recordedDate: resource === null || resource === void 0 ? void 0 : resource.effectiveDateTime,
        value: resource === null || resource === void 0 ? void 0 : (_resource_valueQuantity2 = resource.valueQuantity) === null || _resource_valueQuantity2 === void 0 ? void 0 : _resource_valueQuantity2.value
    };
}
function createOrUpdateVitalsAndBiometrics(patientUuid, encounterTypeUuid, encounterUuid, location, vitalsAndBiometricsObs, abortController) {
    var url = encounterUuid ? "".concat(_openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_1__.restBaseUrl, "/encounter/").concat(encounterUuid) : "".concat(_openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_1__.restBaseUrl, "/encounter");
    var encounter = {
        patient: patientUuid,
        obs: vitalsAndBiometricsObs
    };
    if (!encounterUuid) {
        encounter['location'] = location;
        encounter['encounterType'] = encounterTypeUuid;
    }
    return (0,_openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_1__.openmrsFetch)(url, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        signal: abortController.signal,
        body: encounter
    });
}
function deleteEncounter(encounterUuid) {
    return (0,_openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_1__.openmrsFetch)("".concat(_openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_1__.restBaseUrl, "/encounter/").concat(encounterUuid), {
        method: 'DELETE'
    });
}
function extractEncounterUuid(encounter) {
    if (!encounter || !encounter.reference) {
        return '';
    }
    return encounter.reference.split('/')[1];
}
/**
 * Invalidate all useVitalsAndBiometrics hooks data, to force them to reload
 */ function invalidateCachedVitalsAndBiometrics() {
    return _async_to_generator(function() {
        return _ts_generator(this, function(_state) {
            vitalsHooksMutates.forEach(function(mutate) {
                return mutate();
            });
            return [
                2
            ];
        });
    })();
}


/***/ }),

/***/ "./src/common/debug-helper.ts":
/*!************************************!*\
  !*** ./src/common/debug-helper.ts ***!
  \************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   checkComponentRegistration: () => (/* binding */ checkComponentRegistration)
/* harmony export */ });
// This file is just to help with debugging component registration
console.log('Debug helper file loaded');
// Add global error handler
if (typeof window !== 'undefined') {
    window.addEventListener('error', function(event) {
        console.error('Global error caught:', event.error);
    });
}
// Export a function to check if a component is registered
function checkComponentRegistration() {
    console.log('Available exports from the module:');
    // This will run in the browser and print helpful debugging info
    if (typeof window !== 'undefined') {
        var appName = '@openmrs/esm-patient-vitals-app';
        console.log("Looking for ".concat(appName, " in window.__webpack_modules__"));
        try {
            // @ts-ignore
            var modules = window.__webpack_modules__ || {};
            var found = false;
            Object.keys(modules).forEach(function(key) {
                if (key.includes(appName)) {
                    console.log("Found module: ".concat(key));
                    found = true;
                    try {
                        var _window___webpack_exports__;
                        // @ts-ignore
                        var exports = (_window___webpack_exports__ = window.__webpack_exports__) === null || _window___webpack_exports__ === void 0 ? void 0 : _window___webpack_exports__[key];
                        if (exports) {
                            console.log('Module exports:', Object.keys(exports));
                            if (exports.confDashboard) {
                                console.log('confDashboard is exported!');
                            } else {
                                console.log('confDashboard is NOT found in exports');
                            }
                        }
                    } catch (e) {
                        console.error('Error inspecting exports:', e);
                    }
                }
            });
            if (!found) {
                console.log("No modules found for ".concat(appName));
            }
        } catch (e) {
            console.error('Error in debug helper:', e);
        }
    }
    return true;
}
// Call this function automatically
setTimeout(function() {
    console.log('Running automatic component registration check...');
    checkComponentRegistration();
}, 2000);
// Run the check automatically
setTimeout(checkComponentRegistration, 2000);


/***/ }),

/***/ "./src/common/helpers.ts":
/*!*******************************!*\
  !*** ./src/common/helpers.ts ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   assessValue: () => (/* binding */ assessValue),
/* harmony export */   calculateBodyMassIndex: () => (/* binding */ calculateBodyMassIndex),
/* harmony export */   generatePlaceholder: () => (/* binding */ generatePlaceholder),
/* harmony export */   getReferenceRangesForConcept: () => (/* binding */ getReferenceRangesForConcept),
/* harmony export */   interpretBloodPressure: () => (/* binding */ interpretBloodPressure),
/* harmony export */   prepareObsForSubmission: () => (/* binding */ prepareObsForSubmission)
/* harmony export */ });
function _array_like_to_array(arr, len) {
    if (len == null || len > arr.length) len = arr.length;
    for(var i = 0, arr2 = new Array(len); i < len; i++)arr2[i] = arr[i];
    return arr2;
}
function _array_with_holes(arr) {
    if (Array.isArray(arr)) return arr;
}
function _iterable_to_array_limit(arr, i) {
    var _i = arr == null ? null : typeof Symbol !== "undefined" && arr[Symbol.iterator] || arr["@@iterator"];
    if (_i == null) return;
    var _arr = [];
    var _n = true;
    var _d = false;
    var _s, _e;
    try {
        for(_i = _i.call(arr); !(_n = (_s = _i.next()).done); _n = true){
            _arr.push(_s.value);
            if (i && _arr.length === i) break;
        }
    } catch (err) {
        _d = true;
        _e = err;
    } finally{
        try {
            if (!_n && _i["return"] != null) _i["return"]();
        } finally{
            if (_d) throw _e;
        }
    }
    return _arr;
}
function _non_iterable_rest() {
    throw new TypeError("Invalid attempt to destructure non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _sliced_to_array(arr, i) {
    return _array_with_holes(arr) || _iterable_to_array_limit(arr, i) || _unsupported_iterable_to_array(arr, i) || _non_iterable_rest();
}
function _unsupported_iterable_to_array(o, minLen) {
    if (!o) return;
    if (typeof o === "string") return _array_like_to_array(o, minLen);
    var n = Object.prototype.toString.call(o).slice(8, -1);
    if (n === "Object" && o.constructor) n = o.constructor.name;
    if (n === "Map" || n === "Set") return Array.from(n);
    if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _array_like_to_array(o, minLen);
}
function calculateBodyMassIndex(weight, height) {
    if (weight > 0 && height > 0) {
        return Number((weight / Math.pow(height / 100, 2)).toFixed(1));
    }
    return null;
}
function assessValue(value, range) {
    if (range && value) {
        if (range.hiCritical && value >= range.hiCritical) {
            return 'critically_high';
        }
        if (range.hiNormal && value > range.hiNormal) {
            return 'high';
        }
        if (range.lowCritical && value <= range.lowCritical) {
            return 'critically_low';
        }
        if (range.lowNormal && value < range.lowNormal) {
            return 'low';
        }
    }
    return 'normal';
}
function interpretBloodPressure(systolic, diastolic, concepts, conceptMetadata) {
    if (!conceptMetadata) {
        return 'normal';
    }
    var systolicAssessment = assessValue(systolic, getReferenceRangesForConcept(concepts === null || concepts === void 0 ? void 0 : concepts.systolicBloodPressureUuid, conceptMetadata));
    var diastolicAssessment = (concepts === null || concepts === void 0 ? void 0 : concepts.diastolicBloodPressureUuid) ? assessValue(diastolic, getReferenceRangesForConcept(concepts.diastolicBloodPressureUuid, conceptMetadata)) : 'normal';
    if (systolicAssessment === 'critically_high' || diastolicAssessment === 'critically_high') {
        return 'critically_high';
    }
    if (systolicAssessment === 'critically_low' || diastolicAssessment === 'critically_low') {
        return 'critically_low';
    }
    if (systolicAssessment === 'high' || diastolicAssessment === 'high') {
        return 'high';
    }
    if (systolicAssessment === 'low' || diastolicAssessment === 'low') {
        return 'low';
    }
    return 'normal';
}
function generatePlaceholder(value) {
    switch(value){
        case 'BMI':
            return '';
        case 'Temperature':
        case 'Weight':
            return '--.-';
        case 'Height':
        case 'diastolic':
        case 'systolic':
        case 'Pulse':
            return '---';
        default:
            return '--';
    }
}
function getReferenceRangesForConcept(conceptUuid, conceptMetadata) {
    if (!conceptUuid || !(conceptMetadata === null || conceptMetadata === void 0 ? void 0 : conceptMetadata.length)) {
        return undefined;
    }
    return conceptMetadata === null || conceptMetadata === void 0 ? void 0 : conceptMetadata.find(function(metadata) {
        return metadata.uuid === conceptUuid;
    });
}
function prepareObsForSubmission(formData, dirtyFields, formContext, initialFieldValuesMap, fieldToConceptMap) {
    return Object.entries(formData).reduce(function(obsForSubmission, param) {
        var _param = _sliced_to_array(param, 2), field = _param[0], newValue = _param[1];
        if (!fieldToConceptMap["".concat(field, "Uuid")]) {
            console.error("Missing concept mapping for field: ".concat(field));
            return obsForSubmission;
        }
        if (formContext === 'editing' && initialFieldValuesMap.has(field) && dirtyFields[field]) {
            // void old obs
            var obs = initialFieldValuesMap.get(field).obs;
            obsForSubmission.toBeVoided.push({
                uuid: obs.uuid,
                voided: true
            });
            if (newValue) {
                obsForSubmission.newObs.push({
                    concept: fieldToConceptMap["".concat(field, "Uuid")],
                    value: newValue
                });
            }
        } else if (dirtyFields[field] && newValue) {
            // create new obs
            obsForSubmission.newObs.push({
                concept: fieldToConceptMap["".concat(field, "Uuid")],
                value: newValue
            });
        }
        return obsForSubmission;
    }, {
        toBeVoided: [],
        newObs: []
    });
}


/***/ }),

/***/ "./src/common/index.ts":
/*!*****************************!*\
  !*** ./src/common/index.ts ***!
  \*****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   StigmaCutoffChart: () => (/* reexport safe */ _stigma_cutoff_chart__WEBPACK_IMPORTED_MODULE_2__.StigmaCutoffChart),
/* harmony export */   adjustForNepaliTimezone: () => (/* reexport safe */ _data_utils__WEBPACK_IMPORTED_MODULE_3__.adjustForNepaliTimezone),
/* harmony export */   assessValue: () => (/* reexport safe */ _helpers__WEBPACK_IMPORTED_MODULE_1__.assessValue),
/* harmony export */   calculateBodyMassIndex: () => (/* reexport safe */ _helpers__WEBPACK_IMPORTED_MODULE_1__.calculateBodyMassIndex),
/* harmony export */   calculateObservationStats: () => (/* reexport safe */ _data_utils__WEBPACK_IMPORTED_MODULE_3__.calculateObservationStats),
/* harmony export */   createOrUpdateVitalsAndBiometrics: () => (/* reexport safe */ _data_resource__WEBPACK_IMPORTED_MODULE_0__.createOrUpdateVitalsAndBiometrics),
/* harmony export */   deleteEncounter: () => (/* reexport safe */ _data_resource__WEBPACK_IMPORTED_MODULE_0__.deleteEncounter),
/* harmony export */   extractNumericValue: () => (/* reexport safe */ _data_utils__WEBPACK_IMPORTED_MODULE_3__.extractNumericValue),
/* harmony export */   filterObservationsByDateRange: () => (/* reexport safe */ _data_utils__WEBPACK_IMPORTED_MODULE_3__.filterObservationsByDateRange),
/* harmony export */   generatePlaceholder: () => (/* reexport safe */ _helpers__WEBPACK_IMPORTED_MODULE_1__.generatePlaceholder),
/* harmony export */   getMostRecentObservation: () => (/* reexport safe */ _data_utils__WEBPACK_IMPORTED_MODULE_3__.getMostRecentObservation),
/* harmony export */   getReferenceRangesForConcept: () => (/* reexport safe */ _helpers__WEBPACK_IMPORTED_MODULE_1__.getReferenceRangesForConcept),
/* harmony export */   groupObservationsByConcept: () => (/* reexport safe */ _data_utils__WEBPACK_IMPORTED_MODULE_3__.groupObservationsByConcept),
/* harmony export */   interpretBloodPressure: () => (/* reexport safe */ _helpers__WEBPACK_IMPORTED_MODULE_1__.interpretBloodPressure),
/* harmony export */   invalidateCachedVitalsAndBiometrics: () => (/* reexport safe */ _data_resource__WEBPACK_IMPORTED_MODULE_0__.invalidateCachedVitalsAndBiometrics),
/* harmony export */   parseOpenMRSDate: () => (/* reexport safe */ _data_utils__WEBPACK_IMPORTED_MODULE_3__.parseOpenMRSDate),
/* harmony export */   useConceptUnits: () => (/* reexport safe */ _data_resource__WEBPACK_IMPORTED_MODULE_0__.useConceptUnits),
/* harmony export */   useEncounterVitalsAndBiometrics: () => (/* reexport safe */ _data_resource__WEBPACK_IMPORTED_MODULE_0__.useEncounterVitalsAndBiometrics),
/* harmony export */   useVitalsAndBiometrics: () => (/* reexport safe */ _data_resource__WEBPACK_IMPORTED_MODULE_0__.useVitalsAndBiometrics),
/* harmony export */   useVitalsConceptMetadata: () => (/* reexport safe */ _data_resource__WEBPACK_IMPORTED_MODULE_0__.useVitalsConceptMetadata),
/* harmony export */   withUnit: () => (/* reexport safe */ _data_resource__WEBPACK_IMPORTED_MODULE_0__.withUnit)
/* harmony export */ });
/* harmony import */ var _data_resource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./data.resource */ "./src/common/data.resource.ts");
/* harmony import */ var _helpers__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./helpers */ "./src/common/helpers.ts");
/* harmony import */ var _stigma_cutoff_chart__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./stigma-cutoff-chart */ "./src/common/stigma-cutoff-chart.tsx");
/* harmony import */ var _data_utils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./data-utils */ "./src/common/data-utils.ts");


// Analytics Dashboard Components

// export { MonthlyBarChart } from './monthly-bar-chart';
// export { HealthTrendChart } from './health-trend-chart';
// export { PatientAnalyticsDashboard } from './patient-analytics-dashboard';
// Data Utilities



/***/ }),

/***/ "./src/common/stigma-cutoff-chart.tsx":
/*!********************************************!*\
  !*** ./src/common/stigma-cutoff-chart.tsx ***!
  \********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   StigmaCutoffChart: () => (/* binding */ StigmaCutoffChart)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_chartjs_2__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-chartjs-2 */ "../../node_modules/react-chartjs-2/dist/index.js");
/* harmony import */ var chart_js_auto__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! chart.js/auto */ "../../node_modules/chart.js/auto/auto.js");



function StigmaCutoffChart(param) {
    var stigmaCutoffSummary = param.stigmaCutoffSummary, patientsData = param.patientsData, stigmaScoreLabel = param.stigmaScoreLabel, stigmaScoreThreshold = param.stigmaScoreThreshold;
    // If we have the raw data and should calculate
    var calculatedData = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(function() {
        if (patientsData && stigmaScoreLabel && stigmaScoreThreshold) {
            return calculateStigmaThresholdCounts(patientsData, stigmaScoreLabel, stigmaScoreThreshold);
        }
        return null;
    }, [
        patientsData,
        stigmaScoreLabel,
        stigmaScoreThreshold
    ]);
    // Use either pre-calculated or calculated data
    var chartData = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(function() {
        if (calculatedData) {
            return {
                aboveThreshold: calculatedData.aboveThresholdCount,
                belowThreshold: calculatedData.belowThresholdCount,
                total: calculatedData.aboveThresholdCount + calculatedData.belowThresholdCount
            };
        } else if (stigmaCutoffSummary) {
            return {
                aboveThreshold: stigmaCutoffSummary.matchedPatients,
                belowThreshold: stigmaCutoffSummary.unmatchedPatients,
                total: stigmaCutoffSummary.totalPatients
            };
        }
        return null;
    }, [
        calculatedData,
        stigmaCutoffSummary
    ]);
    // Loading state
    if (!chartData) {
        return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement("p", null, "तथ्यांक विश्लेषण गर्दै...");
    }
    return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", {
        style: {
            backgroundColor: '#fff',
            padding: '1rem',
            marginBottom: '1rem',
            borderRadius: '8px',
            boxShadow: '0 2px 4px rgba(0,0,0,0.1)'
        }
    }, /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement("h3", {
        style: {
            fontSize: '1.5rem',
            fontWeight: '600',
            color: '#333',
            textRendering: 'optimizeLegibility',
            marginBottom: '1.5rem'
        }
    }, "लान्छना विश्लेषण नतिजाहरू"), /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", {
        style: {
            maxWidth: '500px',
            margin: '20px auto',
            WebkitFontSmoothing: 'antialiased',
            MozOsxFontSmoothing: 'grayscale'
        }
    }, /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement(react_chartjs_2__WEBPACK_IMPORTED_MODULE_2__.Chart, {
        type: "pie",
        data: {
            labels: [
                'उच्च लान्छना स्कोर',
                'न्यून लान्छना स्कोर'
            ],
            datasets: [
                {
                    data: [
                        chartData.aboveThreshold,
                        chartData.belowThreshold
                    ],
                    backgroundColor: [
                        '#f7cc5c',
                        '#28a6a4'
                    ],
                    borderColor: [
                        '#fff',
                        '#fff'
                    ],
                    borderWidth: 2
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: true,
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: {
                        font: {
                            size: 14,
                            weight: 'bold'
                        },
                        padding: 20,
                        color: '#333'
                    }
                },
                tooltip: {
                    titleFont: {
                        size: 14,
                        weight: 'bold'
                    },
                    bodyFont: {
                        size: 13
                    },
                    backgroundColor: 'rgba(255, 255, 255, 0.9)',
                    titleColor: '#333',
                    bodyColor: '#333',
                    borderColor: '#ccc',
                    borderWidth: 1,
                    callbacks: {
                        label: function label(context) {
                            var total = chartData.total;
                            var value = context.raw;
                            var percentage = (value / total * 100).toFixed(1);
                            return "".concat(context.label, ": ").concat(percentage, "% (").concat(value, " बिरामीहरू)");
                        }
                    }
                }
            }
        }
    })), stigmaScoreThreshold && /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", {
        style: {
            textAlign: 'center',
            marginTop: '1rem',
            fontSize: '0.9rem',
            color: '#555'
        }
    }, /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement("p", null, "Threshold: ", stigmaScoreThreshold, " | Total Patients: ", chartData.total)));
}
// Helper function to calculate stigma threshold counts
function calculateStigmaThresholdCounts(patientsData, stigmaScoreLabel, stigmaScoreThreshold) {
    var aboveThresholdCount = 0;
    var belowThresholdCount = 0;
    patientsData.forEach(function(patient) {
        // Find the most recent stigma score for each patient
        var mostRecent = null;
        var mostRecentDate = null;
        patient.forEach(function(obs) {
            var _obs_display;
            if ((_obs_display = obs.display) === null || _obs_display === void 0 ? void 0 : _obs_display.includes(stigmaScoreLabel)) {
                var date = new Date(obs.effectiveDateTime || obs.date);
                if (!mostRecentDate || date > mostRecentDate) {
                    mostRecentDate = date;
                    mostRecent = obs;
                }
            }
        });
        if (mostRecent) {
            // Extract the numeric value from the display string
            // Assuming the format is like "Stigma Score: 12"
            var valueMatch = mostRecent.display.match(/\d+(\.\d+)?/);
            if (valueMatch) {
                var value = parseFloat(valueMatch[0]);
                if (value >= stigmaScoreThreshold) {
                    aboveThresholdCount++;
                } else {
                    belowThresholdCount++;
                }
            }
        }
    });
    return {
        aboveThresholdCount: aboveThresholdCount,
        belowThresholdCount: belowThresholdCount
    };
}


/***/ }),

/***/ "./src/common/stigma-data-aggregate.tsx":
/*!**********************************************!*\
  !*** ./src/common/stigma-data-aggregate.tsx ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ MultiChartSelector)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _covid_stigma_data_resource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./covid-stigma-data.resource */ "./src/common/covid-stigma-data.resource.tsx");
/* harmony import */ var react_chartjs_2__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react-chartjs-2 */ "../../node_modules/react-chartjs-2/dist/index.js");
/* harmony import */ var chart_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! chart.js */ "../../node_modules/chart.js/dist/chart.js");
 // Removed useState since we're not using it

 // Removed Line import since we're not using it

// import zoomPlugin from 'chartjs-plugin-zoom';
chart_js__WEBPACK_IMPORTED_MODULE_2__.Chart.register(chart_js__WEBPACK_IMPORTED_MODULE_2__.CategoryScale, chart_js__WEBPACK_IMPORTED_MODULE_2__.LinearScale, chart_js__WEBPACK_IMPORTED_MODULE_2__.BarElement, chart_js__WEBPACK_IMPORTED_MODULE_2__.PointElement, chart_js__WEBPACK_IMPORTED_MODULE_2__.LineElement, chart_js__WEBPACK_IMPORTED_MODULE_2__.Title, chart_js__WEBPACK_IMPORTED_MODULE_2__.Tooltip, chart_js__WEBPACK_IMPORTED_MODULE_2__.Legend, chart_js__WEBPACK_IMPORTED_MODULE_2__.Filler);
var DOMAIN_COLORS = {
    hiv: 'rgba(255,99,132,0.8)',
    mh: 'rgba(54,162,235,0.8)',
    sgm: 'rgba(255,206,86,0.8)',
    em: 'rgba(75,192,192,0.8)',
    intersectional: 'rgba(153,102,255,0.8)'
};
/* ---------------- Helpers ---------------- */ function parseDimensionScore(scoreStr) {
    var domainMap = {
        hiv: 0,
        mh: 0,
        sgm: 0,
        em: 0,
        intersectional: 0
    };
    var mappings = [
        {
            key: 'hiv',
            label: 'एचआईभी'
        },
        {
            key: 'mh',
            label: 'मानसिक स्वास्थ्य'
        },
        {
            key: 'sgm',
            label: 'लैङ्गिक तथा यौनिक अल्पसङ्ख्यक'
        },
        {
            key: 'em',
            label: 'जातीय अल्पसङ्ख्यक/दलित'
        },
        {
            key: 'intersectional',
            label: 'इण्टरसेक्सनल'
        }
    ];
    mappings.forEach(function(param) {
        var key = param.key, label = param.label;
        var regex = new RegExp("".concat(label, "\\s*:?\\s*(\\d+)"));
        var match = scoreStr.match(regex);
        if (match) domainMap[key] = Number(match[1]);
    });
    return domainMap;
}
/* ---------------- Aggregation ---------------- */ var aggregateByType = function(data) {
    return data.map(function(d) {
        var parsed = d.dimensionScore ? parseDimensionScore(String(d.dimensionScore)) : {
            hiv: 0,
            mh: 0,
            sgm: 0,
            em: 0,
            intersectional: 0
        };
        // Use the intersectionalScore property directly
        if (d.intersectionalScore) {
            parsed.intersectional = Number(d.intersectionalScore);
        }
        return {
            type: d.stigmaType || 'Unknown',
            totals: parsed
        };
    });
};
/* Commenting out aggregateByDate since we're not using the line chart
const aggregateByDate = (data: CovidStigmaData[]) => {
  return data
    .map((d) => {
      const parsed = d.dimensionScore
        ? parseDimensionScore(String(d.dimensionScore))
        : { hiv: 0, mh: 0, sgm: 0, em: 0, intersectional: 0 };

      // Use the intersectionalScore property directly
      if (d.intersectionalScore) {
        parsed.intersectional = Number(d.intersectionalScore);
      }

      return {
        date: d.date,
        totals: parsed, // 👈 no forced sum
      };
    })
    .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
};
*/ /* ---------------- Chart Components ---------------- */ function TypeDimensionBarChart(param) {
    var data = param.data;
    var domainKeys = [
        'hiv',
        'mh',
        'sgm',
        'em',
        'intersectional'
    ];
    var domainLabels = {
        hiv: 'एचआईभी',
        mh: 'मानसिक स्वास्थ्य',
        sgm: 'लैङ्गिक तथा यौनिक अल्पसङ्ख्यक',
        em: 'जातीय अल्पसङ्ख्यक/दलित',
        intersectional: 'इण्टरसेक्सनल'
    };
    var datasets = domainKeys.map(function(key) {
        return {
            label: domainLabels[key],
            data: data.map(function(d) {
                return d.totals[key];
            }),
            backgroundColor: DOMAIN_COLORS[key]
        };
    });
    return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement(react_chartjs_2__WEBPACK_IMPORTED_MODULE_3__.Bar, {
        data: {
            labels: data.map(function(d) {
                return d.type;
            }),
            datasets: datasets
        },
        options: {
            responsive: true,
            plugins: {
                title: {
                    display: true,
                    text: 'Stigma Scores Across Type × Dimension'
                },
                legend: {
                    position: 'bottom'
                }
            },
            scales: {
                x: {
                    stacked: false,
                    title: {
                        display: true,
                        text: 'Stigma Type'
                    }
                },
                y: {
                    stacked: false,
                    title: {
                        display: true,
                        text: 'Score'
                    }
                }
            }
        }
    });
}
/* Commenting out the StigmaLineChart component since we're only using the TypeDimensionBarChart
function StigmaLineChart({ data }: { data: ReturnType<typeof aggregateByDate> }) {
  // Format labels as YYYY-MM
  const labels = data.map((d) => {
    const date = new Date(d.date);
    return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
  });

  const domainLabels = {
    hiv: 'एचआईभी',
    mh: 'मानसिक स्वास्थ्य',
    sgm: 'लैङ्गिक तथा यौनिक अल्पसङ्ख्यक',
    em: 'जातीय अल्पसङ्ख्यक/दलित',
    intersectional: 'इण्टरसेक्सनल',
  };

  const datasets = Object.keys(DOMAIN_COLORS).map((key) => ({
    label: domainLabels[key as keyof typeof domainLabels],
    data: data.map((d) => d.totals[key]),
    borderColor: DOMAIN_COLORS[key as keyof typeof DOMAIN_COLORS],
    backgroundColor: DOMAIN_COLORS[key as keyof typeof DOMAIN_COLORS],
    fill: false,
    tension: 0.2,
  }));

  return (
    <Line
      data={{ labels, datasets }}
      options={{
        responsive: true,
        plugins: {
          title: { display: true, text: 'Stigma Scores Trends' },
          legend: { position: 'bottom' },
          tooltip: {
            callbacks: {
              label: function (context) {
                const index = context.dataIndex;
                const d = data[index];
                return `${context.dataset.label}: ${context.parsed.y} (Date: ${new Date(d.date).toLocaleDateString()})`;
              },
            },
          },
          zoom: {
            zoom: { wheel: { enabled: true }, pinch: { enabled: true }, mode: 'x' },
            pan: { enabled: true, mode: 'x' },
          },
        },
        scales: {
          x: { title: { display: true, text: 'Year-Month' } },
          y: { title: { display: true, text: 'Score' } },
        },
      }}
    />
  );
}
*/ /* ---------------- Wrapper ---------------- */ function MultiChartSelector(param) {
    var patientUuid = param.patientUuid;
    var _useCovidStigmaData = (0,_covid_stigma_data_resource__WEBPACK_IMPORTED_MODULE_1__.useCovidStigmaData)(patientUuid), data = _useCovidStigmaData.data, isLoading = _useCovidStigmaData.isLoading, error = _useCovidStigmaData.error;
    // Comment out the chart type state since we're only showing the type chart
    // const [chartType, setChartType] = useState<'line' | 'type'>('type');
    var typeData = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(function() {
        return data ? aggregateByType(data) : [];
    }, [
        data
    ]);
    // We'll keep this for future use but won't use it now
    // const lineData = useMemo(() => (data ? aggregateByDate(data) : []), [data]);
    if (isLoading) return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement("p", null, "Loading stigma data...");
    if (error) return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement("p", {
        style: {
            color: 'red'
        }
    }, "Failed to load stigma data.");
    if (!(data === null || data === void 0 ? void 0 : data.length)) return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement("p", null, "No stigma data available");
    return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", {
        style: {
            padding: '1rem'
        }
    }, /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement(TypeDimensionBarChart, {
        data: typeData
    }));
}


/***/ }),

/***/ "./src/components/action-menu/vitals-biometrics-action-menu.component.tsx":
/*!********************************************************************************!*\
  !*** ./src/components/action-menu/vitals-biometrics-action-menu.component.tsx ***!
  \********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   VitalsAndBiometricsActionMenu: () => (/* binding */ VitalsAndBiometricsActionMenu)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-i18next */ "webpack/sharing/consume/default/react-i18next/react-i18next");
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_i18next__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _carbon_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @carbon/react */ "../../node_modules/@carbon/react/es/index.js");
/* harmony import */ var _openmrs_esm_patient_common_lib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @openmrs/esm-patient-common-lib */ "webpack/sharing/consume/default/@openmrs/esm-patient-common-lib/@openmrs/esm-patient-common-lib");
/* harmony import */ var _openmrs_esm_patient_common_lib__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_openmrs_esm_patient_common_lib__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @openmrs/esm-framework */ "webpack/sharing/consume/default/@openmrs/esm-framework/@openmrs/esm-framework");
/* harmony import */ var _openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../constants */ "./src/constants.ts");
/* harmony import */ var _vitals_biometrics_action_menu_scss__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./vitals-biometrics-action-menu.scss */ "./src/components/action-menu/vitals-biometrics-action-menu.scss");







var VitalsAndBiometricsActionMenu = function(param) {
    var encounterUuid = param.encounterUuid;
    var t = (0,react_i18next__WEBPACK_IMPORTED_MODULE_1__.useTranslation)().t;
    var patientUuid = (0,_openmrs_esm_patient_common_lib__WEBPACK_IMPORTED_MODULE_3__.getPatientUuidFromStore)();
    var isTablet = (0,_openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_4__.useLayoutType)() === 'tablet';
    var handleLaunchVitalsAndBiometricsForm = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(function() {
        (0,_openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_4__.launchWorkspace)(_constants__WEBPACK_IMPORTED_MODULE_5__.patientVitalsBiometricsFormWorkspace, {
            workspaceTitle: t('editVitalsAndBiometrics', 'Edit Vitals and Biometrics'),
            editEncounterUuid: encounterUuid,
            formContext: 'editing'
        });
    }, [
        encounterUuid,
        t
    ]);
    var handleLaunchDeleteVitalsAndBiometricsModal = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(function() {
        var dispose = (0,_openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_4__.showModal)('vitals-biometrics-delete-confirmation-modal', {
            closeDeleteModal: function() {
                return dispose();
            },
            encounterUuid: encounterUuid,
            patientUuid: patientUuid
        });
    }, [
        encounterUuid,
        patientUuid
    ]);
    return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_carbon_react__WEBPACK_IMPORTED_MODULE_2__.Layer, {
        className: _vitals_biometrics_action_menu_scss__WEBPACK_IMPORTED_MODULE_6__["default"].layer
    }, /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_carbon_react__WEBPACK_IMPORTED_MODULE_2__.OverflowMenu, {
        "aria-label": t('editOrDeleteVitalsAndBiometrics', 'Edit or delete Vitals and Biometrics'),
        size: isTablet ? 'lg' : 'sm',
        flipped: true,
        align: "left",
        id: encounterUuid
    }, /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_carbon_react__WEBPACK_IMPORTED_MODULE_2__.OverflowMenuItem, {
        className: _vitals_biometrics_action_menu_scss__WEBPACK_IMPORTED_MODULE_6__["default"].menuItem,
        id: "editVitalsAndBiometrics",
        onClick: handleLaunchVitalsAndBiometricsForm,
        itemText: t('edit', 'Edit')
    }), /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_carbon_react__WEBPACK_IMPORTED_MODULE_2__.OverflowMenuItem, {
        className: _vitals_biometrics_action_menu_scss__WEBPACK_IMPORTED_MODULE_6__["default"].menuItem,
        id: "deleteVitalsAndBiometrics",
        itemText: t('delete', 'Delete'),
        onClick: handleLaunchDeleteVitalsAndBiometricsModal,
        isDelete: true,
        hasDivider: true
    })));
};


/***/ }),

/***/ "./src/config-schema.ts":
/*!******************************!*\
  !*** ./src/config-schema.ts ***!
  \******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   configSchema: () => (/* binding */ configSchema)
/* harmony export */ });
/* harmony import */ var _openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @openmrs/esm-framework */ "webpack/sharing/consume/default/@openmrs/esm-framework/@openmrs/esm-framework");
/* harmony import */ var _openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_0__);

var configSchema = {
    concepts: {
        systolicBloodPressureUuid: {
            _type: _openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_0__.Type.ConceptUuid,
            _default: '5085AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA'
        },
        diastolicBloodPressureUuid: {
            _type: _openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_0__.Type.ConceptUuid,
            _default: '5086AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA'
        },
        pulseUuid: {
            _type: _openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_0__.Type.ConceptUuid,
            _default: '5087AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA'
        },
        temperatureUuid: {
            _type: _openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_0__.Type.ConceptUuid,
            _default: '5088AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA'
        },
        oxygenSaturationUuid: {
            _type: _openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_0__.Type.ConceptUuid,
            _default: '5092AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA'
        },
        heightUuid: {
            _type: _openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_0__.Type.ConceptUuid,
            _default: '5090AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA'
        },
        weightUuid: {
            _type: _openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_0__.Type.ConceptUuid,
            _default: '5089AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA'
        },
        respiratoryRateUuid: {
            _type: _openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_0__.Type.ConceptUuid,
            _default: '5242AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA'
        },
        generalPatientNoteUuid: {
            _type: _openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_0__.Type.ConceptUuid,
            _default: '165095AAAAAAAAAAAAAAAAAAAAAAAAAAAAAA'
        },
        midUpperArmCircumferenceUuid: {
            _type: _openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_0__.Type.ConceptUuid,
            _default: '1343AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA'
        },
        vitalSignsConceptSetUuid: {
            _type: _openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_0__.Type.ConceptUuid,
            _default: '1114AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA'
        }
    },
    vitals: {
        useFormEngine: {
            _type: _openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_0__.Type.Boolean,
            _default: false,
            _description: 'Whether to use an Ampath form as the vitals and biometrics form. If set to true, encounterUuid and formUuid must be set as well.'
        },
        encounterTypeUuid: {
            _type: _openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_0__.Type.UUID,
            _default: '67a71486-1a54-468f-ac3e-7091a9a79584'
        },
        logo: {
            src: {
                _type: _openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_0__.Type.String,
                _default: null,
                _description: 'A path or URL to an image. Defaults to the OpenMRS SVG sprite.'
            },
            alt: {
                _type: _openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_0__.Type.String,
                _default: 'Logo',
                _description: 'Alt text, shown on hover'
            },
            name: {
                _type: _openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_0__.Type.String,
                _default: null,
                _description: 'The organization name displayed when image is absent'
            }
        },
        showPrintButton: {
            _type: _openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_0__.Type.Boolean,
            _default: false,
            _description: 'Determines whether or not to display the Print button in the vitals datatable header. If set to true, a Print button gets shown as the right-most item in the table header. When clicked, this button enables the user to print out the contents of the table'
        },
        formUuid: {
            _type: _openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_0__.Type.UUID,
            _default: '9f26aad4-244a-46ca-be49-1196df1a8c9a'
        },
        formName: {
            _type: _openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_0__.Type.String,
            _default: 'Vitals'
        },
        useMuacColors: {
            _type: _openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_0__.Type.Boolean,
            _default: false,
            _description: 'Whether to show/use MUAC color codes. If set to true, the input will show status colors.'
        }
    },
    biometrics: {
        bmiUnit: {
            _type: _openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_0__.Type.String,
            _default: 'kg / m²'
        }
    }
};


/***/ }),

/***/ "./src/constants.ts":
/*!**************************!*\
  !*** ./src/constants.ts ***!
  \**************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   patientVitalsBiometricsFormWorkspace: () => (/* binding */ patientVitalsBiometricsFormWorkspace)
/* harmony export */ });
var patientVitalsBiometricsFormWorkspace = 'patient-vitals-biometrics-form-workspace';


/***/ }),

/***/ "./src/dashboard.meta.ts":
/*!*******************************!*\
  !*** ./src/dashboard.meta.ts ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   dashboardMeta: () => (/* binding */ dashboardMeta),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
var dashboardMeta = {
    id: 'vitals-and-biometrics',
    slot: 'patient-chart-vitals-biometrics-dashboard-slot',
    path: 'Individual Dashboard',
    title: 'Individual Dashboard',
    icon: 'omrs-icon-activity',
    widgets: [
        {
            name: 'vitalsSummary',
            order: 0
        },
        {
            name: 'vitalsMain',
            order: 1
        },
        {
            name: 'biometricsOverview',
            order: 2
        },
        {
            name: 'biometricsDetailedSummary',
            order: 3
        },
        {
            name: 'stigmaMonthlyAggregate',
            order: 4
        },
        {
            name: 'confDashboard',
            order: 5
        },
        {
            name: 'conferenceDashboard',
            order: 6
        }
    ]
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (dashboardMeta);


/***/ }),

/***/ "./src/index.ts":
/*!**********************!*\
  !*** ./src/index.ts ***!
  \**********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   biometricsDetailedSummary: () => (/* binding */ biometricsDetailedSummary),
/* harmony export */   biometricsOverview: () => (/* binding */ biometricsOverview),
/* harmony export */   confDashboard: () => (/* binding */ confDashboard),
/* harmony export */   confDashboardLink: () => (/* binding */ confDashboardLink),
/* harmony export */   importTranslation: () => (/* binding */ importTranslation),
/* harmony export */   startupApp: () => (/* binding */ startupApp),
/* harmony export */   stigmaDashboardButton: () => (/* binding */ stigmaDashboardButton),
/* harmony export */   stigmaMonthlyAggregate: () => (/* binding */ stigmaMonthlyAggregate),
/* harmony export */   vitalsAndBiometricsDashboardLink: () => (/* binding */ vitalsAndBiometricsDashboardLink),
/* harmony export */   vitalsAndBiometricsDeleteConfirmationModal: () => (/* binding */ vitalsAndBiometricsDeleteConfirmationModal),
/* harmony export */   vitalsHeader: () => (/* binding */ vitalsHeader),
/* harmony export */   vitalsMain: () => (/* binding */ vitalsMain),
/* harmony export */   vitalsSummary: () => (/* binding */ vitalsSummary),
/* harmony export */   weightTile: () => (/* binding */ weightTile)
/* harmony export */ });
/* harmony import */ var _openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @openmrs/esm-framework */ "webpack/sharing/consume/default/@openmrs/esm-framework/@openmrs/esm-framework");
/* harmony import */ var _openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _openmrs_esm_patient_common_lib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @openmrs/esm-patient-common-lib */ "webpack/sharing/consume/default/@openmrs/esm-patient-common-lib/@openmrs/esm-patient-common-lib");
/* harmony import */ var _openmrs_esm_patient_common_lib__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_openmrs_esm_patient_common_lib__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _config_schema__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./config-schema */ "./src/config-schema.ts");
/* harmony import */ var _biometrics_biometrics_main_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./biometrics/biometrics-main.component */ "./src/biometrics/biometrics-main.component.tsx");
/* harmony import */ var _biometrics_biometrics_overview_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./biometrics/biometrics-overview.component */ "./src/biometrics/biometrics-overview.component.tsx");
/* harmony import */ var _dashboard_meta__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./dashboard.meta */ "./src/dashboard.meta.ts");
/* harmony import */ var _vitals_and_biometrics_header_vitals_header_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./vitals-and-biometrics-header/vitals-header.component */ "./src/vitals-and-biometrics-header/vitals-header.component.tsx");
/* harmony import */ var _vitals_vitals_main_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./vitals/vitals-main.component */ "./src/vitals/vitals-main.component.tsx");
/* harmony import */ var _vitals_vitals_summary_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./vitals/vitals-summary.component */ "./src/vitals/vitals-summary.component.tsx");
/* harmony import */ var _common_stigma_data_aggregate__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./common/stigma-data-aggregate */ "./src/common/stigma-data-aggregate.tsx");
/* harmony import */ var _common_conf_dashboard__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./common/conf_dashboard */ "./src/common/conf_dashboard.tsx");
/* harmony import */ var _common_debug_helper__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./common/debug-helper */ "./src/common/debug-helper.ts");
function _define_property(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
function _object_spread(target) {
    for(var i = 1; i < arguments.length; i++){
        var source = arguments[i] != null ? arguments[i] : {};
        var ownKeys = Object.keys(source);
        if (typeof Object.getOwnPropertySymbols === "function") {
            ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function(sym) {
                return Object.getOwnPropertyDescriptor(source, sym).enumerable;
            }));
        }
        ownKeys.forEach(function(key) {
            _define_property(target, key, source[key]);
        });
    }
    return target;
}
function ownKeys(object, enumerableOnly) {
    var keys = Object.keys(object);
    if (Object.getOwnPropertySymbols) {
        var symbols = Object.getOwnPropertySymbols(object);
        if (enumerableOnly) {
            symbols = symbols.filter(function(sym) {
                return Object.getOwnPropertyDescriptor(object, sym).enumerable;
            });
        }
        keys.push.apply(keys, symbols);
    }
    return keys;
}
function _object_spread_props(target, source) {
    source = source != null ? source : {};
    if (Object.getOwnPropertyDescriptors) {
        Object.defineProperties(target, Object.getOwnPropertyDescriptors(source));
    } else {
        ownKeys(Object(source)).forEach(function(key) {
            Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key));
        });
    }
    return target;
}











 // Import debug helper
var moduleName = '@openmrs/esm-patient-vitals-app';
var options = {
    featureName: 'patient-vitals',
    moduleName: moduleName
};
var importTranslation = __webpack_require__("./translations lazy .json$");
function startupApp() {
    (0,_openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_0__.messageOmrsServiceWorker)({
        type: 'registerDynamicRoute',
        pattern: "".concat(_openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_0__.fhirBaseUrl, "/Observation.+")
    });
    (0,_openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_0__.messageOmrsServiceWorker)({
        type: 'registerDynamicRoute',
        pattern: ".+".concat(_openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_0__.restBaseUrl, "/concept.+")
    });
    (0,_openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_0__.defineConfigSchema)(moduleName, _config_schema__WEBPACK_IMPORTED_MODULE_2__.configSchema);
}
var vitalsSummary = (0,_openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_0__.getSyncLifecycle)(_vitals_vitals_summary_component__WEBPACK_IMPORTED_MODULE_8__["default"], options);
var vitalsMain = (0,_openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_0__.getSyncLifecycle)(_vitals_vitals_main_component__WEBPACK_IMPORTED_MODULE_7__["default"], options);
var vitalsHeader = (0,_openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_0__.getSyncLifecycle)(_vitals_and_biometrics_header_vitals_header_component__WEBPACK_IMPORTED_MODULE_6__["default"], options);
var biometricsOverview = (0,_openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_0__.getSyncLifecycle)(_biometrics_biometrics_overview_component__WEBPACK_IMPORTED_MODULE_4__["default"], options);
var biometricsDetailedSummary = (0,_openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_0__.getSyncLifecycle)(_biometrics_biometrics_main_component__WEBPACK_IMPORTED_MODULE_3__["default"], options);
var vitalsAndBiometricsDashboardLink = // t('Vitals & Biometrics', 'Vitals & Biometrics')
(0,_openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_0__.getSyncLifecycle)((0,_openmrs_esm_patient_common_lib__WEBPACK_IMPORTED_MODULE_1__.createDashboardLink)(_object_spread_props(_object_spread({}, _dashboard_meta__WEBPACK_IMPORTED_MODULE_5__["default"]), {
    moduleName: moduleName
})), options);
var weightTile = (0,_openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_0__.getAsyncLifecycle)(function() {
    return __webpack_require__.e(/*! import() */ "src_components_weight-tile_weight-tile_component_tsx").then(__webpack_require__.bind(__webpack_require__, /*! ./components/weight-tile/weight-tile.component */ "./src/components/weight-tile/weight-tile.component.tsx"));
}, options);
// t('recordVitalsAndBiometrics', 'Record Vitals and Biometrics')
// export const vitalsBiometricsFormWorkspace = getAsyncLifecycle(
//   () => import('./vitals-biometrics-form/vitals-biometrics-form.workspace'),
//   options,
// );
var vitalsAndBiometricsDeleteConfirmationModal = (0,_openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_0__.getAsyncLifecycle)(function() {
    return __webpack_require__.e(/*! import() */ "src_components_delete-vitals-biometrics-modal_delete-vitals-biometrics_modal_tsx").then(__webpack_require__.bind(__webpack_require__, /*! ./components/delete-vitals-biometrics-modal/delete-vitals-biometrics.modal */ "./src/components/delete-vitals-biometrics-modal/delete-vitals-biometrics.modal.tsx"));
}, options);
var stigmaMonthlyAggregate = (0,_openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_0__.getSyncLifecycle)(_common_stigma_data_aggregate__WEBPACK_IMPORTED_MODULE_9__["default"], options);
// Hiding the conference dashboard component (लान्छना विश्लेषण नतिजाहरू)
var confDashboard = (0,_openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_0__.getSyncLifecycle)(_common_conf_dashboard__WEBPACK_IMPORTED_MODULE_10__["default"], options);
// Hiding the conference dashboard link
var confDashboardLink = (0,_openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_0__.getSyncLifecycle)((0,_openmrs_esm_patient_common_lib__WEBPACK_IMPORTED_MODULE_1__.createDashboardLink)(_object_spread_props(_object_spread({}, _dashboard_meta__WEBPACK_IMPORTED_MODULE_5__["default"]), {
    title: 'Conference Dashboard',
    moduleName: moduleName
})), options);
// Register the stigma dashboard button component for patient actions
// This component is already commented out in the imports
var stigmaDashboardButton = (0,_openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_0__.getSyncLifecycle)(stigmaDashboardButton, {
    featureName: 'patient-actions-slot',
    moduleName: moduleName
}); // Register the stigma dashboard workspace
 // export const stigmaDashboardWorkspace = getAsyncLifecycle(() => import('./common/stigma-dashboard.workspace'), {
 //   featureName: 'stigma-dashboard',
 //   moduleName,
 // });
 // // Register the data visualization button in the global nav
 // export const dataVisualizationNavButton = getAsyncLifecycle(
 //   () => import('./navbar/data-visualization-button.component'),
 //   {
 //     featureName: 'data-visualization-nav',
 //     moduleName,
 //   },
 // );


/***/ }),

/***/ "./src/utils.ts":
/*!**********************!*\
  !*** ./src/utils.ts ***!
  \**********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   useLaunchVitalsAndBiometricsForm: () => (/* binding */ useLaunchVitalsAndBiometricsForm)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @openmrs/esm-framework */ "webpack/sharing/consume/default/@openmrs/esm-framework/@openmrs/esm-framework");
/* harmony import */ var _openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _openmrs_esm_patient_common_lib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @openmrs/esm-patient-common-lib */ "webpack/sharing/consume/default/@openmrs/esm-patient-common-lib/@openmrs/esm-patient-common-lib");
/* harmony import */ var _openmrs_esm_patient_common_lib__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_openmrs_esm_patient_common_lib__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./constants */ "./src/constants.ts");
/* harmony import */ var _common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./common */ "./src/common/index.ts");





/**
 * Launches the appropriate workspace based on the current visit and configuration.
 * @param currentVisit - The current visit.
 * @param config - The configuration object.
 */ function useLaunchVitalsAndBiometricsForm() {
    var config = (0,_openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_1__.useConfig)();
    var _config_vitals = config.vitals, useFormEngine = _config_vitals.useFormEngine, formName = _config_vitals.formName, formUuid = _config_vitals.formUuid;
    var launchVitalsAndBiometricsForm = (0,_openmrs_esm_patient_common_lib__WEBPACK_IMPORTED_MODULE_2__.useLaunchWorkspaceRequiringVisit)(useFormEngine ? 'patient-form-entry-workspace' : _constants__WEBPACK_IMPORTED_MODULE_3__.patientVitalsBiometricsFormWorkspace);
    var launchVitalsAndBiometricsFormNoParams = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(function() {
        var workspaceProps = useFormEngine ? {
            workspaceTitle: formName,
            formInfo: {
                formUuid: formUuid,
                encounterUuid: ''
            },
            mutateForm: _common__WEBPACK_IMPORTED_MODULE_4__.invalidateCachedVitalsAndBiometrics
        } : {};
        launchVitalsAndBiometricsForm(workspaceProps);
    }, [
        useFormEngine,
        formName,
        formUuid,
        launchVitalsAndBiometricsForm
    ]);
    return launchVitalsAndBiometricsFormNoParams;
}


/***/ }),

/***/ "./src/vitals-and-biometrics-header/vitals-header-item.component.tsx":
/*!***************************************************************************!*\
  !*** ./src/vitals-and-biometrics-header/vitals-header-item.component.tsx ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! classnames */ "../../node_modules/classnames/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-i18next */ "webpack/sharing/consume/default/react-i18next/react-i18next");
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_i18next__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _vitals_header_item_scss__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./vitals-header-item.scss */ "./src/vitals-and-biometrics-header/vitals-header-item.scss");
function _define_property(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}




var VitalsHeaderItem = function(param) {
    var interpretation = param.interpretation, value = param.value, unitName = param.unitName, unitSymbol = param.unitSymbol;
    var t = (0,react_i18next__WEBPACK_IMPORTED_MODULE_2__.useTranslation)().t;
    var flaggedCritical = interpretation && interpretation.includes('critically');
    var flaggedAbnormal = interpretation && interpretation !== 'normal';
    var generatedId = (0,react__WEBPACK_IMPORTED_MODULE_0__.useId)();
    var trimmedUnitName = unitName.trim().toLowerCase();
    var unitNameWithoutSpaces = trimmedUnitName.replace(/\s+/g, '-');
    var labelId = "omrs-patient-chart-label-".concat(unitNameWithoutSpaces, "-").concat(generatedId);
    var valueId = "omrs-patient-chart-value-".concat(unitNameWithoutSpaces, "-").concat(generatedId);
    var unitId = "omrs-patient-chart-unit-".concat(unitNameWithoutSpaces, "-").concat(generatedId);
    var displayValue = Boolean(value) ? value : t('notAvailable', 'Not available');
    var _obj;
    return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement("section", {
        className: _vitals_header_item_scss__WEBPACK_IMPORTED_MODULE_3__["default"].container
    }, /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_1___default()((_obj = {}, _define_property(_obj, _vitals_header_item_scss__WEBPACK_IMPORTED_MODULE_3__["default"]['critical-value'], flaggedCritical), _define_property(_obj, _vitals_header_item_scss__WEBPACK_IMPORTED_MODULE_3__["default"]['abnormal-value'], flaggedAbnormal), _obj))
    }, /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", {
        className: _vitals_header_item_scss__WEBPACK_IMPORTED_MODULE_3__["default"]['label-container']
    }, /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", {
        id: labelId,
        className: _vitals_header_item_scss__WEBPACK_IMPORTED_MODULE_3__["default"].label
    }, unitName), flaggedAbnormal ? /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", {
        className: _vitals_header_item_scss__WEBPACK_IMPORTED_MODULE_3__["default"][interpretation.replace('_', '-')],
        title: t('abnormalValue', 'Abnormal value')
    }) : null), /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", {
        className: _vitals_header_item_scss__WEBPACK_IMPORTED_MODULE_3__["default"]['value-container']
    }, /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", {
        className: _vitals_header_item_scss__WEBPACK_IMPORTED_MODULE_3__["default"]['pad-right']
    }, /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", {
        id: valueId,
        "aria-labelledby": "".concat(labelId, " ").concat(unitId),
        className: _vitals_header_item_scss__WEBPACK_IMPORTED_MODULE_3__["default"].value
    }, displayValue), /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", {
        id: unitId,
        className: _vitals_header_item_scss__WEBPACK_IMPORTED_MODULE_3__["default"].units
    }, value ? " ".concat(unitSymbol) : '')))));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (VitalsHeaderItem);


/***/ }),

/***/ "./src/vitals-and-biometrics-header/vitals-header.component.tsx":
/*!**********************************************************************!*\
  !*** ./src/vitals-and-biometrics-header/vitals-header.component.tsx ***!
  \**********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! classnames */ "../../node_modules/classnames/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var dayjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! dayjs */ "webpack/sharing/consume/default/dayjs/dayjs");
/* harmony import */ var dayjs__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(dayjs__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var dayjs_plugin_duration__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! dayjs/plugin/duration */ "../../node_modules/dayjs/plugin/duration.js");
/* harmony import */ var dayjs_plugin_duration__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(dayjs_plugin_duration__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var dayjs_plugin_isToday__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! dayjs/plugin/isToday */ "../../node_modules/dayjs/plugin/isToday.js");
/* harmony import */ var dayjs_plugin_isToday__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(dayjs_plugin_isToday__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react-i18next */ "webpack/sharing/consume/default/react-i18next/react-i18next");
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_i18next__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _carbon_react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @carbon/react */ "../../node_modules/@carbon/react/es/index.js");
/* harmony import */ var _openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @openmrs/esm-framework */ "webpack/sharing/consume/default/@openmrs/esm-framework/@openmrs/esm-framework");
/* harmony import */ var _openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _openmrs_esm_patient_common_lib__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @openmrs/esm-patient-common-lib */ "webpack/sharing/consume/default/@openmrs/esm-patient-common-lib/@openmrs/esm-patient-common-lib");
/* harmony import */ var _openmrs_esm_patient_common_lib__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_openmrs_esm_patient_common_lib__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _common__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../common */ "./src/common/index.ts");
/* harmony import */ var _vitals_header_item_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./vitals-header-item.component */ "./src/vitals-and-biometrics-header/vitals-header-item.component.tsx");
/* harmony import */ var _vitals_header_scss__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./vitals-header.scss */ "./src/vitals-and-biometrics-header/vitals-header.scss");
/* harmony import */ var _common_img_notes_png__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../common/img/notes.png */ "./src/common/img/notes.png");
function _array_like_to_array(arr, len) {
    if (len == null || len > arr.length) len = arr.length;
    for(var i = 0, arr2 = new Array(len); i < len; i++)arr2[i] = arr[i];
    return arr2;
}
function _array_with_holes(arr) {
    if (Array.isArray(arr)) return arr;
}
function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) {
    try {
        var info = gen[key](arg);
        var value = info.value;
    } catch (error) {
        reject(error);
        return;
    }
    if (info.done) {
        resolve(value);
    } else {
        Promise.resolve(value).then(_next, _throw);
    }
}
function _async_to_generator(fn) {
    return function() {
        var self = this, args = arguments;
        return new Promise(function(resolve, reject) {
            var gen = fn.apply(self, args);
            function _next(value) {
                asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value);
            }
            function _throw(err) {
                asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err);
            }
            _next(undefined);
        });
    };
}
function _define_property(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
function _iterable_to_array_limit(arr, i) {
    var _i = arr == null ? null : typeof Symbol !== "undefined" && arr[Symbol.iterator] || arr["@@iterator"];
    if (_i == null) return;
    var _arr = [];
    var _n = true;
    var _d = false;
    var _s, _e;
    try {
        for(_i = _i.call(arr); !(_n = (_s = _i.next()).done); _n = true){
            _arr.push(_s.value);
            if (i && _arr.length === i) break;
        }
    } catch (err) {
        _d = true;
        _e = err;
    } finally{
        try {
            if (!_n && _i["return"] != null) _i["return"]();
        } finally{
            if (_d) throw _e;
        }
    }
    return _arr;
}
function _non_iterable_rest() {
    throw new TypeError("Invalid attempt to destructure non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _sliced_to_array(arr, i) {
    return _array_with_holes(arr) || _iterable_to_array_limit(arr, i) || _unsupported_iterable_to_array(arr, i) || _non_iterable_rest();
}
function _unsupported_iterable_to_array(o, minLen) {
    if (!o) return;
    if (typeof o === "string") return _array_like_to_array(o, minLen);
    var n = Object.prototype.toString.call(o).slice(8, -1);
    if (n === "Object" && o.constructor) n = o.constructor.name;
    if (n === "Map" || n === "Set") return Array.from(n);
    if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _array_like_to_array(o, minLen);
}
function _ts_generator(thisArg, body) {
    var f, y, t, _ = {
        label: 0,
        sent: function() {
            if (t[0] & 1) throw t[1];
            return t[1];
        },
        trys: [],
        ops: []
    }, g = Object.create((typeof Iterator === "function" ? Iterator : Object).prototype);
    return g.next = verb(0), g["throw"] = verb(1), g["return"] = verb(2), typeof Symbol === "function" && (g[Symbol.iterator] = function() {
        return this;
    }), g;
    function verb(n) {
        return function(v) {
            return step([
                n,
                v
            ]);
        };
    }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while(g && (g = 0, op[0] && (_ = 0)), _)try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [
                op[0] & 2,
                t.value
            ];
            switch(op[0]){
                case 0:
                case 1:
                    t = op;
                    break;
                case 4:
                    _.label++;
                    return {
                        value: op[1],
                        done: false
                    };
                case 5:
                    _.label++;
                    y = op[1];
                    op = [
                        0
                    ];
                    continue;
                case 7:
                    op = _.ops.pop();
                    _.trys.pop();
                    continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
                        _ = 0;
                        continue;
                    }
                    if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
                        _.label = op[1];
                        break;
                    }
                    if (op[0] === 6 && _.label < t[1]) {
                        _.label = t[1];
                        t = op;
                        break;
                    }
                    if (t && _.label < t[2]) {
                        _.label = t[2];
                        _.ops.push(op);
                        break;
                    }
                    if (t[2]) _.ops.pop();
                    _.trys.pop();
                    continue;
            }
            op = body.call(thisArg, _);
        } catch (e) {
            op = [
                6,
                e
            ];
            y = 0;
        } finally{
            f = t = 0;
        }
        if (op[0] & 5) throw op[1];
        return {
            value: op[0] ? op[1] : void 0,
            done: true
        };
    }
}





dayjs__WEBPACK_IMPORTED_MODULE_2___default().extend((dayjs_plugin_isToday__WEBPACK_IMPORTED_MODULE_4___default()));
dayjs__WEBPACK_IMPORTED_MODULE_2___default().extend((dayjs_plugin_duration__WEBPACK_IMPORTED_MODULE_3___default()));








var VitalsHeader = function(param) {
    var patientUuid = param.patientUuid, _param_hideLinks = param.hideLinks, hideLinks = _param_hideLinks === void 0 ? false : _param_hideLinks;
    var _user_roles;
    var t = (0,react_i18next__WEBPACK_IMPORTED_MODULE_5__.useTranslation)().t;
    var config = (0,_openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_7__.useConfig)();
    var conceptUnits = (0,_common__WEBPACK_IMPORTED_MODULE_9__.useConceptUnits)().conceptUnits;
    var _useVitalsAndBiometrics = (0,_common__WEBPACK_IMPORTED_MODULE_9__.useVitalsAndBiometrics)(patientUuid, 'both'), vitals = _useVitalsAndBiometrics.data, isLoading = _useVitalsAndBiometrics.isLoading, isValidating = _useVitalsAndBiometrics.isValidating;
    var conceptRanges = (0,_common__WEBPACK_IMPORTED_MODULE_9__.useVitalsConceptMetadata)(patientUuid).conceptRanges;
    var latestVitals = vitals === null || vitals === void 0 ? void 0 : vitals[0];
    var currentVisit = (0,_openmrs_esm_patient_common_lib__WEBPACK_IMPORTED_MODULE_8__.useVisitOrOfflineVisit)(patientUuid).currentVisit;
    var workspaces = (0,_openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_7__.useWorkspaces)().workspaces;
    var user = (0,_openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_7__.useSession)().user;
    var userRoles = (user === null || user === void 0 ? void 0 : (_user_roles = user.roles) === null || _user_roles === void 0 ? void 0 : _user_roles.map(function(r) {
        var _r_display;
        return (_r_display = r.display) === null || _r_display === void 0 ? void 0 : _r_display.toLowerCase();
    })) || [];
    var isHCW = userRoles.includes('include_hcw');
    var _useState = _sliced_to_array((0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null), 2), pendingPatientUuid = _useState[0], setPendingPatientUuid = _useState[1];
    var _useState1 = _sliced_to_array((0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false), 2), launchFormAfterReady = _useState1[0], setLaunchFormAfterReady = _useState1[1];
    var isWorkspaceOpen = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(function() {
        return Boolean(workspaces === null || workspaces === void 0 ? void 0 : workspaces.length);
    }, [
        workspaces
    ]);
    // Handle delayed form launch
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(function() {
        if (launchFormAfterReady && pendingPatientUuid) {
            var launchForm = function() {
                return _async_to_generator(function() {
                    var _currentVisit_uuid, error;
                    return _ts_generator(this, function(_state) {
                        switch(_state.label){
                            case 0:
                                // Wait a bit to ensure WorkspaceContainer is mounted
                                return [
                                    4,
                                    new Promise(function(r) {
                                        return setTimeout(r, 500);
                                    })
                                ];
                            case 1:
                                _state.sent();
                                _state.label = 2;
                            case 2:
                                _state.trys.push([
                                    2,
                                    4,
                                    5,
                                    6
                                ]);
                                return [
                                    4,
                                    (0,_openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_7__.launchWorkspace)(_openmrs_esm_patient_common_lib__WEBPACK_IMPORTED_MODULE_8__.formEntryWorkspace, {
                                        workspaceTitle: 'काउन्सिलर फारम',
                                        formInfo: {
                                            patientUuid: pendingPatientUuid,
                                            formUuid: 'effc3190-3189-4fc2-9a19-ffee5d5ece95',
                                            encounterUuid: undefined,
                                            visitUuid: (_currentVisit_uuid = currentVisit === null || currentVisit === void 0 ? void 0 : currentVisit.uuid) !== null && _currentVisit_uuid !== void 0 ? _currentVisit_uuid : undefined,
                                            visitTypeUuid: undefined,
                                            visitStartDatetime: undefined,
                                            visitStopDatetime: undefined,
                                            htmlForm: null,
                                            mode: 'enter'
                                        }
                                    })
                                ];
                            case 3:
                                _state.sent();
                                console.log('[Form Debug] Counselor form launched successfully');
                                return [
                                    3,
                                    6
                                ];
                            case 4:
                                error = _state.sent();
                                console.error('[Form Debug] Error launching counselor form:', error);
                                return [
                                    3,
                                    6
                                ];
                            case 5:
                                setLaunchFormAfterReady(false);
                                setPendingPatientUuid(null);
                                return [
                                    7
                                ];
                            case 6:
                                return [
                                    2
                                ];
                        }
                    });
                })();
            };
            launchForm();
        }
    }, [
        launchFormAfterReady,
        pendingPatientUuid,
        currentVisit === null || currentVisit === void 0 ? void 0 : currentVisit.uuid
    ]);
    if (isLoading) {
        return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_carbon_react__WEBPACK_IMPORTED_MODULE_6__.InlineLoading, {
            role: "progressbar",
            className: _vitals_header_scss__WEBPACK_IMPORTED_MODULE_11__["default"].loading,
            description: "".concat(t('loading', 'Loading'), " ...")
        });
    }
    // Show vitals if available
    if (latestVitals && Object.keys(latestVitals).length && (conceptRanges === null || conceptRanges === void 0 ? void 0 : conceptRanges.length)) {
        var hasActiveVisit = Boolean(currentVisit === null || currentVisit === void 0 ? void 0 : currentVisit.uuid);
        var vitalsTakenToday = Boolean(dayjs__WEBPACK_IMPORTED_MODULE_2___default()(latestVitals === null || latestVitals === void 0 ? void 0 : latestVitals.date).isToday());
        var vitalsOverdue = hasActiveVisit && !vitalsTakenToday;
        var now = dayjs__WEBPACK_IMPORTED_MODULE_2___default()();
        var vitalsOverdueDayCount = Math.round(dayjs__WEBPACK_IMPORTED_MODULE_2___default().duration(now.diff(latestVitals === null || latestVitals === void 0 ? void 0 : latestVitals.date)).asDays());
        var overdueVitalsTagContent = null;
        if (vitalsOverdueDayCount >= 1 && vitalsOverdueDayCount < 7) {
            overdueVitalsTagContent = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement(react_i18next__WEBPACK_IMPORTED_MODULE_5__.Trans, {
                i18nKey: "daysOldVitals",
                values: {
                    count: vitalsOverdueDayCount
                }
            }, /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", null, "These vitals are ", /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement("strong", null, vitalsOverdueDayCount, " day old")));
        } else if (vitalsOverdueDayCount >= 8 && vitalsOverdueDayCount <= 14) {
            overdueVitalsTagContent = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement(react_i18next__WEBPACK_IMPORTED_MODULE_5__.Trans, {
                i18nKey: "overOneWeekOldVitals"
            }, /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", null, "These vitals are ", /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement("strong", null, "over one week old")));
        } else {
            overdueVitalsTagContent = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement(react_i18next__WEBPACK_IMPORTED_MODULE_5__.Trans, {
                i18nKey: "outOfDateVitals"
            }, /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", null, "These vitals are ", /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement("strong", null, "out of date")));
        }
        var _ref, _latestVitals_systolic, _latestVitals_diastolic;
        return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", {
            className: _vitals_header_scss__WEBPACK_IMPORTED_MODULE_11__["default"].container
        }, /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", {
            className: _vitals_header_scss__WEBPACK_IMPORTED_MODULE_11__["default"].vitalsHeader
        }, /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", {
            className: _vitals_header_scss__WEBPACK_IMPORTED_MODULE_11__["default"].headerItems
        }, /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", {
            className: _vitals_header_scss__WEBPACK_IMPORTED_MODULE_11__["default"].heading
        }, t('vitalsAndBiometrics', '')), /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", {
            className: _vitals_header_scss__WEBPACK_IMPORTED_MODULE_11__["default"].bodyText
        }, (0,_openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_7__.formatDate)((0,_openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_7__.parseDate)(latestVitals === null || latestVitals === void 0 ? void 0 : latestVitals.date), {
            day: true,
            time: true
        })), vitalsOverdue && /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_carbon_react__WEBPACK_IMPORTED_MODULE_6__.Tag, {
            className: _vitals_header_scss__WEBPACK_IMPORTED_MODULE_11__["default"].tag,
            type: "red"
        }, overdueVitalsTagContent), hideLinks && /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_7__.ConfigurableLink, {
            className: _vitals_header_scss__WEBPACK_IMPORTED_MODULE_11__["default"].link,
            to: "${openmrsSpaBase}/patient/".concat(patientUuid, "/chart/Vitals & Biometrics")
        }, t('vitalsHistory', 'Vitals history')))), /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", {
            className: classnames__WEBPACK_IMPORTED_MODULE_1___default()(_vitals_header_scss__WEBPACK_IMPORTED_MODULE_11__["default"].rowContainer, _define_property({}, _vitals_header_scss__WEBPACK_IMPORTED_MODULE_11__["default"].workspaceOpen, isWorkspaceOpen()))
        }, /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", {
            className: _vitals_header_scss__WEBPACK_IMPORTED_MODULE_11__["default"].row
        }, /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_vitals_header_item_component__WEBPACK_IMPORTED_MODULE_10__["default"], {
            interpretation: (0,_common__WEBPACK_IMPORTED_MODULE_9__.interpretBloodPressure)(latestVitals === null || latestVitals === void 0 ? void 0 : latestVitals.systolic, latestVitals === null || latestVitals === void 0 ? void 0 : latestVitals.diastolic, config === null || config === void 0 ? void 0 : config.concepts, conceptRanges),
            unitName: t('bp', 'BP'),
            unitSymbol: (_ref = (latestVitals === null || latestVitals === void 0 ? void 0 : latestVitals.systolic) && conceptUnits.get(config.concepts.systolicBloodPressureUuid)) !== null && _ref !== void 0 ? _ref : '',
            value: "".concat((_latestVitals_systolic = latestVitals === null || latestVitals === void 0 ? void 0 : latestVitals.systolic) !== null && _latestVitals_systolic !== void 0 ? _latestVitals_systolic : '--', " / ").concat((_latestVitals_diastolic = latestVitals === null || latestVitals === void 0 ? void 0 : latestVitals.diastolic) !== null && _latestVitals_diastolic !== void 0 ? _latestVitals_diastolic : '--')
        }))));
    }
    // Empty state with form launch button
    return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", {
        className: _vitals_header_scss__WEBPACK_IMPORTED_MODULE_11__["default"].emptyStateVitalsHeader
    }, /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", {
        className: _vitals_header_scss__WEBPACK_IMPORTED_MODULE_11__["default"].container
    }, /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", {
        className: _vitals_header_scss__WEBPACK_IMPORTED_MODULE_11__["default"].introBox
    }, /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement("p", {
        className: _vitals_header_scss__WEBPACK_IMPORTED_MODULE_11__["default"].introText
    }, t('vitalsAndBiometricsIntro', 'कृपया काउन्सिलर फारम खोल्नुहोस् र निर्देशन अनुसार सहभागीलाई प्रश्नहरु सोध्नुहोला।'))), /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", {
        className: _vitals_header_scss__WEBPACK_IMPORTED_MODULE_11__["default"].bodyText
    }, t('noDataRecorded', ' ')), isHCW && /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null, /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", {
        className: _vitals_header_scss__WEBPACK_IMPORTED_MODULE_11__["default"].separator
    }), /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_carbon_react__WEBPACK_IMPORTED_MODULE_6__.Button, {
        className: _vitals_header_scss__WEBPACK_IMPORTED_MODULE_11__["default"].customButton,
        // renderIcon={DocumentIcon}
        onClick: function() {
            setPendingPatientUuid(patientUuid);
            setLaunchFormAfterReady(true);
        }
    }, t('openCounselorForm', 'काउन्सिलर फारम  '), /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement("img", {
        src: _common_img_notes_png__WEBPACK_IMPORTED_MODULE_12__,
        alt: "icon",
        className: _vitals_header_scss__WEBPACK_IMPORTED_MODULE_11__["default"].buttonImage,
        style: {
            marginLeft: '8px',
            height: '20px'
        }
    })))));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (VitalsHeader);


/***/ }),

/***/ "./src/vitals/paginated-vitals.component.tsx":
/*!***************************************************!*\
  !*** ./src/vitals/paginated-vitals.component.tsx ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-i18next */ "webpack/sharing/consume/default/react-i18next/react-i18next");
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_i18next__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _carbon_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @carbon/react */ "../../node_modules/@carbon/react/es/index.js");
/* harmony import */ var _openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @openmrs/esm-framework */ "webpack/sharing/consume/default/@openmrs/esm-framework/@openmrs/esm-framework");
/* harmony import */ var _openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _openmrs_esm_patient_common_lib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @openmrs/esm-patient-common-lib */ "webpack/sharing/consume/default/@openmrs/esm-patient-common-lib/@openmrs/esm-patient-common-lib");
/* harmony import */ var _openmrs_esm_patient_common_lib__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_openmrs_esm_patient_common_lib__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _components_action_menu_vitals_biometrics_action_menu_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../components/action-menu/vitals-biometrics-action-menu.component */ "./src/components/action-menu/vitals-biometrics-action-menu.component.tsx");
/* harmony import */ var _paginated_vitals_scss__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./paginated-vitals.scss */ "./src/vitals/paginated-vitals.scss");
function _array_like_to_array(arr, len) {
    if (len == null || len > arr.length) len = arr.length;
    for(var i = 0, arr2 = new Array(len); i < len; i++)arr2[i] = arr[i];
    return arr2;
}
function _array_with_holes(arr) {
    if (Array.isArray(arr)) return arr;
}
function _define_property(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
function _iterable_to_array_limit(arr, i) {
    var _i = arr == null ? null : typeof Symbol !== "undefined" && arr[Symbol.iterator] || arr["@@iterator"];
    if (_i == null) return;
    var _arr = [];
    var _n = true;
    var _d = false;
    var _s, _e;
    try {
        for(_i = _i.call(arr); !(_n = (_s = _i.next()).done); _n = true){
            _arr.push(_s.value);
            if (i && _arr.length === i) break;
        }
    } catch (err) {
        _d = true;
        _e = err;
    } finally{
        try {
            if (!_n && _i["return"] != null) _i["return"]();
        } finally{
            if (_d) throw _e;
        }
    }
    return _arr;
}
function _non_iterable_rest() {
    throw new TypeError("Invalid attempt to destructure non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _object_spread(target) {
    for(var i = 1; i < arguments.length; i++){
        var source = arguments[i] != null ? arguments[i] : {};
        var ownKeys = Object.keys(source);
        if (typeof Object.getOwnPropertySymbols === "function") {
            ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function(sym) {
                return Object.getOwnPropertyDescriptor(source, sym).enumerable;
            }));
        }
        ownKeys.forEach(function(key) {
            _define_property(target, key, source[key]);
        });
    }
    return target;
}
function ownKeys(object, enumerableOnly) {
    var keys = Object.keys(object);
    if (Object.getOwnPropertySymbols) {
        var symbols = Object.getOwnPropertySymbols(object);
        if (enumerableOnly) {
            symbols = symbols.filter(function(sym) {
                return Object.getOwnPropertyDescriptor(object, sym).enumerable;
            });
        }
        keys.push.apply(keys, symbols);
    }
    return keys;
}
function _object_spread_props(target, source) {
    source = source != null ? source : {};
    if (Object.getOwnPropertyDescriptors) {
        Object.defineProperties(target, Object.getOwnPropertyDescriptors(source));
    } else {
        ownKeys(Object(source)).forEach(function(key) {
            Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key));
        });
    }
    return target;
}
function _sliced_to_array(arr, i) {
    return _array_with_holes(arr) || _iterable_to_array_limit(arr, i) || _unsupported_iterable_to_array(arr, i) || _non_iterable_rest();
}
function _unsupported_iterable_to_array(o, minLen) {
    if (!o) return;
    if (typeof o === "string") return _array_like_to_array(o, minLen);
    var n = Object.prototype.toString.call(o).slice(8, -1);
    if (n === "Object" && o.constructor) n = o.constructor.name;
    if (n === "Map" || n === "Set") return Array.from(n);
    if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _array_like_to_array(o, minLen);
}







var PaginatedVitals = function(param) {
    var isPrinting = param.isPrinting, pageSize = param.pageSize, pageUrl = param.pageUrl, tableHeaders = param.tableHeaders, tableRows = param.tableRows, urlLabel = param.urlLabel;
    var t = (0,react_i18next__WEBPACK_IMPORTED_MODULE_1__.useTranslation)().t;
    var isTablet = (0,_openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_3__.useLayoutType)() === 'tablet';
    var StyledTableCell = function(param) {
        var children = param.children, interpretation = param.interpretation;
        switch(interpretation){
            case 'critically_high':
                return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_carbon_react__WEBPACK_IMPORTED_MODULE_2__.TableCell, {
                    className: _paginated_vitals_scss__WEBPACK_IMPORTED_MODULE_6__["default"].criticallyHigh
                }, children);
            case 'critically_low':
                return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_carbon_react__WEBPACK_IMPORTED_MODULE_2__.TableCell, {
                    className: _paginated_vitals_scss__WEBPACK_IMPORTED_MODULE_6__["default"].criticallyLow
                }, children);
            case 'high':
                return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_carbon_react__WEBPACK_IMPORTED_MODULE_2__.TableCell, {
                    className: _paginated_vitals_scss__WEBPACK_IMPORTED_MODULE_6__["default"].high
                }, children);
            case 'low':
                return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_carbon_react__WEBPACK_IMPORTED_MODULE_2__.TableCell, {
                    className: _paginated_vitals_scss__WEBPACK_IMPORTED_MODULE_6__["default"].low
                }, children);
            default:
                return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_carbon_react__WEBPACK_IMPORTED_MODULE_2__.TableCell, null, children);
        }
    };
    var _useState = _sliced_to_array((0,react__WEBPACK_IMPORTED_MODULE_0__.useState)({
        key: '',
        sortDirection: 'NONE'
    }), 2), sortParams = _useState[0], setSortParams = _useState[1];
    var handleSorting = function(cellA, cellB, param) {
        var key = param.key, sortDirection = param.sortDirection;
        if (sortDirection === 'NONE') {
            setSortParams({
                key: '',
                sortDirection: sortDirection
            });
        } else {
            setSortParams({
                key: key,
                sortDirection: sortDirection
            });
        }
    };
    var sortedData = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(function() {
        if (sortParams.sortDirection === 'NONE') {
            return tableRows;
        }
        var header = tableHeaders.find(function(header) {
            return header.key === sortParams.key;
        });
        if (!header) {
            return tableRows;
        }
        var sortedRows = tableRows.slice().sort(function(rowA, rowB) {
            var sortingNum = header.sortFunc(rowA, rowB);
            return sortParams.sortDirection === 'DESC' ? sortingNum : -sortingNum;
        });
        return sortedRows;
    }, [
        tableHeaders,
        tableRows,
        sortParams
    ]);
    var _usePagination = (0,_openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_3__.usePagination)(sortedData, pageSize), paginatedVitals = _usePagination.results, goTo = _usePagination.goTo, currentPage = _usePagination.currentPage;
    var rows = isPrinting ? sortedData : paginatedVitals;
    return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null, /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_carbon_react__WEBPACK_IMPORTED_MODULE_2__.DataTable, {
        headers: tableHeaders,
        isSortable: true,
        overflowMenuOnHover: !isTablet,
        rows: rows,
        size: isTablet ? 'lg' : 'sm',
        sortRow: handleSorting,
        useZebraStyles: true
    }, function(param) {
        var rows = param.rows, headers = param.headers, getTableProps = param.getTableProps, getHeaderProps = param.getHeaderProps;
        return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_carbon_react__WEBPACK_IMPORTED_MODULE_2__.TableContainer, {
            className: _paginated_vitals_scss__WEBPACK_IMPORTED_MODULE_6__["default"].tableContainer
        }, /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_carbon_react__WEBPACK_IMPORTED_MODULE_2__.Table, _object_spread({
            "aria-label": "vitals",
            className: _paginated_vitals_scss__WEBPACK_IMPORTED_MODULE_6__["default"].table
        }, getTableProps()), /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_carbon_react__WEBPACK_IMPORTED_MODULE_2__.TableHead, null, /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_carbon_react__WEBPACK_IMPORTED_MODULE_2__.TableRow, null, headers.map(function(header) {
            var _header_header;
            var _header_header_content;
            return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_carbon_react__WEBPACK_IMPORTED_MODULE_2__.TableHeader, _object_spread_props(_object_spread({}, getHeaderProps({
                header: header,
                isSortable: header.isSortable
            })), {
                key: header.key
            }), (_header_header_content = (_header_header = header.header) === null || _header_header === void 0 ? void 0 : _header_header.content) !== null && _header_header_content !== void 0 ? _header_header_content : header.header);
        }), /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_carbon_react__WEBPACK_IMPORTED_MODULE_2__.TableHeader, {
            "aria-label": t('actions', 'Actions')
        }))), /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_carbon_react__WEBPACK_IMPORTED_MODULE_2__.TableBody, null, rows.map(function(row) {
            return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_carbon_react__WEBPACK_IMPORTED_MODULE_2__.TableRow, {
                key: row.id
            }, row.cells.map(function(cell) {
                var _cell_value;
                var vitalsObj = paginatedVitals.find(function(obj) {
                    return obj.id === row.id;
                });
                var interpretationKey = cell.info.header + 'Interpretation';
                var interpretation = vitalsObj === null || vitalsObj === void 0 ? void 0 : vitalsObj[interpretationKey];
                var _cell_value_content;
                return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement(StyledTableCell, {
                    key: "styled-cell-".concat(cell.id),
                    interpretation: interpretation
                }, typeof cell.value === 'string' && cell.value.includes('\n') ? cell.value.split('\n').map(function(line, idx) {
                    return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", {
                        key: idx
                    }, line);
                }) : (_cell_value_content = (_cell_value = cell.value) === null || _cell_value === void 0 ? void 0 : _cell_value.content) !== null && _cell_value_content !== void 0 ? _cell_value_content : cell.value);
            }), /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_carbon_react__WEBPACK_IMPORTED_MODULE_2__.TableCell, {
                className: "cds--table-column-menu",
                id: "actions"
            }, /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_components_action_menu_vitals_biometrics_action_menu_component__WEBPACK_IMPORTED_MODULE_5__.VitalsAndBiometricsActionMenu, {
                encounterUuid: row.id
            })));
        }))));
    }), !isPrinting ? /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_openmrs_esm_patient_common_lib__WEBPACK_IMPORTED_MODULE_4__.PatientChartPagination, {
        pageNumber: currentPage,
        totalItems: tableRows.length,
        currentItems: paginatedVitals.length,
        pageSize: pageSize,
        onPageNumberChange: function(param) {
            var page = param.page;
            return goTo(page);
        },
        dashboardLinkUrl: pageUrl,
        dashboardLinkLabel: urlLabel
    }) : null);
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (PaginatedVitals);


/***/ }),

/***/ "./src/vitals/print/print.component.tsx":
/*!**********************************************!*\
  !*** ./src/vitals/print/print.component.tsx ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   PrintComponent: () => (/* binding */ PrintComponent),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-i18next */ "webpack/sharing/consume/default/react-i18next/react-i18next");
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_i18next__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @openmrs/esm-framework */ "webpack/sharing/consume/default/@openmrs/esm-framework/@openmrs/esm-framework");
/* harmony import */ var _openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _print_scss__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./print.scss */ "./src/vitals/print/print.scss");




function PrintComponent(param) {
    var subheader = param.subheader, patientDetails = param.patientDetails;
    var _session_user;
    var t = (0,react_i18next__WEBPACK_IMPORTED_MODULE_1__.useTranslation)().t;
    var _useConfig = (0,_openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_2__.useConfig)(), logo = _useConfig.vitals.logo;
    var session = (0,_openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_2__.useSession)();
    return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", {
        className: _print_scss__WEBPACK_IMPORTED_MODULE_3__["default"].printPage
    }, /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement("header", {
        className: _print_scss__WEBPACK_IMPORTED_MODULE_3__["default"].header
    }, (logo === null || logo === void 0 ? void 0 : logo.src) ? /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement("img", {
        className: _print_scss__WEBPACK_IMPORTED_MODULE_3__["default"].logo,
        src: (0,_openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_2__.interpolateUrl)(logo.src),
        alt: logo.alt,
        width: 110,
        height: 40
    }) : (logo === null || logo === void 0 ? void 0 : logo.name) ? logo.name : /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement("svg", {
        role: "img",
        width: 110,
        height: 40,
        viewBox: "0 0 380 119",
        xmlns: "http://www.w3.org/2000/svg"
    }, /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement("path", {
        fillRule: "evenodd",
        clipRule: "evenodd",
        d: "M40.29 40.328a27.755 27.755 0 0 1 19.688-8.154c7.669 0 14.613 3.102 19.647 8.116l.02-18.54A42.835 42.835 0 0 0 59.978 17c-7.089 0-13.813 1.93-19.709 4.968l.021 18.36ZM79.645 79.671a27.744 27.744 0 0 1-19.684 8.154c-7.67 0-14.614-3.101-19.651-8.116l-.02 18.54A42.857 42.857 0 0 0 59.96 103a42.833 42.833 0 0 0 19.672-4.751l.013-18.578ZM40.328 79.696c-5.038-5.037-8.154-11.995-8.154-19.685 0-7.669 3.102-14.612 8.116-19.65l-18.54-.02A42.85 42.85 0 0 0 17 60.012a42.819 42.819 0 0 0 4.752 19.672l18.576.013ZM79.634 40.289a27.753 27.753 0 0 1 8.154 19.688 27.744 27.744 0 0 1-8.117 19.646l18.542.02a42.842 42.842 0 0 0 4.749-19.666c0-7.09-1.714-13.779-4.751-19.675l-18.577-.013ZM156.184 60.002c0-8.748-6.118-15.776-15.025-15.776-8.909 0-15.025 7.028-15.025 15.776 0 8.749 6.116 15.78 15.025 15.78 8.907 0 15.025-7.031 15.025-15.78Zm-34.881 0c0-11.482 8.318-19.958 19.856-19.958 11.536 0 19.855 8.477 19.855 19.959 0 11.484-8.319 19.964-19.855 19.964-11.538 0-19.856-8.48-19.856-19.965ZM179.514 75.54c5.507 0 9.05-4.14 9.05-9.482 0-5.341-3.543-9.483-9.05-9.483-5.505 0-9.046 4.142-9.046 9.483 0 5.342 3.541 9.482 9.046 9.482ZM166.22 53.306h4.248v3.704h.11c2.344-2.725 5.449-4.36 9.154-4.36 8.014 0 13.408 5.67 13.408 13.408 0 7.63-5.613 13.406-12.752 13.406-4.58 0-8.231-2.29-9.81-5.178h-.11V90.87h-4.248V53.306ZM217.773 63.768c-.163-4.305-3-7.193-7.686-7.193-4.685 0-7.79 2.888-8.335 7.193h16.021Zm3.653 10.412c-3.001 3.868-6.596 5.284-11.339 5.284-8.01 0-12.914-5.993-12.914-13.406 0-7.901 5.559-13.407 13.08-13.407 7.196 0 12.096 4.906 12.096 13.354v1.362h-20.597c.325 4.413 3.704 8.173 8.335 8.173 3.65 0 6.105-1.307 8.12-3.868l3.219 2.508ZM227.854 59.356c0-2.346-.216-4.36-.216-6.05h4.031c0 1.363.11 2.777.11 4.195h.11c1.144-2.505 4.306-4.85 8.5-4.85 6.705 0 9.699 4.252 9.699 10.41v15.748h-4.248v-15.31c0-4.253-1.856-6.924-5.833-6.924-5.503 0-7.903 3.979-7.903 9.811V78.81h-4.25V59.356ZM259.211 41.008h6.708L278.8 70.791h.107l12.982-29.782h6.549v37.99h-4.506V47.124h-.106L280.192 79h-2.738l-13.629-31.875h-.107V79h-4.507V41.01ZM312.392 57.752h4.023c4.992 0 11.487 0 11.487-6.282 0-5.47-4.776-6.276-9.177-6.276h-6.333v12.558Zm-4.506-16.744h9.711c7.352 0 15.132 1.072 15.132 10.462 0 5.527-3.594 9.125-9.495 10.037L334.018 79h-5.525l-10.304-17.063h-5.797V79h-4.506V41.01ZM358.123 47.712c-1.506-2.413-4.187-3.486-6.926-3.486-3.973 0-8.1 1.88-8.1 6.385 0 3.49 1.931 5.047 7.994 6.98 5.903 1.878 11.377 3.809 11.377 11.267 0 7.567-6.495 11.11-13.36 11.11-4.402 0-9.125-1.45-11.7-5.262l3.862-3.165c1.61 2.794 4.83 4.24 8.105 4.24 3.862 0 8.263-2.253 8.263-6.601 0-4.669-3.165-5.474-9.928-7.728-5.366-1.771-9.442-4.134-9.442-10.463 0-7.298 6.277-10.945 12.929-10.945 4.241 0 7.836 1.178 10.625 4.45l-3.699 3.218Z"
    })), /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", {
        className: _print_scss__WEBPACK_IMPORTED_MODULE_3__["default"].patientDetails
    }, /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", {
        className: _print_scss__WEBPACK_IMPORTED_MODULE_3__["default"].name
    }, patientDetails === null || patientDetails === void 0 ? void 0 : patientDetails.name), /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", {
        className: _print_scss__WEBPACK_IMPORTED_MODULE_3__["default"].patientInfo
    }, patientDetails === null || patientDetails === void 0 ? void 0 : patientDetails.gender, ", ", patientDetails === null || patientDetails === void 0 ? void 0 : patientDetails.age, ", ", patientDetails === null || patientDetails === void 0 ? void 0 : patientDetails.identifiers, ' ')), /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", {
        className: _print_scss__WEBPACK_IMPORTED_MODULE_3__["default"].printedBy
    }, t('printedBy', 'Printed by'), /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", {
        className: _print_scss__WEBPACK_IMPORTED_MODULE_3__["default"].printedBy
    }, session === null || session === void 0 ? void 0 : (_session_user = session.user) === null || _session_user === void 0 ? void 0 : _session_user.display))), /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", {
        className: _print_scss__WEBPACK_IMPORTED_MODULE_3__["default"].subheader
    }, /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement("h4", null, subheader)));
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (PrintComponent);


/***/ }),

/***/ "./src/vitals/vitals-chart.component.tsx":
/*!***********************************************!*\
  !*** ./src/vitals/vitals-chart.component.tsx ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! classnames */ "../../node_modules/classnames/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-i18next */ "webpack/sharing/consume/default/react-i18next/react-i18next");
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_i18next__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _carbon_react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @carbon/react */ "../../node_modules/@carbon/react/es/index.js");
/* harmony import */ var _carbon_charts_react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @carbon/charts-react */ "../../node_modules/@carbon/charts-react/dist/index.mjs");
/* harmony import */ var _openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @openmrs/esm-framework */ "webpack/sharing/consume/default/@openmrs/esm-framework/@openmrs/esm-framework");
/* harmony import */ var _openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../common */ "./src/common/index.ts");
/* harmony import */ var _vitals_chart_scss__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./vitals-chart.scss */ "./src/vitals/vitals-chart.scss");
function _array_like_to_array(arr, len) {
    if (len == null || len > arr.length) len = arr.length;
    for(var i = 0, arr2 = new Array(len); i < len; i++)arr2[i] = arr[i];
    return arr2;
}
function _array_with_holes(arr) {
    if (Array.isArray(arr)) return arr;
}
function _define_property(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
function _iterable_to_array_limit(arr, i) {
    var _i = arr == null ? null : typeof Symbol !== "undefined" && arr[Symbol.iterator] || arr["@@iterator"];
    if (_i == null) return;
    var _arr = [];
    var _n = true;
    var _d = false;
    var _s, _e;
    try {
        for(_i = _i.call(arr); !(_n = (_s = _i.next()).done); _n = true){
            _arr.push(_s.value);
            if (i && _arr.length === i) break;
        }
    } catch (err) {
        _d = true;
        _e = err;
    } finally{
        try {
            if (!_n && _i["return"] != null) _i["return"]();
        } finally{
            if (_d) throw _e;
        }
    }
    return _arr;
}
function _non_iterable_rest() {
    throw new TypeError("Invalid attempt to destructure non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _sliced_to_array(arr, i) {
    return _array_with_holes(arr) || _iterable_to_array_limit(arr, i) || _unsupported_iterable_to_array(arr, i) || _non_iterable_rest();
}
function _unsupported_iterable_to_array(o, minLen) {
    if (!o) return;
    if (typeof o === "string") return _array_like_to_array(o, minLen);
    var n = Object.prototype.toString.call(o).slice(8, -1);
    if (n === "Object" && o.constructor) n = o.constructor.name;
    if (n === "Map" || n === "Set") return Array.from(n);
    if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _array_like_to_array(o, minLen);
}








var VitalsChart = function(param) {
    var patientVitals = param.patientVitals, conceptUnits = param.conceptUnits, config = param.config;
    var t = (0,react_i18next__WEBPACK_IMPORTED_MODULE_2__.useTranslation)().t;
    var id = (0,react__WEBPACK_IMPORTED_MODULE_0__.useId)();
    var _useState = _sliced_to_array((0,react__WEBPACK_IMPORTED_MODULE_0__.useState)({
        title: "".concat(t('bp', 'BP'), " (").concat(conceptUnits.get(config.concepts.systolicBloodPressureUuid), ")"),
        value: 'systolic'
    }), 2), selectedVitalsSign = _useState[0], setSelectedVitalsSign = _useState[1];
    var _conceptUnits_get, _conceptUnits_get1, _conceptUnits_get2, _conceptUnits_get3, _conceptUnits_get4;
    var vitalSigns = [
        {
            id: 'bloodPressure',
            title: (0,_common__WEBPACK_IMPORTED_MODULE_6__.withUnit)(t('bp', 'BP'), (_conceptUnits_get = conceptUnits.get(config.concepts.systolicBloodPressureUuid)) !== null && _conceptUnits_get !== void 0 ? _conceptUnits_get : '-'),
            value: 'systolic'
        },
        {
            id: 'oxygenSaturation',
            title: (0,_common__WEBPACK_IMPORTED_MODULE_6__.withUnit)(t('spo2', 'SpO2'), (_conceptUnits_get1 = conceptUnits.get(config.concepts.oxygenSaturationUuid)) !== null && _conceptUnits_get1 !== void 0 ? _conceptUnits_get1 : '-'),
            value: 'spo2'
        },
        {
            id: 'temperature',
            title: (0,_common__WEBPACK_IMPORTED_MODULE_6__.withUnit)(t('temp', 'Temp'), (_conceptUnits_get2 = conceptUnits.get(config.concepts.temperatureUuid)) !== null && _conceptUnits_get2 !== void 0 ? _conceptUnits_get2 : '-'),
            value: 'temperature'
        },
        {
            id: 'respiratoryRate',
            title: (0,_common__WEBPACK_IMPORTED_MODULE_6__.withUnit)(t('respiratoryRate', 'R. rate'), (_conceptUnits_get3 = conceptUnits.get(config.concepts.respiratoryRateUuid)) !== null && _conceptUnits_get3 !== void 0 ? _conceptUnits_get3 : '-'),
            value: 'respiratoryRate'
        },
        {
            id: 'pulse',
            title: (0,_common__WEBPACK_IMPORTED_MODULE_6__.withUnit)(t('pulse', 'Pulse'), (_conceptUnits_get4 = conceptUnits.get(config.concepts.pulseUuid)) !== null && _conceptUnits_get4 !== void 0 ? _conceptUnits_get4 : '-'),
            value: 'pulse'
        }
    ];
    var chartData = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(function() {
        return patientVitals.filter(function(vitals) {
            return vitals[selectedVitalsSign.value];
        }).slice(0, 10).sort(function(vitalA, vitalB) {
            return new Date(vitalA.date).getTime() - new Date(vitalB.date).getTime();
        }).map(function(vitals) {
            if ([
                'systolic',
                'diastolic'
            ].includes(selectedVitalsSign.value)) {
                return [
                    {
                        group: 'Systolic blood pressure',
                        key: (0,_openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_5__.formatDate)((0,_openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_5__.parseDate)(vitals.date), {
                            year: true
                        }),
                        value: vitals.systolic,
                        date: vitals.date
                    },
                    {
                        group: 'Diastolic blood pressure',
                        key: (0,_openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_5__.formatDate)((0,_openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_5__.parseDate)(vitals.date), {
                            year: true
                        }),
                        value: vitals.diastolic,
                        date: vitals.date
                    }
                ];
            }
            return {
                group: selectedVitalsSign.value,
                key: (0,_openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_5__.formatDate)((0,_openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_5__.parseDate)(vitals.date)),
                value: vitals[selectedVitalsSign.value],
                date: vitals.date
            };
        });
    }, [
        patientVitals,
        selectedVitalsSign
    ]);
    var chartOptions = {
        title: selectedVitalsSign.title,
        axes: {
            bottom: {
                title: t('date', 'Date'),
                mapsTo: 'date',
                scaleType: _carbon_charts_react__WEBPACK_IMPORTED_MODULE_4__.ScaleTypes.TIME
            },
            left: {
                mapsTo: 'value',
                title: selectedVitalsSign.title,
                scaleType: _carbon_charts_react__WEBPACK_IMPORTED_MODULE_4__.ScaleTypes.LINEAR,
                includeZero: false
            }
        },
        legend: {
            enabled: false
        },
        color: {
            scale: _define_property({}, selectedVitalsSign.title, '#6929c4')
        },
        tooltip: {
            customHTML: function(param) {
                var _param = _sliced_to_array(param, 1), _param_ = _param[0], value = _param_.value, group = _param_.group, key = _param_.key;
                return '<div class="cds--tooltip cds--tooltip--shown" style="min-width: max-content; font-weight:600">'.concat(value, " - ").concat(String(group).toUpperCase(), '\n        <span style="color: #c6c6c6; font-size: 1rem; font-weight:600">').concat(key, "</span></div>");
            }
        },
        toolbar: {
            enabled: true,
            numberOfIcons: 4,
            controls: [
                {
                    type: 'Zoom in'
                },
                {
                    type: 'Zoom out'
                },
                {
                    type: 'Reset zoom'
                },
                {
                    type: 'Export as CSV'
                },
                {
                    type: 'Export as PNG'
                },
                {
                    type: 'Make fullscreen'
                }
            ]
        },
        zoomBar: {
            top: {
                enabled: true
            }
        },
        height: '400px'
    };
    return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", {
        className: _vitals_chart_scss__WEBPACK_IMPORTED_MODULE_7__["default"].vitalsChartContainer
    }, /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", {
        className: _vitals_chart_scss__WEBPACK_IMPORTED_MODULE_7__["default"].vitalSignsArea
    }, /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement("label", {
        className: _vitals_chart_scss__WEBPACK_IMPORTED_MODULE_7__["default"].vitalsSignLabel,
        htmlFor: "".concat(id, "-tab")
    }, t('vitalSignDisplayed', 'Vital sign displayed')), /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_carbon_react__WEBPACK_IMPORTED_MODULE_3__.TabsVertical, null, /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_carbon_react__WEBPACK_IMPORTED_MODULE_3__.TabListVertical, {
        "aria-label": "Vitals tabs"
    }, vitalSigns.map(function(param) {
        var id = param.id, title = param.title, value = param.value;
        return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_carbon_react__WEBPACK_IMPORTED_MODULE_3__.Tab, {
            className: classnames__WEBPACK_IMPORTED_MODULE_1___default()(_vitals_chart_scss__WEBPACK_IMPORTED_MODULE_7__["default"].tab, _define_property({}, _vitals_chart_scss__WEBPACK_IMPORTED_MODULE_7__["default"].selectedTab, selectedVitalsSign.title === title)),
            id: "".concat(id, "-tab"),
            key: id,
            onClick: function() {
                return setSelectedVitalsSign({
                    title: title,
                    value: value
                });
            }
        }, title);
    })), /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_carbon_react__WEBPACK_IMPORTED_MODULE_3__.TabPanels, null, vitalSigns.map(function(param) {
        var id = param.id, title = param.title, value = param.value;
        return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_carbon_react__WEBPACK_IMPORTED_MODULE_3__.TabPanel, {
            key: id
        }, /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_carbon_charts_react__WEBPACK_IMPORTED_MODULE_4__.LineChart, {
            data: chartData.flat().filter(function(data) {
                return value === 'systolic' ? data.group === 'Systolic blood pressure' || data.group === 'Diastolic blood pressure' : data.group === value;
            }),
            options: chartOptions
        }));
    })))));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (VitalsChart);


/***/ }),

/***/ "./src/vitals/vitals-main.component.tsx":
/*!**********************************************!*\
  !*** ./src/vitals/vitals-main.component.tsx ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-i18next */ "webpack/sharing/consume/default/react-i18next/react-i18next");
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_i18next__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _vitals_overview_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./vitals-overview.component */ "./src/vitals/vitals-overview.component.tsx");



var VitalsMain = function(param) {
    var patientUuid = param.patientUuid, patient = param.patient;
    var pageSize = 10;
    var t = (0,react_i18next__WEBPACK_IMPORTED_MODULE_1__.useTranslation)().t;
    var pageUrl = "${openmrsSpaBase}/patient/".concat(patientUuid, "/chart");
    var urlLabel = t('goToSummary', 'Go to Summary');
    return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_vitals_overview_component__WEBPACK_IMPORTED_MODULE_2__["default"], {
        patientUuid: patientUuid,
        patient: patient,
        pageSize: pageSize,
        urlLabel: urlLabel,
        pageUrl: pageUrl
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (VitalsMain);


/***/ }),

/***/ "./src/vitals/vitals-overview.component.tsx":
/*!**************************************************!*\
  !*** ./src/vitals/vitals-overview.component.tsx ***!
  \**************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-i18next */ "webpack/sharing/consume/default/react-i18next/react-i18next");
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_i18next__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_to_print__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-to-print */ "../../node_modules/react-to-print/lib/index.js");
/* harmony import */ var react_to_print__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_to_print__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _carbon_react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @carbon/react */ "../../node_modules/@carbon/react/es/index.js");
/* harmony import */ var _openmrs_esm_patient_common_lib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @openmrs/esm-patient-common-lib */ "webpack/sharing/consume/default/@openmrs/esm-patient-common-lib/@openmrs/esm-patient-common-lib");
/* harmony import */ var _openmrs_esm_patient_common_lib__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_openmrs_esm_patient_common_lib__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @openmrs/esm-framework */ "webpack/sharing/consume/default/@openmrs/esm-framework/@openmrs/esm-framework");
/* harmony import */ var _openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../utils */ "./src/utils.ts");
/* harmony import */ var _common__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../common */ "./src/common/index.ts");
/* harmony import */ var _common_covid_stigma_data_resource__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../common/covid-stigma-data.resource */ "./src/common/covid-stigma-data.resource.tsx");
/* harmony import */ var _paginated_vitals_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./paginated-vitals.component */ "./src/vitals/paginated-vitals.component.tsx");
/* harmony import */ var _print_print_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./print/print.component */ "./src/vitals/print/print.component.tsx");
/* harmony import */ var _vitals_chart_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./vitals-chart.component */ "./src/vitals/vitals-chart.component.tsx");
/* harmony import */ var _vitals_overview_scss__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./vitals-overview.scss */ "./src/vitals/vitals-overview.scss");
/* harmony import */ var _common_stigma_data_aggregate__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../common/stigma-data-aggregate */ "./src/common/stigma-data-aggregate.tsx");
function _array_like_to_array(arr, len) {
    if (len == null || len > arr.length) len = arr.length;
    for(var i = 0, arr2 = new Array(len); i < len; i++)arr2[i] = arr[i];
    return arr2;
}
function _array_with_holes(arr) {
    if (Array.isArray(arr)) return arr;
}
function _array_without_holes(arr) {
    if (Array.isArray(arr)) return _array_like_to_array(arr);
}
function _define_property(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
function _iterable_to_array(iter) {
    if (typeof Symbol !== "undefined" && iter[Symbol.iterator] != null || iter["@@iterator"] != null) return Array.from(iter);
}
function _iterable_to_array_limit(arr, i) {
    var _i = arr == null ? null : typeof Symbol !== "undefined" && arr[Symbol.iterator] || arr["@@iterator"];
    if (_i == null) return;
    var _arr = [];
    var _n = true;
    var _d = false;
    var _s, _e;
    try {
        for(_i = _i.call(arr); !(_n = (_s = _i.next()).done); _n = true){
            _arr.push(_s.value);
            if (i && _arr.length === i) break;
        }
    } catch (err) {
        _d = true;
        _e = err;
    } finally{
        try {
            if (!_n && _i["return"] != null) _i["return"]();
        } finally{
            if (_d) throw _e;
        }
    }
    return _arr;
}
function _non_iterable_rest() {
    throw new TypeError("Invalid attempt to destructure non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _non_iterable_spread() {
    throw new TypeError("Invalid attempt to spread non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _object_spread(target) {
    for(var i = 1; i < arguments.length; i++){
        var source = arguments[i] != null ? arguments[i] : {};
        var ownKeys = Object.keys(source);
        if (typeof Object.getOwnPropertySymbols === "function") {
            ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function(sym) {
                return Object.getOwnPropertyDescriptor(source, sym).enumerable;
            }));
        }
        ownKeys.forEach(function(key) {
            _define_property(target, key, source[key]);
        });
    }
    return target;
}
function ownKeys(object, enumerableOnly) {
    var keys = Object.keys(object);
    if (Object.getOwnPropertySymbols) {
        var symbols = Object.getOwnPropertySymbols(object);
        if (enumerableOnly) {
            symbols = symbols.filter(function(sym) {
                return Object.getOwnPropertyDescriptor(object, sym).enumerable;
            });
        }
        keys.push.apply(keys, symbols);
    }
    return keys;
}
function _object_spread_props(target, source) {
    source = source != null ? source : {};
    if (Object.getOwnPropertyDescriptors) {
        Object.defineProperties(target, Object.getOwnPropertyDescriptors(source));
    } else {
        ownKeys(Object(source)).forEach(function(key) {
            Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key));
        });
    }
    return target;
}
function _sliced_to_array(arr, i) {
    return _array_with_holes(arr) || _iterable_to_array_limit(arr, i) || _unsupported_iterable_to_array(arr, i) || _non_iterable_rest();
}
function _to_consumable_array(arr) {
    return _array_without_holes(arr) || _iterable_to_array(arr) || _unsupported_iterable_to_array(arr) || _non_iterable_spread();
}
function _unsupported_iterable_to_array(o, minLen) {
    if (!o) return;
    if (typeof o === "string") return _array_like_to_array(o, minLen);
    var n = Object.prototype.toString.call(o).slice(8, -1);
    if (n === "Object" && o.constructor) n = o.constructor.name;
    if (n === "Map" || n === "Set") return Array.from(n);
    if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _array_like_to_array(o, minLen);
}









// import MultiChartSelector from '../common/stigma-data-aggregate'; // Commented out to hide






var VitalsOverview = function(param) {
    var patientUuid = param.patientUuid, patient = param.patient, pageSize = param.pageSize, urlLabel = param.urlLabel, pageUrl = param.pageUrl;
    var _user_roles;
    var t = (0,react_i18next__WEBPACK_IMPORTED_MODULE_1__.useTranslation)().t;
    var config = (0,_openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_5__.useConfig)();
    var headerTitle = t('vitals', 'Stigma Score');
    var _useState = _sliced_to_array((0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false), 2), chartView = _useState[0], setChartView = _useState[1];
    var _useState1 = _sliced_to_array((0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false), 2), showStigmaChart = _useState1[0], setShowStigmaChart = _useState1[1];
    var isTablet = (0,_openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_5__.useLayoutType)() === 'tablet';
    var _useState2 = _sliced_to_array((0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false), 2), isPrinting = _useState2[0], setIsPrinting = _useState2[1];
    var contentToPrintRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
    var launchVitalsBiometricsForm = (0,_utils__WEBPACK_IMPORTED_MODULE_6__.useLaunchVitalsAndBiometricsForm)();
    var excludePatientIdentifierCodeTypes = (0,_openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_5__.useConfig)().excludePatientIdentifierCodeTypes;
    var _useVitalsAndBiometrics = (0,_common__WEBPACK_IMPORTED_MODULE_7__.useVitalsAndBiometrics)(patientUuid), vitals = _useVitalsAndBiometrics.data, error = _useVitalsAndBiometrics.error, isLoading = _useVitalsAndBiometrics.isLoading, isValidating = _useVitalsAndBiometrics.isValidating;
    var _useCovidStigmaData = (0,_common_covid_stigma_data_resource__WEBPACK_IMPORTED_MODULE_8__.useCovidStigmaData)(patientUuid), covidStigmaData = _useCovidStigmaData.data, stigmaError = _useCovidStigmaData.error, stigmaLoading = _useCovidStigmaData.isLoading;
    var conceptUnits = (0,_common__WEBPACK_IMPORTED_MODULE_7__.useConceptUnits)().conceptUnits;
    var showPrintButton = config.vitals.showPrintButton && !chartView;
    var user = (0,_openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_5__.useSession)().user;
    var userRoles = (user === null || user === void 0 ? void 0 : (_user_roles = user.roles) === null || _user_roles === void 0 ? void 0 : _user_roles.map(function(r) {
        var _r_display;
        return (_r_display = r.display) === null || _r_display === void 0 ? void 0 : _r_display.toLowerCase();
    })) || [];
    // Hide Vitals completely for self-registration users
    if (userRoles.includes('self registration')) return null;
    var patientDetails = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(function() {
        var _patient_identifier, _patient_address;
        var getGender = function(gender) {
            switch(gender){
                case 'male':
                    return t('male', 'Male');
                case 'female':
                    return t('female', 'Female');
                case 'other':
                    return t('other', 'Other');
                case 'unknown':
                    return t('unknown', 'Unknown');
                default:
                    return gender;
            }
        };
        var _patient_identifier_filter;
        var identifiers = (_patient_identifier_filter = patient === null || patient === void 0 ? void 0 : (_patient_identifier = patient.identifier) === null || _patient_identifier === void 0 ? void 0 : _patient_identifier.filter(function(identifier) {
            return !(excludePatientIdentifierCodeTypes === null || excludePatientIdentifierCodeTypes === void 0 ? void 0 : excludePatientIdentifierCodeTypes.uuids.includes(identifier.type.coding[0].code));
        })) !== null && _patient_identifier_filter !== void 0 ? _patient_identifier_filter : [];
        return {
            name: patient ? (0,_openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_5__.getPatientName)(patient) : '',
            age: (0,_openmrs_esm_framework__WEBPACK_IMPORTED_MODULE_5__.age)(patient === null || patient === void 0 ? void 0 : patient.birthDate),
            gender: getGender(patient === null || patient === void 0 ? void 0 : patient.gender),
            location: patient === null || patient === void 0 ? void 0 : (_patient_address = patient.address) === null || _patient_address === void 0 ? void 0 : _patient_address[0].city,
            identifiers: (identifiers === null || identifiers === void 0 ? void 0 : identifiers.length) ? identifiers.map(function(param) {
                var value = param.value;
                return value;
            }) : []
        };
    }, [
        patient,
        t,
        excludePatientIdentifierCodeTypes === null || excludePatientIdentifierCodeTypes === void 0 ? void 0 : excludePatientIdentifierCodeTypes.uuids
    ]);
    var tableHeaders = [
        {
            key: 'temperatureRender',
            header: 'Type of Stigma\n\n(लान्छनाको प्रकार)',
            style: {
                width: '200px',
                minWidth: '200px'
            },
            isSortable: true,
            sortFunc: function(valueA, valueB) {
                return valueA.temperature && valueB.temperature ? valueA.temperature - valueB.temperature : 0;
            }
        },
        {
            key: 'bloodPressureRender',
            header: 'Stigma Score\n\n(लान्छनाको अंक)',
            style: {
                width: '150px',
                minWidth: '150px'
            },
            isSortable: true,
            sortFunc: function(valueA, valueB) {
                return valueA.systolic && valueB.systolic && valueA.diastolic && valueB.diastolic ? valueA.systolic !== valueB.systolic ? valueA.systolic - valueB.systolic : valueA.diastolic - valueB.diastolic : 0;
            }
        },
        {
            key: 'spo2Render',
            header: 'Intersectional\nStigma Score\n\n(अन्तरसम्बन्धित\nलान्छनाको अंक)',
            style: {
                width: '140px',
                maxWidth: '140px'
            },
            isSortable: true,
            sortFunc: function(valueA, valueB) {
                return valueA.spo2 && valueB.spo2 ? valueA.spo2 - valueB.spo2 : 0;
            }
        },
        {
            key: 'respiratoryRateRender',
            header: 'Dimension Score\n\n(क्षेत्रको अंक)',
            style: {
                width: '300px',
                minWidth: '300px'
            },
            isSortable: true,
            sortFunc: function(valueA, valueB) {
                return valueA.respiratoryRate && valueB.respiratoryRate ? valueA.respiratoryRate - valueB.respiratoryRate : 0;
            }
        }
    ];
    var tableRows = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(function() {
        if (covidStigmaData && covidStigmaData.length > 0) {
            var allStigmaRows = _to_consumable_array((0,_common_covid_stigma_data_resource__WEBPACK_IMPORTED_MODULE_8__.mapStigmaDataToVitalsFormat)(covidStigmaData, 'अपेक्षित लान्छना')).concat(_to_consumable_array((0,_common_covid_stigma_data_resource__WEBPACK_IMPORTED_MODULE_8__.mapStigmaDataToVitalsFormat)(covidStigmaData, 'व्यावहारिक लान्छना')), _to_consumable_array((0,_common_covid_stigma_data_resource__WEBPACK_IMPORTED_MODULE_8__.mapStigmaDataToVitalsFormat)(covidStigmaData, 'आत्मलान्छना')));
            var sortedRows = allStigmaRows.sort(function(a, b) {
                return new Date(b.date).getTime() - new Date(a.date).getTime();
            });
            return sortedRows.map(function(row, idx) {
                var _row_date;
                return _object_spread_props(_object_spread({}, row), {
                    id: String(idx),
                    date: (_row_date = row.date) !== null && _row_date !== void 0 ? _row_date : ''
                });
            });
        } else if (vitals && vitals.length > 0) {
            return vitals.sort(function(a, b) {
                return new Date(b.date).getTime() - new Date(a.date).getTime();
            }).map(function(d, idx) {
                var _d_date, _d_temperature, _d_bloodPressureRenderInterpretation, _d_pulse, _d_respiratoryRate, _d_spo2;
                return {
                    id: String(idx),
                    date: (_d_date = d.date) !== null && _d_date !== void 0 ? _d_date : '',
                    dateRender: d.date ? new Date(d.date).toLocaleDateString() : '',
                    temperatureRender: (_d_temperature = d.temperature) !== null && _d_temperature !== void 0 ? _d_temperature : '',
                    bloodPressureRender: (_d_bloodPressureRenderInterpretation = d.bloodPressureRenderInterpretation) !== null && _d_bloodPressureRenderInterpretation !== void 0 ? _d_bloodPressureRenderInterpretation : '',
                    pulseRender: (_d_pulse = d.pulse) !== null && _d_pulse !== void 0 ? _d_pulse : '',
                    respiratoryRateRender: (_d_respiratoryRate = d.respiratoryRate) !== null && _d_respiratoryRate !== void 0 ? _d_respiratoryRate : '',
                    spo2Render: (_d_spo2 = d.spo2) !== null && _d_spo2 !== void 0 ? _d_spo2 : '',
                    temperatureRenderInterpretation: undefined,
                    bloodPressureRenderInterpretation: undefined,
                    pulseRenderInterpretation: undefined,
                    respiratoryRateRenderInterpretation: undefined,
                    spo2RenderInterpretation: undefined
                };
            });
        }
        return [];
    }, [
        covidStigmaData,
        vitals
    ]);
    var onBeforeGetContentResolve = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(function() {
        if (isPrinting && onBeforeGetContentResolve.current) {
            onBeforeGetContentResolve.current();
        }
    }, [
        isPrinting
    ]);
    var handlePrint = (0,react_to_print__WEBPACK_IMPORTED_MODULE_2__.useReactToPrint)({
        content: function() {
            return contentToPrintRef.current;
        },
        documentTitle: "OpenMRS - ".concat(patientDetails.name, " - ").concat(headerTitle),
        onBeforeGetContent: function() {
            return new Promise(function(resolve) {
                if (patient && headerTitle) {
                    onBeforeGetContentResolve.current = resolve;
                    setIsPrinting(true);
                }
            });
        },
        onAfterPrint: function() {
            onBeforeGetContentResolve.current = null;
            setIsPrinting(false);
        }
    });
    return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null, function() {
        if (isLoading || stigmaLoading) {
            return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_carbon_react__WEBPACK_IMPORTED_MODULE_3__.DataTableSkeleton, {
                role: "progressbar",
                compact: !isTablet,
                zebra: true
            });
        }
        if (error || stigmaError) {
            return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_openmrs_esm_patient_common_lib__WEBPACK_IMPORTED_MODULE_4__.ErrorState, {
                error: error || stigmaError,
                headerTitle: headerTitle
            });
        }
        if (tableRows === null || tableRows === void 0 ? void 0 : tableRows.length) {
            return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", {
                className: _vitals_overview_scss__WEBPACK_IMPORTED_MODULE_12__["default"].widgetCard
            }, /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_openmrs_esm_patient_common_lib__WEBPACK_IMPORTED_MODULE_4__.CardHeader, {
                title: headerTitle
            }, /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", {
                className: _vitals_overview_scss__WEBPACK_IMPORTED_MODULE_12__["default"].backgroundDataFetchingIndicator
            }, /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", null, isValidating ? /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_carbon_react__WEBPACK_IMPORTED_MODULE_3__.InlineLoading, null) : null)), /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", {
                className: _vitals_overview_scss__WEBPACK_IMPORTED_MODULE_12__["default"].vitalsHeaderActionItems
            }, /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_carbon_react__WEBPACK_IMPORTED_MODULE_3__.Button, {
                kind: "ghost",
                size: "sm",
                className: _vitals_overview_scss__WEBPACK_IMPORTED_MODULE_12__["default"].titleChartButton,
                onClick: function() {
                    return setShowStigmaChart(!showStigmaChart);
                },
                iconDescription: t('toggleChart', 'Toggle Stigma Chart'),
                renderIcon: function(props) {
                    return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", {
                        className: _vitals_overview_scss__WEBPACK_IMPORTED_MODULE_12__["default"].chartIcon
                    }, "\uD83D\uDCC8");
                }
            }, showStigmaChart ? t('hideChart', 'Hide Chart') : t('showChart', 'Show Chart')))), showStigmaChart && /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", {
                className: _vitals_overview_scss__WEBPACK_IMPORTED_MODULE_12__["default"].stigmaChartContainer
            }, /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_common_stigma_data_aggregate__WEBPACK_IMPORTED_MODULE_13__["default"], {
                patientUuid: patientUuid
            })), chartView ? /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_vitals_chart_component__WEBPACK_IMPORTED_MODULE_11__["default"], {
                patientVitals: vitals,
                conceptUnits: conceptUnits,
                config: config
            }) : /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", {
                ref: contentToPrintRef
            }, /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_print_print_component__WEBPACK_IMPORTED_MODULE_10__["default"], {
                subheader: headerTitle,
                patientDetails: patientDetails
            }), /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_paginated_vitals_component__WEBPACK_IMPORTED_MODULE_9__["default"], {
                isPrinting: isPrinting,
                pageSize: pageSize,
                pageUrl: pageUrl,
                tableHeaders: tableHeaders,
                tableRows: tableRows,
                urlLabel: urlLabel
            })));
        }
        return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", {
            className: _vitals_overview_scss__WEBPACK_IMPORTED_MODULE_12__["default"].widgetCard
        }, /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_openmrs_esm_patient_common_lib__WEBPACK_IMPORTED_MODULE_4__.CardHeader, {
            title: headerTitle,
            children: ''
        }), /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", {
            style: {
                padding: '1rem',
                textAlign: 'center',
                fontSize: '1rem'
            }
        }, t('noStigmaMessage', 'कुनै पनि डेटा फेला परेन।')));
    }());
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (VitalsOverview);


/***/ }),

/***/ "./src/vitals/vitals-summary.component.tsx":
/*!*************************************************!*\
  !*** ./src/vitals/vitals-summary.component.tsx ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-i18next */ "webpack/sharing/consume/default/react-i18next/react-i18next");
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_i18next__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _vitals_overview_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./vitals-overview.component */ "./src/vitals/vitals-overview.component.tsx");



var VitalsSummary = function(param) {
    var patientUuid = param.patientUuid, patient = param.patient, basePath = param.basePath;
    var pageSize = 5;
    var t = (0,react_i18next__WEBPACK_IMPORTED_MODULE_1__.useTranslation)().t;
    var pageUrl = "${openmrsSpaBase}/patient/".concat(patientUuid, "/chart/Vitals & Biometrics");
    var urlLabel = t('seeAll', 'See all');
    return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_vitals_overview_component__WEBPACK_IMPORTED_MODULE_2__["default"], {
        patientUuid: patientUuid,
        patient: patient,
        pageSize: pageSize,
        urlLabel: urlLabel,
        pageUrl: pageUrl
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (VitalsSummary);


/***/ }),

/***/ "./translations lazy .json$":
/*!************************************************!*\
  !*** ./translations/ lazy nonrecursive .json$ ***!
  \************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var map = {
	"./am.json": [
		"./translations/am.json",
		"translations_am_json"
	],
	"./ar.json": [
		"./translations/ar.json",
		"translations_ar_json"
	],
	"./ar_SY.json": [
		"./translations/ar_SY.json",
		"translations_ar_SY_json"
	],
	"./bn.json": [
		"./translations/bn.json",
		"translations_bn_json"
	],
	"./de.json": [
		"./translations/de.json",
		"translations_de_json"
	],
	"./en.json": [
		"./translations/en.json",
		"translations_en_json"
	],
	"./en_US.json": [
		"./translations/en_US.json",
		"translations_en_US_json"
	],
	"./es.json": [
		"./translations/es.json",
		"translations_es_json"
	],
	"./es_MX.json": [
		"./translations/es_MX.json",
		"translations_es_MX_json"
	],
	"./fr.json": [
		"./translations/fr.json",
		"translations_fr_json"
	],
	"./he.json": [
		"./translations/he.json",
		"translations_he_json"
	],
	"./hi.json": [
		"./translations/hi.json",
		"translations_hi_json"
	],
	"./hi_IN.json": [
		"./translations/hi_IN.json",
		"translations_hi_IN_json"
	],
	"./id.json": [
		"./translations/id.json",
		"translations_id_json"
	],
	"./it.json": [
		"./translations/it.json",
		"translations_it_json"
	],
	"./ka.json": [
		"./translations/ka.json",
		"translations_ka_json"
	],
	"./km.json": [
		"./translations/km.json",
		"translations_km_json"
	],
	"./ku.json": [
		"./translations/ku.json",
		"translations_ku_json"
	],
	"./ky.json": [
		"./translations/ky.json",
		"translations_ky_json"
	],
	"./lg.json": [
		"./translations/lg.json",
		"translations_lg_json"
	],
	"./ne.json": [
		"./translations/ne.json",
		"translations_ne_json"
	],
	"./pl.json": [
		"./translations/pl.json",
		"translations_pl_json"
	],
	"./pt.json": [
		"./translations/pt.json",
		"translations_pt_json"
	],
	"./pt_BR.json": [
		"./translations/pt_BR.json",
		"translations_pt_BR_json"
	],
	"./qu.json": [
		"./translations/qu.json",
		"translations_qu_json"
	],
	"./ro_RO.json": [
		"./translations/ro_RO.json",
		"translations_ro_RO_json"
	],
	"./ru_RU.json": [
		"./translations/ru_RU.json",
		"translations_ru_RU_json"
	],
	"./si.json": [
		"./translations/si.json",
		"translations_si_json"
	],
	"./sw.json": [
		"./translations/sw.json",
		"translations_sw_json"
	],
	"./sw_KE.json": [
		"./translations/sw_KE.json",
		"translations_sw_KE_json"
	],
	"./tr.json": [
		"./translations/tr.json",
		"translations_tr_json"
	],
	"./tr_TR.json": [
		"./translations/tr_TR.json",
		"translations_tr_TR_json"
	],
	"./uk.json": [
		"./translations/uk.json",
		"translations_uk_json"
	],
	"./uz.json": [
		"./translations/uz.json",
		"translations_uz_json"
	],
	"./uz@Latn.json": [
		"./translations/uz@Latn.json",
		"translations_uz_Latn_json"
	],
	"./uz_UZ.json": [
		"./translations/uz_UZ.json",
		"translations_uz_UZ_json"
	],
	"./vi.json": [
		"./translations/vi.json",
		"translations_vi_json"
	],
	"./zh.json": [
		"./translations/zh.json",
		"translations_zh_json"
	],
	"./zh_CN.json": [
		"./translations/zh_CN.json",
		"translations_zh_CN_json"
	]
};
function webpackAsyncContext(req) {
	if(!__webpack_require__.o(map, req)) {
		return Promise.resolve().then(() => {
			var e = new Error("Cannot find module '" + req + "'");
			e.code = 'MODULE_NOT_FOUND';
			throw e;
		});
	}

	var ids = map[req], id = ids[0];
	return __webpack_require__.e(ids[1]).then(() => {
		return __webpack_require__(id);
	});
}
webpackAsyncContext.keys = () => (Object.keys(map));
webpackAsyncContext.id = "./translations lazy .json$";
module.exports = webpackAsyncContext;

/***/ }),

/***/ "./src/common/img/QR1_HIV awareness_NAPN.png":
/*!***************************************************!*\
  !*** ./src/common/img/QR1_HIV awareness_NAPN.png ***!
  \***************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";
module.exports = __webpack_require__.p + "b8feb1e0d0c56398.png";

/***/ }),

/***/ "./src/common/img/QR2_TPO_Managing fear.png":
/*!**************************************************!*\
  !*** ./src/common/img/QR2_TPO_Managing fear.png ***!
  \**************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";
module.exports = __webpack_require__.p + "bedf0f5093cf1fba.png";

/***/ }),

/***/ "./src/common/img/QR3_BDS_Ideal World.png":
/*!************************************************!*\
  !*** ./src/common/img/QR3_BDS_Ideal World.png ***!
  \************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";
module.exports = __webpack_require__.p + "f20ebe83b4e81c45.png";

/***/ }),

/***/ "./src/common/img/QR4_Treatment adherence video(उपचार पालना)_NCASC.png":
/*!*****************************************************************************!*\
  !*** ./src/common/img/QR4_Treatment adherence video(उपचार पालना)_NCASC.png ***!
  \*****************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";
module.exports = __webpack_require__.p + "75279d4d0f75884c.png";

/***/ }),

/***/ "./src/common/img/notes.png":
/*!**********************************!*\
  !*** ./src/common/img/notes.png ***!
  \**********************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";
module.exports = __webpack_require__.p + "ee3e46312d46a54f.png";

/***/ })

}]);
//# sourceMappingURL=src_index_ts.js.map