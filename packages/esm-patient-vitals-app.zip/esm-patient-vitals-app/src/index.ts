import {
  defineConfigSchema,
  fhirBaseUrl,
  getAsyncLifecycle,
  getSyncLifecycle,
  messageOmrsServiceWorker,
  restBaseUrl,
} from '@openmrs/esm-framework';
import { createDashboardLink } from '@openmrs/esm-patient-common-lib';
import { configSchema } from './config-schema';
import biometricsDetailedSummaryComponent from './biometrics/biometrics-main.component';
import biometricsOverviewComponent from './biometrics/biometrics-overview.component';
import dashboardMeta from './dashboard.meta';
import vitalsHeaderComponent from './vitals-and-biometrics-header/vitals-header.component';
import vitalsMainComponent from './vitals/vitals-main.component';
import vitalsSummaryComponent from './vitals/vitals-summary.component';
import stigmaMonthlyAggregateComponent from './common/stigma-data-aggregate';
// import confDashboardComponent from './common/conf_dashboard';
// import conferenceDashboardComponent from './common/conference-dashboard.component';
import './common/debug-helper'; // Import debug helper

const moduleName = '@openmrs/esm-patient-vitals-app';

const options = {
  featureName: 'patient-vitals',
  moduleName,
};

export const importTranslation = require.context('../translations', false, /.json$/, 'lazy');

export function startupApp() {
  messageOmrsServiceWorker({
    type: 'registerDynamicRoute',
    pattern: `${fhirBaseUrl}/Observation.+`,
  });

  messageOmrsServiceWorker({
    type: 'registerDynamicRoute',
    pattern: `.+${restBaseUrl}/concept.+`,
  });

  defineConfigSchema(moduleName, configSchema);
}

export const vitalsSummary = getSyncLifecycle(vitalsSummaryComponent, options);

export const vitalsMain = getSyncLifecycle(vitalsMainComponent, options);

export const vitalsHeader = getSyncLifecycle(vitalsHeaderComponent, options);

export const biometricsOverview = getSyncLifecycle(biometricsOverviewComponent, options);

export const biometricsDetailedSummary = getSyncLifecycle(biometricsDetailedSummaryComponent, options);

export const vitalsAndBiometricsDashboardLink =
  // t('Vitals & Biometrics', 'Vitals & Biometrics')
  getSyncLifecycle(
    createDashboardLink({
      ...dashboardMeta,
      moduleName,
    }),
    options,
  );

export const weightTile = getAsyncLifecycle(() => import('./components/weight-tile/weight-tile.component'), options);

// t('recordVitalsAndBiometrics', 'Record Vitals and Biometrics')
// export const vitalsBiometricsFormWorkspace = getAsyncLifecycle(
//   () => import('./vitals-biometrics-form/vitals-biometrics-form.workspace'),
//   options,
// );

export const vitalsAndBiometricsDeleteConfirmationModal = getAsyncLifecycle(
  () => import('./components/delete-vitals-biometrics-modal/delete-vitals-biometrics.modal'),
  options,
);

export const stigmaMonthlyAggregate = getSyncLifecycle(stigmaMonthlyAggregateComponent, options);

// console.log('Registering confDashboard component', confDashboardComponent);
// export const confDashboard = getSyncLifecycle(confDashboardComponent, options);

// console.log('Registering conferenceDashboard component', conferenceDashboardComponent);
// export const conferenceDashboard = getSyncLifecycle(conferenceDashboardComponent, options);

// export const confDashboardLink = getSyncLifecycle(
//   createDashboardLink({
//     path: 'stigma-dashboard',
//     title: 'Stigma Dashboard',
//     moduleName,
//     slot: 'patient-chart-dashboard-slot', // ✅ important!
//   }),
//   options,
// );

// ,
//     {
//       "name": "conference-dashboard-widget",
//       "component": "confDashboard",
//       "slot": "patient-chart-vitals-biometrics-dashboard-slot",
//       "meta": {
//         "fullWidth": true,
//         "title": "Conference Level Dashboard"
//       },
//       "order": 4
//     }
