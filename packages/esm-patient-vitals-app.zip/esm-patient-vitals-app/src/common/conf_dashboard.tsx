// import React, { useEffect, useState, useMemo } from 'react';
// import useSWR from 'swr';
// import { fhirBaseUrl, openmrsFetch } from '@openmrs/esm-framework';
// import { Chart } from 'react-chartjs-2';
// import 'chart.js/auto'; // ensures chart.js works
// import { StigmaOverviewChart } from './stigma-type-dimensions';
// import { StigmaAnnualTrendChart } from './stigma-annual-trend';
// import type { AggregatedData } from './stigma-annual-trend';
// import { CovidStigmaData, computeStigmaMatch_LatestOnly } from './covid-stigma-data.resource';
// // import { StigmaAnnualTrendChart } from './stigma-annual-trend';
// // import { StigmaOverviewChart } from './StigmaOverviewChart'; // adjust path if needed
// // ---------------- Fetch All Patients (no pagination) ----------------
// async function fetchAllPatients() {
//   let allPatients: any[] = [];
//   let offset = 0;
//   let total = 0;
//   while (true) {
//     const url = `${fhirBaseUrl}/Patient?_count=100&_getpagesoffset=${offset}`;
//     const { data } = await openmrsFetch(url);
//     if (!data?.entry || data.entry.length === 0) break;
//     allPatients = allPatients.concat(data.entry.map((e: any) => e.resource));
//     total = data?.total || allPatients.length;
//     offset += 100;
//     if (allPatients.length >= total) break;
//   }
//   return { patients: allPatients, total };
// }

// export function useAllPatients() {
//   return useSWR('allPatients', fetchAllPatients);
// }
// export function checkCutoff(
//   value: number | undefined | null,
//   cutoff: number,
//   returnBoolean = false,
// ): 'below' | 'above' | 'equal' | boolean {
//   if (value == null) return returnBoolean ? false : 'below';
//   if (value < cutoff) return returnBoolean ? false : 'below';
//   if (value > cutoff) return returnBoolean ? true : 'above';
//   return returnBoolean ? true : 'equal';
// }

// // ---------------- Fetch Counselling/Stigma Data for a patient ----------------
// async function fetchPatientStigmaData(patientId: string) {
//   try {
//     const url = `${fhirBaseUrl}/Observation?subject=${patientId}&_count=100`;
//     const { data } = await openmrsFetch(url);
//     if (!data?.entry) return [];
//     return data.entry.map((e: any) => e.resource);
//   } catch (error) {
//     console.error(`Error fetching stigma data for patient ${patientId}:`, error);
//     return [];
//   }
// }

// // ---------------- Aggregate Data By Year and Month ----------------
// function aggregateYearMonthPatientCount(allPatientsData: any[], selectedYear: string) {
//   // For each month, collect a Set of patient IDs
//   const monthPatientSets: Array<Set<string>> = Array(12)
//     .fill(null)
//     .map(() => new Set());
//   allPatientsData.forEach((patientData, patientIdx) => {
//     patientData.forEach((obs: any) => {
//       const date = new Date(obs.effectiveDateTime || obs.date);
//       if (!date) return;
//       // Adjust for Nepali Time (UTC+5:45)
//       const offsetInMs = 5 * 60 * 60 * 1000 + 45 * 60 * 1000;
//       const nepaliDate = new Date(date.getTime() + offsetInMs);
//       const year = nepaliDate.getFullYear().toString();
//       const month = nepaliDate.getMonth(); // 0=Jan, 11=Dec
//       if (year === selectedYear) {
//         // Use patientIdx as unique patient identifier (since each patientData is for one patient)
//         monthPatientSets[month].add(String(patientIdx));
//       }
//     });
//   });
//   // Convert sets to counts
//   return monthPatientSets.map((set) => set.size);
// }

// // ---------------- Chart Component ----------------
// function MonthlyBarChart({
//   allPatientsData,
//   selectedYear,
//   onYearChange,
//   availableYears,
// }: {
//   allPatientsData: any[];
//   selectedYear: string;
//   onYearChange: (year: string) => void;
//   availableYears: string[];
// }) {
//   const monthCounts = useMemo(
//     () => aggregateYearMonthPatientCount(allPatientsData, selectedYear),
//     [allPatientsData, selectedYear],
//   );
//   const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
//   const data = {
//     labels: months,
//     datasets: [
//       {
//         label: `Patient Count in ${selectedYear}`,
//         data: monthCounts,
//         backgroundColor: '#1f2e5bff',
//       },
//     ],
//   };
//   return (
//     <div>
//       <div style={{ marginBottom: '1rem' }}>
//         <label htmlFor="year-select">Select Year: </label>
//         <select id="year-select" value={selectedYear} onChange={(e) => onYearChange(e.target.value)}>
//           {availableYears.map((y) => (
//             <option key={y} value={y}>
//               {y}
//             </option>
//           ))}
//         </select>
//       </div>
//       <Chart type="bar" data={data} />
//     </div>
//   );
// }

// export function isAboveCutoff(value: number | undefined | null, cutoff: number): boolean {
//   if (value == null) return false;
//   return value > cutoff;
// }

// export function isBelowCutoff(value: number | undefined | null, cutoff: number): boolean {
//   if (value == null) return true;
//   return value < cutoff;
// }

// // ---------------- Main Dashboard ----------------
// export default function AllPatientsDashboard() {
//   const { data, isLoading, error } = useAllPatients();
//   const patients = data?.patients || [];
//   const [allPatientsData, setAllPatientsData] = useState<any[]>([]);
//   const [selectedYear, setSelectedYear] = useState<string>('');
//   const [availableYears, setAvailableYears] = useState<string[]>([]);

//   useEffect(() => {
//     if (!patients?.length) return;
//     Promise.all(patients.map((p) => fetchPatientStigmaData(p.id))).then((results) => {
//       setAllPatientsData(results);
//       // Find all years present in the data
//       const yearsSet = new Set<string>();
//       results.forEach((patientData) => {
//         patientData.forEach((obs: any) => {
//           const date = new Date(obs.effectiveDateTime || obs.date);
//           if (!date) return;
//           // Adjust for Nepali Time
//           const offsetInMs = 5 * 60 * 60 * 1000 + 45 * 60 * 1000;
//           const nepaliDate = new Date(date.getTime() + offsetInMs);
//           yearsSet.add(nepaliDate.getFullYear().toString());
//         });
//       });
//       const yearsArr = Array.from(yearsSet).sort();
//       setAvailableYears(yearsArr);
//       // Default to latest year
//       if (yearsArr.length > 0) setSelectedYear(yearsArr[yearsArr.length - 1]);
//     });
//   }, [patients]);

//   // Test function to analyze stigma data
//   function testStigmaAnalysis(patientData: any[]) {
//     let totalPatients = 0;
//     let matchedPatients = 0;
//     let unmatchedPatients = 0;
//     const patientMatches: Record<
//       string,
//       { matched: boolean; highestScores: { type: string; score: number; threshold: number }[] }
//     > = {};

//     patientData.forEach((observations, patientIndex) => {
//       const patientId = String(patientIndex);

//       // Process observations to match CovidStigmaData format
//       const stigmaData: CovidStigmaData[] = observations
//         .filter((obs: any) =>
//           // Filter only stigma-related observations
//           obs.code?.coding?.some(
//             (coding: any) =>
//               coding.display?.toLowerCase().includes('stigma') || coding.code?.toLowerCase().includes('stigma'),
//           ),
//         )
//         .map((obs: any) => ({
//           id: obs.id,
//           date: obs.effectiveDateTime || obs.date,
//           encounterUuid: obs.encounter?.reference,
//           stigmaType: obs.code?.coding?.[0]?.display || '',
//           stigmaScore: obs.valueQuantity?.value || 0,
//           dimensionType: '',
//           dimensionScore:
//             obs.component?.map((c: any) => `${c.code.text}:${c.valueQuantity?.value || 0}`).join(', ') || '',
//           intersectionalScore:
//             obs.component?.find((c: any) => c.code.text?.toLowerCase().includes('intersectional'))?.valueQuantity
//               ?.value || 0,
//         }));

//       // Only count patients who have stigma data
//       if (stigmaData.length > 0) {
//         console.log(`\n📊 Analyzing Patient ${patientId}:`);

//         // Use a Set to track unique score types for this patient
//         const uniqueScoreTypes = new Set();

//         // Count all scores over their respective thresholds, ensuring each type is only counted once per patient
//         const highScores = stigmaData.reduce(
//           (scores, entry) => {
//             const type = entry.stigmaType?.toLowerCase() || '';
//             const score =
//               typeof entry.stigmaScore === 'number'
//                 ? entry.stigmaScore
//                 : typeof entry.stigmaScore === 'string'
//                   ? parseFloat(entry.stigmaScore)
//                   : 0;

//             // Skip if score is not a valid number
//             if (isNaN(score)) return scores;

//             // Intersectional scores
//             if (type.includes('intersectional')) {
//               if (type.includes('anticipated') && score >= 80 && !uniqueScoreTypes.has('Anticipated Intersectional')) {
//                 uniqueScoreTypes.add('Anticipated Intersectional');
//                 scores.push({ type: 'Anticipated Intersectional', score, threshold: 80 });
//               }
//               if (type.includes('enacted') && score >= 86 && !uniqueScoreTypes.has('Enacted Intersectional')) {
//                 uniqueScoreTypes.add('Enacted Intersectional');
//                 scores.push({ type: 'Enacted Intersectional', score, threshold: 86 });
//               }
//               if (
//                 type.includes('internalized') &&
//                 score >= 66 &&
//                 !uniqueScoreTypes.has('Internalized Intersectional')
//               ) {
//                 uniqueScoreTypes.add('Internalized Intersectional');
//                 scores.push({ type: 'Internalized Intersectional', score, threshold: 66 });
//               }
//             }

//             // Domain scores
//             if (type.includes('mental health')) {
//               if (type.includes('enacted') && score >= 43 && !uniqueScoreTypes.has('Mental Health Enacted')) {
//                 uniqueScoreTypes.add('Mental Health Enacted');
//                 scores.push({ type: 'Mental Health Enacted', score, threshold: 43 });
//               }
//               if (type.includes('anticipated') && score >= 40 && !uniqueScoreTypes.has('Mental Health Anticipated')) {
//                 uniqueScoreTypes.add('Mental Health Anticipated');
//                 scores.push({ type: 'Mental Health Anticipated', score, threshold: 40 });
//               }
//               if (type.includes('internalized') && score >= 33 && !uniqueScoreTypes.has('Mental Health Internalized')) {
//                 uniqueScoreTypes.add('Mental Health Internalized');
//                 scores.push({ type: 'Mental Health Internalized', score, threshold: 33 });
//               }
//             }

//             // Total scores
//             if (type.includes('total score')) {
//               if (type.includes('enacted') && score >= 43 && !uniqueScoreTypes.has('Total Enacted')) {
//                 uniqueScoreTypes.add('Total Enacted');
//                 scores.push({ type: 'Total Enacted', score, threshold: 43 });
//               }
//               if (type.includes('anticipated') && score >= 40) {
//                 scores.push({ type: 'Total Anticipated', score, threshold: 40 });
//               }
//               if (type.includes('internalized') && score >= 33) {
//                 scores.push({ type: 'Total Internalized', score, threshold: 33 });
//               }
//             }

//             return scores;
//           },
//           [] as { type: string; score: number; threshold: number }[],
//         );

//         totalPatients++;
//         const hasHighScore = highScores.length > 0;
//         patientMatches[patientId] = { matched: hasHighScore, highestScores: highScores };

//         if (hasHighScore) {
//           console.log('⚠️ HIGH STIGMA DETECTED:');
//           highScores.forEach((s) => {
//             console.log(`  → ${s.type}: ${s.score} (threshold: ${s.threshold})`);
//           });
//           matchedPatients++;
//         } else {
//           console.log('✓ All scores below thresholds');
//           unmatchedPatients++;
//         }

//         console.log('Running Totals:', {
//           total: totalPatients,
//           high: matchedPatients,
//           low: unmatchedPatients,
//         });
//       }
//     });

//     return {
//       totalPatients,
//       matchedPatients,
//       unmatchedPatients,
//       patientMatches,
//     };
//   }

//   const stigmaDataByPatient: Record<string, CovidStigmaData[]> = {};
//   allPatientsData.forEach((patientObservations, index) => {
//     stigmaDataByPatient[String(index)] = patientObservations;
//   });

//   // Test the analysis and log results
//   useEffect(() => {
//     if (allPatientsData.length > 0) {
//       const analysisResult = testStigmaAnalysis(allPatientsData);
//       console.log('Stigma Analysis Test Results:', {
//         totalPatients: analysisResult.totalPatients,
//         matchedPatients: analysisResult.matchedPatients,
//         unmatchedPatients: analysisResult.unmatchedPatients,
//         matchDetails: analysisResult.patientMatches,
//       });
//     }
//   }, [allPatientsData]);

//   const stigmaCutoffSummary = useMemo(() => {
//     // Run the test analysis when data is available
//     if (allPatientsData.length > 0) {
//       const analysisResult = testStigmaAnalysis(allPatientsData);
//       console.log('Stigma Analysis Test Results:', analysisResult);
//       return analysisResult;
//     }
//     return null;
//   }, [allPatientsData]);

//   return (
//     <div
//       style={{
//         padding: '1rem',
//         border: '2px solid #3366ff',
//         margin: '1rem',
//         backgroundColor: '#f0f8ff',
//       }}
//     >
//       {/* <h2>All Patients Monthly Counselling Trend</h2> */}

//       {isLoading && <p>Loading patient data...</p>}
//       {error && <p style={{ color: 'red' }}>Error loading patients: {String(error)}</p>}
//       {!isLoading && !patients?.length && <p>No patients found</p>}

//       {/* Display Stigma Analysis Results if data is available */}
//       {allPatientsData.length > 0 && (
//         <div
//           style={{
//             backgroundColor: '#fff',
//             padding: '1rem',
//             marginBottom: '1rem',
//             borderRadius: '8px',
//             boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
//           }}
//         >
//           <h3>लान्छना विश्लेषण नतिजाहरू</h3>
//           {stigmaCutoffSummary ? (
//             <>
//               <p>कुल बिरामीहरू: {stigmaCutoffSummary.totalPatients}</p>
//               <p>उच्च लान्छना स्कोर भएका: {stigmaCutoffSummary.matchedPatients}</p>
//               <p>न्यून लान्छना स्कोर भएका: {stigmaCutoffSummary.unmatchedPatients}</p>
//             </>
//           ) : (
//             <p>तथ्यांक विश्लेषण गर्दै...</p>
//           )}
//         </div>
//       )}

//       {patients.length > 0 && selectedYear && (
//         <MonthlyBarChart
//           allPatientsData={allPatientsData}
//           selectedYear={selectedYear}
//           onYearChange={setSelectedYear}
//           availableYears={availableYears}
//         />
//       )}

//       {/* Optional: Stigma Overview Chart */}
//       {/* <div style={{ marginTop: '2rem' }}>
//         <StigmaOverviewChart allPatientsData={allPatientsData} />
//       </div> */}

//       {/* Monthly Trend Chart */}
//       {/* <div style={{ marginTop: '2rem' }}>
//         <StigmaOverviewChart allPatientsData={allPatientsData} />
//       </div> */}

//       {/* Annual Trend Chart */}
//       <div style={{ marginTop: '2rem' }}>
//         <StigmaAnnualTrendChart
//           data={allPatientsData.reduce(
//             (acc, observations) => {
//               const stigmaData = observations.filter((obs: any) =>
//                 obs.code?.coding?.some(
//                   (coding: any) =>
//                     coding.display?.toLowerCase().includes('stigma') || coding.code?.toLowerCase().includes('stigma'),
//                 ),
//               );

//               if (stigmaData.length === 0) return acc;

//               const date = stigmaData[0]?.effectiveDateTime || stigmaData[0]?.date;
//               if (!date) return acc;

//               const year = new Date(date).getFullYear().toString();
//               const stats = computeStigmaMatch_LatestOnly(stigmaData);

//               // Find or create year entry
//               const yearEntry = acc.find((entry) => entry.year === year);
//               if (!yearEntry) {
//                 acc.push({
//                   year,
//                   hiv_as: stats.matched ? 1 : 0,
//                   hiv_es: stats.matched ? 1 : 0,
//                   hiv_is: stats.matched ? 1 : 0,
//                   mh_as: stats.matched ? 1 : 0,
//                   mh_es: stats.matched ? 1 : 0,
//                   mh_is: stats.matched ? 1 : 0,
//                   sgm_as: stats.matched ? 1 : 0,
//                   sgm_es: stats.matched ? 1 : 0,
//                   sgm_is: stats.matched ? 1 : 0,
//                   em_as: stats.matched ? 1 : 0,
//                   em_es: stats.matched ? 1 : 0,
//                   em_is: stats.matched ? 1 : 0,
//                 });
//               } else {
//                 // Update existing year entry
//                 yearEntry.hiv_as += stats.matched ? 1 : 0;
//                 yearEntry.hiv_es += stats.matched ? 1 : 0;
//                 yearEntry.hiv_is += stats.matched ? 1 : 0;
//                 yearEntry.mh_as += stats.matched ? 1 : 0;
//                 yearEntry.mh_es += stats.matched ? 1 : 0;
//                 yearEntry.mh_is += stats.matched ? 1 : 0;
//                 yearEntry.sgm_as += stats.matched ? 1 : 0;
//                 yearEntry.sgm_es += stats.matched ? 1 : 0;
//                 yearEntry.sgm_is += stats.matched ? 1 : 0;
//                 yearEntry.em_as += stats.matched ? 1 : 0;
//                 yearEntry.em_es += stats.matched ? 1 : 0;
//                 yearEntry.em_is += stats.matched ? 1 : 0;
//               }

//               return acc;
//             },
//             [] as Array<AggregatedData & { year: string }>,
//           )}
//         />
//       </div>
//     </div>
//   );
// }
