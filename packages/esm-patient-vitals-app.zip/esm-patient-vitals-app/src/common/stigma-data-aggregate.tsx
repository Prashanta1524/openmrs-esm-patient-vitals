import React, { useMemo } from 'react'; // Removed useState since we're not using it
import { useCovidStigmaData, type CovidStigmaData } from './covid-stigma-data.resource';
import { Bar } from 'react-chartjs-2'; // Removed Line import since we're not using it
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  Filler,
} from 'chart.js';
// import zoomPlugin from 'chartjs-plugin-zoom';

ChartJS.register(CategoryScale, LinearScale, BarElement, PointElement, LineElement, Title, Tooltip, Legend, Filler);

const DOMAIN_COLORS = {
  hiv: 'rgba(255,99,132,0.8)',
  mh: 'rgba(54,162,235,0.8)',
  sgm: 'rgba(255,206,86,0.8)',
  em: 'rgba(75,192,192,0.8)',
  intersectional: 'rgba(153,102,255,0.8)',
};

/* ---------------- Helpers ---------------- */
function parseDimensionScore(scoreStr: string) {
  const domainMap: Record<string, number> = { hiv: 0, mh: 0, sgm: 0, em: 0, intersectional: 0 };
  const mappings = [
    { key: 'hiv', label: 'एचआईभी' },
    { key: 'mh', label: 'मानसिक स्वास्थ्य' },
    { key: 'sgm', label: 'लैङ्गिक तथा यौनिक अल्पसङ्ख्यक' },
    { key: 'em', label: 'जातीय अल्पसङ्ख्यक/दलित' },
    { key: 'intersectional', label: 'इण्टरसेक्सनल' },
  ];

  mappings.forEach(({ key, label }) => {
    const regex = new RegExp(`${label}\\s*:?\\s*(\\d+)`);
    const match = scoreStr.match(regex);
    if (match) domainMap[key] = Number(match[1]);
  });

  return domainMap;
}

/* ---------------- Aggregation ---------------- */
const aggregateByType = (data: CovidStigmaData[]) => {
  return data.map((d) => {
    const parsed = d.dimensionScore
      ? parseDimensionScore(String(d.dimensionScore))
      : { hiv: 0, mh: 0, sgm: 0, em: 0, intersectional: 0 };

    // Use the intersectionalScore property directly
    if (d.intersectionalScore) {
      parsed.intersectional = Number(d.intersectionalScore);
    }

    return {
      type: d.stigmaType || 'Unknown',
      totals: parsed,
    };
  });
};

/* Commenting out aggregateByDate since we're not using the line chart
const aggregateByDate = (data: CovidStigmaData[]) => {
  return data
    .map((d) => {
      const parsed = d.dimensionScore
        ? parseDimensionScore(String(d.dimensionScore))
        : { hiv: 0, mh: 0, sgm: 0, em: 0, intersectional: 0 };

      // Use the intersectionalScore property directly
      if (d.intersectionalScore) {
        parsed.intersectional = Number(d.intersectionalScore);
      }

      return {
        date: d.date,
        totals: parsed, // 👈 no forced sum
      };
    })
    .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
};
*/
/* ---------------- Chart Components ---------------- */
function TypeDimensionBarChart({ data }: { data: ReturnType<typeof aggregateByType> }) {
  const domainKeys = ['hiv', 'mh', 'sgm', 'em', 'intersectional'] as const;
  const domainLabels = {
    hiv: 'एचआईभी',
    mh: 'मानसिक स्वास्थ्य',
    sgm: 'लैङ्गिक तथा यौनिक अल्पसङ्ख्यक',
    em: 'जातीय अल्पसङ्ख्यक/दलित',
    intersectional: 'इण्टरसेक्सनल',
  };

  const datasets = domainKeys.map((key) => ({
    label: domainLabels[key],
    data: data.map((d) => d.totals[key]),
    backgroundColor: DOMAIN_COLORS[key],
  }));

  return (
    <Bar
      data={{ labels: data.map((d) => d.type), datasets }}
      options={{
        responsive: true,
        plugins: {
          title: { display: true, text: 'Stigma Scores Across Type × Dimension' },
          legend: { position: 'bottom' },
        },
        scales: {
          x: { stacked: false, title: { display: true, text: 'Stigma Type' } },
          y: { stacked: false, title: { display: true, text: 'Score' } },
        },
      }}
    />
  );
}

/* Commenting out the StigmaLineChart component since we're only using the TypeDimensionBarChart
function StigmaLineChart({ data }: { data: ReturnType<typeof aggregateByDate> }) {
  // Format labels as YYYY-MM
  const labels = data.map((d) => {
    const date = new Date(d.date);
    return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
  });

  const domainLabels = {
    hiv: 'एचआईभी',
    mh: 'मानसिक स्वास्थ्य',
    sgm: 'लैङ्गिक तथा यौनिक अल्पसङ्ख्यक',
    em: 'जातीय अल्पसङ्ख्यक/दलित',
    intersectional: 'इण्टरसेक्सनल',
  };

  const datasets = Object.keys(DOMAIN_COLORS).map((key) => ({
    label: domainLabels[key as keyof typeof domainLabels],
    data: data.map((d) => d.totals[key]),
    borderColor: DOMAIN_COLORS[key as keyof typeof DOMAIN_COLORS],
    backgroundColor: DOMAIN_COLORS[key as keyof typeof DOMAIN_COLORS],
    fill: false,
    tension: 0.2,
  }));

  return (
    <Line
      data={{ labels, datasets }}
      options={{
        responsive: true,
        plugins: {
          title: { display: true, text: 'Stigma Scores Trends' },
          legend: { position: 'bottom' },
          tooltip: {
            callbacks: {
              label: function (context) {
                const index = context.dataIndex;
                const d = data[index];
                return `${context.dataset.label}: ${context.parsed.y} (Date: ${new Date(d.date).toLocaleDateString()})`;
              },
            },
          },
          zoom: {
            zoom: { wheel: { enabled: true }, pinch: { enabled: true }, mode: 'x' },
            pan: { enabled: true, mode: 'x' },
          },
        },
        scales: {
          x: { title: { display: true, text: 'Year-Month' } },
          y: { title: { display: true, text: 'Score' } },
        },
      }}
    />
  );
}
*/

/* ---------------- Wrapper ---------------- */
export default function MultiChartSelector({ patientUuid }: { patientUuid: string }) {
  const { data, isLoading, error } = useCovidStigmaData(patientUuid);
  // Comment out the chart type state since we're only showing the type chart
  // const [chartType, setChartType] = useState<'line' | 'type'>('type');

  const typeData = useMemo(() => (data ? aggregateByType(data) : []), [data]);
  // We'll keep this for future use but won't use it now
  // const lineData = useMemo(() => (data ? aggregateByDate(data) : []), [data]);

  if (isLoading) return <p>Loading stigma data...</p>;
  if (error) return <p style={{ color: 'red' }}>Failed to load stigma data.</p>;
  if (!data?.length) return <p>No stigma data available</p>;

  return (
    <div style={{ padding: '1rem' }}>
      {/* Commented out the chart selector dropdown
      <div style={{ marginBottom: '1.5rem', textAlign: 'center' }}>
        <label style={{ marginRight: '0.5rem', fontWeight: 'bold' }}>Select Chart </label>
        <select
          value={chartType}
          onChange={(e) => setChartType(e.target.value as any)}
          style={{
            padding: '0.5rem 1rem',
            borderRadius: '4px',
            border: '1px solid #ccc',
            backgroundColor: '#f8f8f8',
          }}
        >
          <option value="type">प्रकार र आयाम अनुसार स्टिग्मा अंक</option>
          <option value="line">समय अनुसार स्टिग्मा अंक</option>
        </select>
      </div> */}

      {/* Always show the TypeDimensionBarChart */}
      <TypeDimensionBarChart data={typeData} />
    </div>
  );
}
