# Type of Dimension - Stigma Domain Score Synchronization

## Overview
This document explains how the **Type of Dimension** column in the Stigma Score table automatically synchronizes with domain scores from the Stigma Assessment Form. The system displays active stigma domains and their calculated scores for **Anticipated Stigma** only.

## 🎯 **What is Type of Dimension?**

The **Type of Dimension** column shows which stigma domains are active for a patient based on their Stigma Assessment Form responses. It displays the specific categories of stigma that apply to the patient, making it easy to understand which areas need attention.

## 📊 **Four Stigma Domains**

### 1. **HIV Domain** (`hiv_domain_as`)
- **Concept UUID**: `90e0da1c-1bb4-48db-869e-d0ed4cd11c24`
- **Label**: "HIV domain total score- Anticipated stigma"
- **Calculation**: Sum of 12 HIV-related stigma questions
- **Score Range**: 0-48 points
- **Questions Include**: ART service confidentiality, healthcare worker respect, discrimination at clinics, etc.

### 2. **Mental Health Domain** (`mh_domain_as`)
- **Concept UUID**: `8f94f4c3-58f2-414a-9286-68c5ede9c46e`
- **Label**: "Mental health domain total score-Anticipated stigma"
- **Calculation**: Sum of 12 mental health stigma questions
- **Score Range**: 0-48 points
- **Questions Include**: Mental health service stigma, family reactions, workplace discrimination, etc.

### 3. **Sexual & Gender Minorities Domain** (`sgm_domain_as`)
- **Concept UUID**: `eb0a135d-3b90-470c-a684-d6dc3464712d`
- **Label**: "Sexual and Gender Minorities domain score- Anticipated stigma"
- **Calculation**: Sum of 12 SGM-related stigma questions
- **Score Range**: 0-48 points
- **Questions Include**: LGBTQ+ discrimination, identity hiding, family rejection, etc.

### 4. **Ethnic Minorities Domain** (`em_domain_as`)
- **Concept UUID**: `d1ccc9dc-92fa-4118-af50-6394295131f8`
- **Label**: "Ethnic Minorities domain score- Anticipated stigma score"
- **Calculation**: Sum of 12 ethnic/caste-related stigma questions
- **Score Range**: 0-48 points
- **Questions Include**: Caste discrimination, ethnic minority treatment, social exclusion, etc.

## 🔄 **How Synchronization Works**

### **Step 1: Form Completion**
```
Patient fills Stigma Assessment Form
↓
Each domain automatically calculates its score
↓
Only non-zero domains are considered "active"
```

### **Step 2: Data Detection**
```typescript
// System looks for these concept UUIDs in patient encounters
const hivDomainScore = getObsValue('90e0da1c-1bb4-48db-869e-d0ed4cd11c24');
const mhDomainScore = getObsValue('8f94f4c3-58f2-414a-9286-68c5ede9c46e');
const sgmDomainScore = getObsValue('eb0a135d-3b90-470c-a684-d6dc3464712d');
const emDomainScore = getObsValue('d1ccc9dc-92fa-4118-af50-6394295131f8');
```

### **Step 3: Active Domain Filtering**
```typescript
// Only domains with scores > 0 are included
if (hivDomainScore && hivDomainScore !== '0') {
  domainLabels.push('HIV Domain');
  domainScores.push(`HIV: ${hivDomainScore}`);
}
// ... same for other domains
```

### **Step 4: Display Generation**
```typescript
// Type of Dimension shows active domain names
typeOfDimension = domainLabels.join(', '); 
// Example: "HIV Domain, Mental Health Domain"

// Dimension Score shows actual scores
dimensionScore = domainScores.join(', ');
// Example: "HIV: 12, MH: 8"
```

## 📋 **Display Examples**

### **Example 1: Single Domain**
| Type of Stigma | Score | Type of Dimension | Score | Intersectional Stigma Score |
|----------------|-------|-------------------|-------|----------------------------|
| Anticipated Stigma | 67 | **HIV Domain** | **HIV: 23** | Not recorded |

### **Example 2: Multiple Domains**
| Type of Stigma | Score | Type of Dimension | Score | Intersectional Stigma Score |
|----------------|-------|-------------------|-------|----------------------------|
| Anticipated Stigma | 89 | **HIV Domain, Mental Health Domain** | **HIV: 23, MH: 15** | Not recorded |

### **Example 3: All Domains Active**
| Type of Stigma | Score | Type of Dimension | Score | Intersectional Stigma Score |
|----------------|-------|-------------------|-------|----------------------------|
| Anticipated Stigma | 134 | **HIV Domain, Mental Health Domain, Sexual & Gender Minorities Domain, Ethnic Minorities Domain** | **HIV: 23, MH: 15, SGM: 18, EM: 12** | Not recorded |

### **Example 4: No Active Domains**
| Type of Stigma | Score | Type of Dimension | Score | Intersectional Stigma Score |
|----------------|-------|-------------------|-------|----------------------------|
| Anticipated Stigma | 0 | **No domains detected** | **No scores available** | Not recorded |

## 🎯 **Key Features**

### **Automatic Detection**
- System automatically detects which domains have non-zero scores
- Only relevant domains appear in the display
- No manual configuration required

### **Real-Time Updates**
- Changes to Stigma Assessment Form immediately reflect in the table
- New form submissions automatically update the display
- Domain scores update instantly when forms are modified

### **Smart Filtering**
- Zero scores are excluded from display (domain not applicable)
- Only shows domains that are relevant to the specific patient
- Prevents cluttered display with irrelevant information

### **Anticipated Stigma Only**
- Domain synchronization **only applies to Anticipated Stigma row**
- Enacted Stigma row shows: "No enacted domains available"
- This maintains clear separation between anticipated vs. enacted stigma

## 🔧 **Technical Implementation**

### **Data Flow**
```
Stigma Assessment Form
↓ (Form submission creates OpenMRS encounter)
OpenMRS Database
↓ (REST API call)
COVID Stigma Data Resource
↓ (Domain score extraction and filtering)
Vitals Table Display
```

### **Debug Information**
When debugging, check browser console for:
```javascript
console.log('=== FETCHING DOMAIN SCORES ===');
console.log('HIV domain score found:', hivDomainScore);
console.log('Mental Health domain score found:', mhDomainScore);
console.log('SGM domain score found:', sgmDomainScore);
console.log('Ethnic Minorities domain score found:', emDomainScore);
console.log('Active domain labels:', domainLabels);
console.log('Active domain scores:', domainScores);
```

### **Encounter Detection**
The system detects Stigma Assessment Forms by looking for encounters containing:
```typescript
conceptUuid === 'b5be0487-ef8e-4c39-ad86-39dd341cf0a7' || // Anticipated Stigma Score
conceptUuid === '90e0da1c-1bb4-48db-869e-d0ed4cd11c24' || // HIV Domain Score
conceptUuid === '8f94f4c3-58f2-414a-9286-68c5ede9c46e' || // Mental Health Domain Score
conceptUuid === 'eb0a135d-3b90-470c-a684-d6dc3464712d' || // SGM Domain Score
conceptUuid === 'd1ccc9dc-92fa-4118-af50-6394295131f8'    // Ethnic Minorities Domain Score
```

## 🚀 **Benefits**

### **For Healthcare Providers**
- **Quick Assessment**: Instantly see which stigma areas affect the patient
- **Targeted Care**: Focus interventions on relevant domains only
- **Progress Tracking**: Monitor changes in specific stigma areas over time

### **For Patients**
- **Comprehensive View**: All stigma dimensions captured in one place
- **Clear Scoring**: Easy to understand domain-specific scores
- **Privacy Maintained**: Only relevant domains are displayed

### **For System Administrators**
- **Automatic Operation**: No manual configuration required
- **Real-Time Updates**: Changes reflect immediately
- **Scalable Design**: Easy to add new domains in the future

## 📝 **Troubleshooting**

### **Domain Not Showing**
1. Check if domain score is greater than 0
2. Verify Stigma Assessment Form was completed properly
3. Ensure concept UUIDs match between form and code

### **Incorrect Scores**
1. Verify form calculation expressions are correct
2. Check that all questions in domain are being summed
3. Confirm patient answered all relevant questions

### **Console Debugging**
Use browser DevTools to monitor:
- Domain score extraction process
- Active domain filtering logic
- Final display string generation

---

## 🎉 **Summary**

The Type of Dimension synchronization provides an intelligent, automatic way to display only the relevant stigma domains for each patient. By showing both domain names and scores, healthcare providers get a comprehensive yet focused view of the patient's anticipated stigma concerns, enabling more targeted and effective care interventions.
